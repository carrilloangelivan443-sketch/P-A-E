package com.IPN.PAE

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.edit
import kotlinx.coroutines.launch

@Composable
fun TopHeader(
    title: String,
    onOpenDrawer: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(
            onClick = onOpenDrawer,
            colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)
        ) {
            Icon(
                imageVector = Icons.Default.Menu,
                contentDescription = "Abrir menú",
                modifier = Modifier.size(32.dp)
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun MainDrawerLayout(
    currentScreenTitle: String,
    onLogoutOverride: (() -> Unit)? = null,
    content: @Composable (openDrawer: () -> Unit) -> Unit
) {
    val context = LocalContext.current
    val sharedPreferences = remember { context.getSharedPreferences("SesionIPN", Context.MODE_PRIVATE) }

    val boleta = sharedPreferences.getString("boleta", "") ?: ""
    val grupo = sharedPreferences.getString("grupo", "") ?: ""

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Color.Transparent,
                drawerShape = RoundedCornerShape(topEnd = 6.dp, bottomEnd = 6.dp),
                modifier = Modifier.fillMaxWidth(0.95f).fillMaxHeight()
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    FondoOlasBackground(modifier = Modifier.fillMaxSize())

                    Column(
                        modifier = Modifier.fillMaxSize().padding(24.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp, top = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.logo_ipn),
                                contentDescription = null,
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "PORTAL IPN",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Boleta: $boleta",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFFE0E0E0)
                                )
                                Text(
                                    text = "Grupo: $grupo",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFFFB4A2)
                                )
                            }
                        }

                        HorizontalDivider(color = Color(0x33FFFFFF), thickness = 1.dp)
                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Servicios Académicos",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        val services = listOf(
                            "Inicio" to Icons.Default.Home,
                            "Calificaciones" to Icons.Default.School,
                            "Horario de Clases" to Icons.Default.Schedule,
                            "Kárdex Académico" to Icons.Default.Assessment,
                            "Reinscripción" to Icons.Default.Description,
                            "Apariencia" to Icons.Default.Palette
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (service in services) {
                                val isSelected = service.first == currentScreenTitle
                                NavigationDrawerItem(
                                    icon = { Icon(service.second, null, tint = Color(0xFFFFB4A2)) },
                                    label = { Text(service.first, fontWeight = FontWeight.SemiBold, color = Color.White) },
                                    selected = isSelected,
                                    onClick = {
                                        scope.launch { drawerState.close() }
                                        if (!isSelected) {
                                            val targetActivity = when (service.first) {
                                                "Inicio" -> MainActivity::class.java
                                                "Calificaciones" -> CalificacionesActivity::class.java
                                                "Horario de Clases" -> HorarioActivity::class.java
                                                "Kárdex Académico" -> KardexActivity::class.java
                                                "Reinscripción" -> ReinscripcionActivity::class.java
                                                "Apariencia" -> AparienciaActivity::class.java
                                                else -> null
                                            }
                                            if (targetActivity != null) {
                                                val intent = Intent(context, targetActivity)
                                                if (service.first == "Inicio") {
                                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                                                }
                                                context.startActivity(intent)
                                            }
                                        }
                                    },
                                    colors = NavigationDrawerItemDefaults.colors(
                                        unselectedContainerColor = Color.Transparent,
                                        selectedContainerColor = Color(0x887D2242)
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.weight(1f))

                        OutlinedButton(
                            onClick = {
                                scope.launch { drawerState.close() }
                                if (onLogoutOverride != null) {
                                    onLogoutOverride()
                                } else {
                                    sharedPreferences.edit { clear() }
                                    val intent = Intent(context, MainActivity::class.java).apply {
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                    }
                                    context.startActivity(intent)
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color(0xFFFFB4A2)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ExitToApp, null, tint = Color(0xFFFFB4A2))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("CERRAR SESIÓN", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    ) {
        content {
            scope.launch { drawerState.open() }
        }
    }
}
