package com.IPN.PAE

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.core.content.edit
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.IPN.PAE.ui.theme.MyApplicationTheme
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp()
            }
        }
    }
}

@Composable
fun MainApp() {
    val context = LocalContext.current

    // GUARDADO DE SESIÓN AUTOMÁTICO (SharedPreferences)
    val sharedPreferences = context.getSharedPreferences("SesionIPN", Context.MODE_PRIVATE)

    var loggedInBoleta by remember { mutableStateOf(sharedPreferences.getString("boleta", null)) }
    var loggedInGrupo by remember { mutableStateOf(sharedPreferences.getString("grupo", null)) }
    var loggedInHorario by remember { mutableStateOf(sharedPreferences.getString("horario", null)) }
    var loggedInHorarioUrl by remember { mutableStateOf(sharedPreferences.getString("horarioUrl", null)) }

    if (loggedInBoleta == null) {
        LoginScreen { boleta, grupo, horario, horarioUrl ->
            // Al iniciar sesión exitosamente, guardamos los datos permanentemente
            sharedPreferences.edit {
                putString("boleta", boleta)
                putString("grupo", grupo)
                putString("horario", horario)
                putString("horarioUrl", horarioUrl)
            }

            loggedInBoleta = boleta
            loggedInGrupo = grupo
            loggedInHorario = horario
            loggedInHorarioUrl = horarioUrl
        }
    } else {
        HomeScreen(
            boleta = loggedInBoleta!!,
            grupo = loggedInGrupo ?: "",
            horario = loggedInHorario ?: "",
            horarioUrl = loggedInHorarioUrl ?: "",
            onLogout = {
                // Borra la sesión si presionan cerrar sesión
                sharedPreferences.edit { clear() }
                loggedInBoleta = null
                loggedInGrupo = null
                loggedInHorario = null
                loggedInHorarioUrl = null
            },
        )
    }
}

@Composable
fun LoginScreen(
    onLoginSuccess: (String, String, String, String) -> Unit
) {
    var boleta by remember { mutableStateOf(value = "") }
    var password by remember { mutableStateOf(value = "") }
    var isPasswordVisible by remember { mutableStateOf(value = false) }
    var errorMessage by remember { mutableStateOf<String?>(value = null) }
    var isLoading by remember { mutableStateOf(value = false) }

    val context = LocalContext.current
    val db = try {
        if (FirebaseApp.getApps(context).isEmpty()) {
            FirebaseApp.initializeApp(context)
        }
        FirebaseFirestore.getInstance()
    } catch (_: Exception) {
        null
    }

    Box(modifier = Modifier.fillMaxSize()) {
        FondoOlasBackground(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(modifier = Modifier.height(48.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.logo_ipn),
                    contentDescription = "Escudo Oficial IPN",
                    modifier = Modifier.size(140.dp).padding(bottom = 12.dp)
                )
                Text(
                    text = "INSTITUTO POLITÉCNICO NACIONAL",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "La Técnica al Servicio de la Patria",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFE0E0E0),
                    fontStyle = FontStyle.Italic,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
                )
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
                border = BorderStroke(1.dp, Color(0x33FFFFFF))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Iniciar Sesión",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    OutlinedTextField(
                        value = boleta,
                        onValueChange = { boleta = it; errorMessage = null },
                        label = { Text("Número de Boleta", color = Color(0xFFE0E0E0)) },
                        placeholder = { Text("Ej. 2023600001", color = Color(0xFFA0A0A0)) },
                        leadingIcon = { Icon(Icons.Default.Badge, "Boleta", tint = Color.White) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFFFB4A2), unfocusedBorderColor = Color(0x88FFFFFF),
                            focusedLabelColor = Color.White, unfocusedLabelColor = Color(0xFFE0E0E0), cursorColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp),
                        shape = RoundedCornerShape(16.dp)
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it; errorMessage = null },
                        label = { Text("Contraseña", color = Color(0xFFE0E0E0)) },
                        placeholder = { Text("••••••••", color = Color(0xFFA0A0A0)) },
                        leadingIcon = { Icon(Icons.Default.Lock, "Contraseña", tint = Color.White) },
                        trailingIcon = {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = null, tint = Color.White
                                )
                            }
                        },
                        singleLine = true,
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFFFB4A2), unfocusedBorderColor = Color(0x88FFFFFF),
                            focusedLabelColor = Color.White, unfocusedLabelColor = Color(0xFFE0E0E0), cursorColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        shape = RoundedCornerShape(16.dp)
                    )

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage!!,
                            color = Color(0xFFFF8A8A),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                    }

                    Button(
                        onClick = {
                            val inputBoleta = boleta.trim()
                            val inputPass = password.trim()
                            if (inputBoleta.isEmpty() || inputPass.isEmpty()) {
                                errorMessage = "Ingresa boleta y contraseña"
                                return@Button
                            }

                            if (db == null) {
                                isLoading = false
                                errorMessage = "Firebase no disponible"
                                return@Button
                            }

                            fun handleDocument(documento: DocumentSnapshot) {
                                val passwordRegistrada = (documento.getString("Contraseña")
                                    ?: documento.getString("contraseña")
                                    ?: documento.getString("Contrasena")
                                    ?: documento.getString("contrasena")
                                    ?: documento.getString("Password")
                                    ?: documento.getString("password")
                                    ?: documento["Contraseña"]?.toString()
                                    ?: documento["Password"]?.toString())?.trim() ?: ""

                                if (passwordRegistrada == inputPass) {
                                    val grupoDelAlumno = documento.getString("Grupo") ?: documento.getString("grupo") ?: ""

                                    fun fetchGroup(collectionName: String) {
                                        db.collection(collectionName).document(grupoDelAlumno)
                                            .get()
                                            .addOnSuccessListener { docGrupo ->
                                                if (docGrupo.exists()) {
                                                    val horario = docGrupo.getString("Horario") ?: docGrupo.getString("horario") ?: "Sin horario registrado"
                                                    val rawHorarioUrl = docGrupo.getString("horarioimg")
                                                        ?: docGrupo.getString("HorarioUrl") ?: ""

                                                    val storage = FirebaseStorage.getInstance()
                                                    fun resolveUrl(urlToResolve: String) {
                                                        if (urlToResolve.startsWith("gs://")) {
                                                            storage.getReferenceFromUrl(urlToResolve).downloadUrl
                                                                .addOnSuccessListener { uri: Uri ->
                                                                    isLoading = false
                                                                    onLoginSuccess(inputBoleta, grupoDelAlumno, horario, uri.toString())
                                                                }.addOnFailureListener {
                                                                    isLoading = false
                                                                    onLoginSuccess(inputBoleta, grupoDelAlumno, horario, urlToResolve)
                                                                }
                                                        } else {
                                                            isLoading = false
                                                            onLoginSuccess(inputBoleta, grupoDelAlumno, horario, urlToResolve)
                                                        }
                                                    }
                                                    resolveUrl(rawHorarioUrl)
                                                } else {
                                                    if (collectionName == "Grupos") fetchGroup("GRUPOS")
                                                    else {
                                                        isLoading = false
                                                        onLoginSuccess(inputBoleta, grupoDelAlumno, "Horario no encontrado", "")
                                                    }
                                                }
                                            }
                                            .addOnFailureListener {
                                                if (collectionName == "Grupos") fetchGroup("GRUPOS")
                                                else {
                                                    isLoading = false
                                                    onLoginSuccess(inputBoleta, grupoDelAlumno, "Error", "")
                                                }
                                            }
                                    }
                                    fetchGroup("Grupos")
                                } else {
                                    isLoading = false
                                    errorMessage = "Contraseña incorrecta"
                                }
                            }

                            db.collection("Alumnos").document(inputBoleta).get()
                                .addOnSuccessListener { documento ->
                                    if (documento.exists()) handleDocument(documento)
                                    else {
                                        db.collection("AlumnosIPN").document(inputBoleta).get()
                                            .addOnSuccessListener { doc2 ->
                                                if (doc2.exists()) handleDocument(doc2)
                                                else {
                                                    isLoading = false
                                                    errorMessage = "La boleta no está registrada"
                                                }
                                            }
                                            .addOnFailureListener { e -> isLoading = false; errorMessage = "Error: ${e.localizedMessage}" }
                                    }
                                }
                                .addOnFailureListener { e -> isLoading = false; errorMessage = "Error: ${e.localizedMessage}" }
                        },
                        enabled = !isLoading,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7D2242), contentColor = Color.White),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                    ) {
                        if (isLoading) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                        else Text(text = "INICIAR SESIÓN", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    boleta: String,
    grupo: String,
    horario: String,
    horarioUrl: String,
    onLogout: () -> Unit
) {
    val localDrawableResId = remember(grupo) {
        when (grupo.trim().uppercase()) {
            "5IV11" -> R.drawable.horario_5iv11
            "5IV12" -> R.drawable.horario_5iv12
            "6IV11" -> R.drawable.horario_6iv11
            else -> R.drawable.horario_default
        }
    }

    MainDrawerLayout(
        currentScreenTitle = "Inicio",
        onLogoutOverride = onLogout
    ) { openDrawer ->
        Box(modifier = Modifier.fillMaxSize()) {
            FondoLavaBackground(modifier = Modifier.fillMaxSize())

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .verticalScroll(rememberScrollState())
            ) {
                TopHeader(title = "Inicio", onOpenDrawer = openDrawer)

                // CONTENIDO FIJO DE LA VENTANA "INICIO"
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
                    border = BorderStroke(1.dp, Color(0x33FFFFFF)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("¡Bienvenido Politécnico!", style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Boleta: $boleta", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFE0E0E0))
                        Text("Grupo: $grupo", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = Color(0xFFFFB4A2))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Horario: $horario", style = MaterialTheme.typography.bodySmall, color = Color(0xFFD0D0D0))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                ScheduleCard(grupo = grupo, horarioUrl = horarioUrl, localDrawableResId = localDrawableResId)
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun ScheduleCard(grupo: String, horarioUrl: String, localDrawableResId: Int) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
        border = BorderStroke(1.dp, Color(0x33FFFFFF)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Horario Escolar - Grupo $grupo", style = MaterialTheme.typography.titleSmall, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))

            if (horarioUrl.isNotBlank()) {
                AsyncImage(model = horarioUrl, contentDescription = null, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.FillWidth)
            } else if (localDrawableResId != 0) {
                Image(painter = painterResource(id = localDrawableResId), contentDescription = null, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.FillWidth)
            } else {
                Box(modifier = Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Text("Horario no disponible para el grupo $grupo", color = Color(0xFFE0E0E0), style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, modifier = Modifier.padding(16.dp))
                }
            }
        }
    }
}