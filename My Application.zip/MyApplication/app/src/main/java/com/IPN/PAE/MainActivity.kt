package com.IPN.PAE

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.IPN.PAE.ui.theme.AppThemeMode
import com.IPN.PAE.ui.theme.MyApplicationTheme
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.time.Duration.Companion.seconds

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var themeMode by remember { mutableStateOf(AppThemeMode.APP_GUINDA) }
            val systemDark = isSystemInDarkTheme()
            val effectiveThemeMode = when (themeMode) {
                AppThemeMode.SYSTEM -> if (systemDark) AppThemeMode.DARK else AppThemeMode.LIGHT
                else -> themeMode
            }

            MyApplicationTheme(themeMode = effectiveThemeMode) {
                MainApp(
                    themeMode = themeMode,
                    effectiveThemeMode = effectiveThemeMode,
                    onThemeModeChanged = { themeMode = it }
                )
            }
        }
    }
}

sealed class AppScreen {
    object Home : AppScreen()
    object Appearance : AppScreen()
}

@Composable
fun MainApp(
    themeMode: AppThemeMode,
    effectiveThemeMode: AppThemeMode,
    onThemeModeChanged: (AppThemeMode) -> Unit
) {
    var loggedInBoleta by remember { mutableStateOf<String?>(value = null) }
    var loggedInGrupo by remember { mutableStateOf<String?>(value = null) }
    var loggedInHorario by remember { mutableStateOf<String?>(value = null) }
    var currentScreen by remember { mutableStateOf<AppScreen>(AppScreen.Home) }

    if (loggedInBoleta == null) {
        LoginScreen(
            themeMode = effectiveThemeMode,
            onLoginSuccess = { boleta, grupo, horario ->
                loggedInBoleta = boleta
                loggedInGrupo = grupo
                loggedInHorario = horario
            }
        )
    } else {
        when (currentScreen) {
            is AppScreen.Appearance -> {
                AppearanceScreen(
                    themeMode = themeMode,
                    effectiveThemeMode = effectiveThemeMode,
                    onThemeModeChanged = onThemeModeChanged,
                    onBack = { currentScreen = AppScreen.Home }
                )
            }
            is AppScreen.Home -> {
                HomeScreen(
                    boleta = loggedInBoleta!!,
                    grupo = loggedInGrupo!!,
                    horario = loggedInHorario!!,
                    themeMode = effectiveThemeMode,
                    onOpenAppearance = { currentScreen = AppScreen.Appearance },
                    onLogout = {
                        loggedInBoleta = null
                        loggedInGrupo = null
                        loggedInHorario = null
                    }
                )
            }
        }
    }
}

@Composable
fun LoginScreen(
    themeMode: AppThemeMode,
    onLoginSuccess: (String, String, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var boleta by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(value = false) }
    var errorMessage by remember { mutableStateOf<String?>(value = null) }
    var isLoading by remember { mutableStateOf(false) }

    val db = FirebaseFirestore.getInstance()

    Box(modifier = Modifier.fillMaxSize()) {
        FondoOlasBackground(modifier = Modifier.fillMaxSize(), themeMode = themeMode)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {

            Spacer(modifier = Modifier.height(48.dp))

            // Encabezado
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.logo_ipn),
                    contentDescription = "Escudo Oficial IPN",
                    modifier = Modifier
                        .size(140.dp)
                        .padding(bottom = 12.dp)
                )

                Text(
                    text = "INSTITUTO POLITÉCNICO NACIONAL",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "La Técnica al Servicio de la Patria",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFE0E0E0),
                    fontStyle = FontStyle.Italic,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 2.dp)
                )
            }

            // Tarjeta de Formulario
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0x33000000)
                ),
                border = BorderStroke(1.dp, Color(0x33FFFFFF))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Iniciar Sesión",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    OutlinedTextField(
                        value = boleta,
                        onValueChange = {
                            boleta = it
                            errorMessage = null
                        },
                        label = { Text("Número de Boleta", color = Color(0xFFE0E0E0)) },
                        placeholder = { Text("Ej. 2023600001", color = Color(0xFFA0A0A0)) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Badge,
                                contentDescription = "Boleta",
                                tint = Color.White
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Next
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFFFB4A2),
                            unfocusedBorderColor = Color(0x88FFFFFF),
                            focusedLabelColor = Color.White,
                            unfocusedLabelColor = Color(0xFFE0E0E0),
                            cursorColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 14.dp),
                        shape = RoundedCornerShape(16.dp)
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = {
                            password = it
                            errorMessage = null
                        },
                        label = { Text("Contraseña", color = Color(0xFFE0E0E0)) },
                        placeholder = { Text("••••••••", color = Color(0xFFA0A0A0)) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Contraseña",
                                tint = Color.White
                            )
                        },
                        trailingIcon = {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = if (isPasswordVisible) "Ocultar contraseña" else "Mostrar contraseña",
                                    tint = Color.White
                                )
                            }
                        },
                        singleLine = true,
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = ImeAction.Done
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFFFB4A2),
                            unfocusedBorderColor = Color(0x88FFFFFF),
                            focusedLabelColor = Color.White,
                            unfocusedLabelColor = Color(0xFFE0E0E0),
                            cursorColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        shape = RoundedCornerShape(16.dp)
                    )

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage!!,
                            color = Color(0xFFFF8A8A),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                    }

                    Button(
                        onClick = {
                            val inputBoleta = boleta.trim()
                            val inputPass = password.trim()

                            if (inputBoleta.isEmpty() || inputPass.isEmpty()) {
                                val msg = "Ingresa boleta y contraseña"
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                errorMessage = msg
                                return@Button
                            }

                            isLoading = true
                            scope.launch {
                                delay(8.seconds)
                                if (isLoading) {
                                    isLoading = false
                                    val msg = "Tiempo de espera agotado. Revisa tu conexión."
                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                    errorMessage = msg
                                }
                            }

                            // 1. Consulta en Cloud Firestore la colección AlumnosIPN usando el número de boleta como ID
                            db.collection("AlumnosIPN").document(inputBoleta)
                                .get()
                                .addOnSuccessListener { documento ->
                                    isLoading = false
                                    if (documento.exists()) {
                                        // 2. Lee el campo exacto Contraseña (con C mayúscula y tilde ñ)
                                        val passwordRegistrada = documento.getString("Contraseña")?.trim() ?: ""
                                        
                                        // 3. Compara aplicando .trim() a ambas cadenas
                                        if (passwordRegistrada == inputPass) {
                                            // 4. Extrae el campo Grupo (con G mayúscula)
                                            val grupoDelAlumno = documento.getString("Grupo") ?: ""

                                            // Realiza la consulta a la colección "Grupos" (o "GRUPOS") usando ese grupo
                                            db.collection("Grupos").document(grupoDelAlumno)
                                                .get()
                                                .addOnSuccessListener { docGrupo ->
                                                    val horario = if (docGrupo.exists()) {
                                                        docGrupo.getString("Horario") ?: "Sin horario registrado"
                                                    } else {
                                                        "Horario no encontrado"
                                                    }
                                                    Toast.makeText(context, "¡Bienvenido Politécnico!", Toast.LENGTH_SHORT).show()
                                                    onLoginSuccess(inputBoleta, grupoDelAlumno, horario)
                                                }
                                                .addOnFailureListener {
                                                    val horarioFallback = "No se pudo cargar el horario"
                                                    Toast.makeText(context, "¡Bienvenido Politécnico!", Toast.LENGTH_SHORT).show()
                                                    onLoginSuccess(inputBoleta, grupoDelAlumno, horarioFallback)
                                                }
                                        } else {
                                            // 5. Muestra mensaje claro con Toast si la contraseña no coincide
                                            val msg = "Contraseña incorrecta"
                                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                            errorMessage = msg
                                        }
                                    } else {
                                        // Muestra mensaje claro con Toast si la boleta no existe
                                        val msg = "La boleta no está registrada"
                                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                        errorMessage = msg
                                    }
                                }
                                .addOnFailureListener { e ->
                                    isLoading = false
                                    val msg = "Error de conexión: ${e.localizedMessage}"
                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                    errorMessage = msg
                                }
                        },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = when (themeMode) {
                                AppThemeMode.APP_GUINDA -> Color(0xFF7D2242)
                                AppThemeMode.DARK -> Color(0xFF333333)
                                AppThemeMode.LIGHT -> Color(0xFF1E1E1E)
                                AppThemeMode.SYSTEM -> Color(0xFF333333)
                            },
                            contentColor = Color.White
                        ),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        } else {
                            Text(
                                text = "INICIAR SESIÓN",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppearanceScreen(
    themeMode: AppThemeMode,
    effectiveThemeMode: AppThemeMode,
    onThemeModeChanged: (AppThemeMode) -> Unit,
    onBack: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        FondoLavaBackground(modifier = Modifier.fillMaxSize(), themeMode = effectiveThemeMode)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(24.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Regresar",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Apariencia",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
                border = BorderStroke(1.dp, Color(0x33FFFFFF))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Selecciona el modo de apariencia",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    val modes = listOf(
                        AppThemeMode.APP_GUINDA to "Modo Aplicación (IPN Guinda)",
                        AppThemeMode.DARK to "Modo Oscuro (Negro y Grises)",
                        AppThemeMode.LIGHT to "Modo Claro (Blanco y Grises)",
                        AppThemeMode.SYSTEM to "Modo del Sistema (Automático)"
                    )

                    for ((mode, label) in modes) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onThemeModeChanged(mode) }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (themeMode == mode),
                                onClick = { onThemeModeChanged(mode) }
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = label,
                                style = MaterialTheme.typography.bodyLarge,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    boleta: String,
    grupo: String,
    horario: String,
    themeMode: AppThemeMode,
    onOpenAppearance: () -> Unit,
    onLogout: () -> Unit
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Color.Transparent,
                drawerShape = RoundedCornerShape(topEnd = 6.dp, bottomEnd = 6.dp),
                modifier = Modifier.fillMaxWidth(0.95f)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    FondoOlasBackground(modifier = Modifier.fillMaxSize(), themeMode = themeMode)

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp)
                    ) {
                        // --- ENCABEZADO DEL MENÚ ---
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 20.dp, top = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.logo_ipn),
                                contentDescription = "Logo IPN",
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "PORTAL IPN",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Boleta: $boleta",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFFE0E0E0)
                                )
                                Text(
                                    text = "Grupo: $grupo",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFFFB4A2)
                                )
                            }
                        }

                        HorizontalDivider(color = Color(0x33FFFFFF), thickness = 1.dp)
                        Spacer(modifier = Modifier.height(16.dp))

                        // --- OPCIONES DEL MENÚ ---
                        Text(
                            text = "Servicios Académicos",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        val services = listOf(
                            "Calificaciones" to Icons.Default.School,
                            "Horario de Clases" to Icons.Default.Schedule,
                            "Kárdex Académico" to Icons.Default.Assessment,
                            "Reinscripción" to Icons.Default.Description,
                            "Apariencia" to Icons.Default.Palette
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (service in services) {
                                NavigationDrawerItem(
                                    icon = {
                                        Icon(
                                            imageVector = service.second,
                                            contentDescription = service.first,
                                            tint = Color(0xFFFFB4A2)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = service.first,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color.White
                                        )
                                    },
                                    selected = false,
                                    onClick = {
                                        scope.launch {
                                            drawerState.close()
                                            delay(200L)
                                            if (service.first == "Apariencia") {
                                                onOpenAppearance()
                                            }
                                        }
                                    },
                                    colors = NavigationDrawerItemDefaults.colors(
                                        unselectedContainerColor = Color.Transparent
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.weight(1f))

                        // --- BOTÓN CERRAR SESIÓN ---
                        OutlinedButton(
                            onClick = onLogout,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color(0xFFFFB4A2)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                                contentDescription = null,
                                tint = Color(0xFFFFB4A2)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "CERRAR SESIÓN",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    ) {
        // --- CONTENIDO DE LA PANTALLA PRINCIPAL ---
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            FondoLavaBackground(modifier = Modifier.fillMaxSize(), themeMode = themeMode)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
            ) {
                // Barra superior en la pantalla principal
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            scope.launch { drawerState.open() }
                        },
                        colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Abrir menú",
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Inicio",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Tarjeta de bienvenida, grupo y horario obtenido de Firestore
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
                    border = BorderStroke(1.dp, Color(0x33FFFFFF)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "¡Bienvenido Politécnico!",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Boleta: $boleta",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFE0E0E0)
                        )
                        Text(
                            text = "Grupo: $grupo",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFFFB4A2)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Horario: $horario",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFD0D0D0)
                        )
                    }
                }
            }
        }
    }
}

@Preview
@Composable
fun LoginScreenPreview() {
    MyApplicationTheme {
        LoginScreen(themeMode = AppThemeMode.APP_GUINDA, onLoginSuccess = { _, _, _ -> })
    }
}

@Preview
@Composable
fun HomeScreenPreview() {
    MyApplicationTheme {
        HomeScreen(
            boleta = "2023600001",
            grupo = "5IV11",
            horario = "Lunes a Viernes 7:00 - 13:00 hrs",
            themeMode = AppThemeMode.APP_GUINDA,
            onOpenAppearance = {},
            onLogout = {}
        )
    }
}
