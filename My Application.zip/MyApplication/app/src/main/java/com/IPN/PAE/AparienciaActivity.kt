package com.IPN.PAE

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.IPN.PAE.ui.theme.MyApplicationTheme

class AparienciaActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                AparienciaScreen()
            }
        }
    }
}

@Composable
fun AparienciaScreen() {
    var darkModeEnabled by remember { mutableStateOf(value = true) }
    var highContrastEnabled by remember { mutableStateOf(value = false) }

    MainDrawerLayout(currentScreenTitle = "Apariencia") { openDrawer ->
        Box(modifier = Modifier.fillMaxSize()) {
            FondoLavaBackground(modifier = Modifier.fillMaxSize())

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .verticalScroll(rememberScrollState()),
            ) {
                TopHeader(title = "Apariencia", onOpenDrawer = openDrawer)

                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
                    border = BorderStroke(1.dp, Color(0x33FFFFFF)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "Configuración de Apariencia",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Tema Oscuro", color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text("Usar colores oscuros en toda la app", color = Color(0xFFE0E0E0), style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(
                                checked = darkModeEnabled,
                                onCheckedChange = { darkModeEnabled = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFF7D2242)
                                )
                            )
                        }

                        HorizontalDivider(color = Color(0x22FFFFFF), thickness = 0.5.dp)

                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Alto Contraste", color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text("Mejorar legibilidad de los textos", color = Color(0xFFE0E0E0), style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(
                                checked = highContrastEnabled,
                                onCheckedChange = { highContrastEnabled = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFF7D2242)
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
