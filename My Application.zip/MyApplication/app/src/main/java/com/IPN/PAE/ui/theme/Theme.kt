package com.IPN.PAE.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

enum class AppThemeMode {
    APP_GUINDA,
    DARK,
    LIGHT,
    SYSTEM
}

@Composable
fun MyApplicationTheme(
    themeMode: AppThemeMode = AppThemeMode.APP_GUINDA,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val colorScheme = when (themeMode) {
        AppThemeMode.APP_GUINDA -> darkColorScheme(
            primary = Color(0xFF9E224C),
            secondary = Color(0xFF7D2242),
            tertiary = Color(0xFFFFB4A2),
            background = Color(0xFF2B0018),
            surface = Color(0xFF3B0020),
            onBackground = Color.White,
            onSurface = Color.White
        )
        AppThemeMode.DARK -> darkColorScheme(
            primary = Color(0xFF888888),
            secondary = Color(0xFF555555),
            tertiary = Color(0xFFAAAAAA),
            background = Color(0xFF0A0A0A),
            surface = Color(0xFF141414),
            onBackground = Color.White,
            onSurface = Color.White
        )
        AppThemeMode.LIGHT -> lightColorScheme(
            primary = Color(0xFF333333),
            secondary = Color(0xFF666666),
            tertiary = Color(0xFF111111),
            background = Color(0xFFF2F2F2),
            surface = Color(0xFFFFFFFF),
            onBackground = Color.Black,
            onSurface = Color.Black
        )
        AppThemeMode.SYSTEM -> if (systemDark) darkColorScheme(
            primary = Color(0xFF888888),
            background = Color(0xFF0A0A0A),
            surface = Color(0xFF141414),
            onBackground = Color.White,
            onSurface = Color.White
        ) else lightColorScheme(
            primary = Color(0xFF333333),
            background = Color(0xFFF2F2F2),
            surface = Color(0xFFFFFFFF),
            onBackground = Color.Black,
            onSurface = Color.Black
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
