package com.IPN.PAE

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.IPN.PAE.ui.theme.MyApplicationTheme
import com.google.firebase.firestore.FirebaseFirestore

// Estructura de datos para almacenar temporalmente cada materia y sus calificaciones
data class CalificacionMateria(
    val nombre: String,
    val u1: String,
    val u2: String,
    val u3: String,
    val final: String
)

class CalificacionesActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CalificacionesScreen(onBack = { finish() })
            }
        }
    }
}

@Composable
fun CalificacionesScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    // 1. Extraemos la boleta guardada en sesión
    val sharedPreferences = context.getSharedPreferences("SesionIPN", Context.MODE_PRIVATE)
    val boleta = sharedPreferences.getString("boleta", "") ?: ""

    // 2. Variables de estado para la pantalla
    var listaCalificaciones by remember { mutableStateOf<List<CalificacionMateria>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMensaje by remember { mutableStateOf<String?>(null) }

    // 3. Consulta Inteligente a Firebase: Soporta las dos estructuras de base de datos
    LaunchedEffect(boleta) {
        if (boleta.isNotBlank()) {
            val db = FirebaseFirestore.getInstance()
            db.collection("Calificaciones").document(boleta).get()
                .addOnSuccessListener { document ->
                    if (document.exists() && document.data != null) {
                        val data = document.data!!
                        val materiasTemp = mutableListOf<CalificacionMateria>()

                        // VERIFICAMOS QUÉ ESTRUCTURA TIENE ESTA BOLETA
                        if (data.containsKey("Unidad 1") || data.containsKey("Unidad 2") || data.containsKey("Unidad 3")) {

                            // --> ESTRUCTURA A (Ej. 2024050172): Agrupado por Unidades
                            val u1Map = data["Unidad 1"] as? Map<*, *> ?: emptyMap<String, String>()
                            val u2Map = data["Unidad 2"] as? Map<*, *> ?: emptyMap<String, String>()
                            val u3Map = data["Unidad 3"] as? Map<*, *> ?: emptyMap<String, String>()

                            val nombresMaterias = mutableSetOf<String>()
                            nombresMaterias.addAll(u1Map.keys.map { it.toString() })
                            nombresMaterias.addAll(u2Map.keys.map { it.toString() })
                            nombresMaterias.addAll(u3Map.keys.map { it.toString() })

                            for (materia in nombresMaterias) {
                                val u1 = u1Map[materia]?.toString() ?: "-"
                                val u2 = u2Map[materia]?.toString() ?: "-"
                                val u3 = u3Map[materia]?.toString() ?: "-"

                                var promedioFinal = "-"
                                val validas = listOfNotNull(u1.toFloatOrNull(), u2.toFloatOrNull(), u3.toFloatOrNull())

                                if (validas.isNotEmpty()) {
                                    val promedio = validas.sum() / validas.size
                                    promedioFinal = (Math.round(promedio * 10.0) / 10.0).toString()
                                }

                                materiasTemp.add(
                                    CalificacionMateria(materia, u1, u2, u3, promedioFinal)
                                )
                            }
                        } else {
                            // --> ESTRUCTURA B (Ej. 2026100001): Agrupado directamente por Materias
                            for ((nombreMateria, datosMapa) in data) {
                                if (datosMapa is Map<*, *>) {
                                    val u1 = datosMapa["u1"]?.toString() ?: "-"
                                    val u2 = datosMapa["u2"]?.toString() ?: "-"
                                    val u3 = datosMapa["u3"]?.toString() ?: "-"
                                    var final = datosMapa["final"]?.toString() ?: "-"

                                    // Si no trae calificación final de la nube, la calculamos igual
                                    if (final == "-" || final.isBlank()) {
                                        val validas = listOfNotNull(u1.toFloatOrNull(), u2.toFloatOrNull(), u3.toFloatOrNull())
                                        if (validas.isNotEmpty()) {
                                            val promedio = validas.sum() / validas.size
                                            final = (Math.round(promedio * 10.0) / 10.0).toString()
                                        }
                                    }

                                    materiasTemp.add(
                                        CalificacionMateria(nombreMateria, u1, u2, u3, final)
                                    )
                                }
                            }
                        }

                        // Ordenamos alfabéticamente
                        listaCalificaciones = materiasTemp.sortedBy { it.nombre }
                    }
                    isLoading = false
                }
                .addOnFailureListener {
                    errorMensaje = "No se pudieron cargar las calificaciones"
                    isLoading = false
                }
        } else {
            isLoading = false
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        FondoLavaBackground(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
        ) {
            // Barra superior
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Regresar", modifier = Modifier.size(32.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("Calificaciones", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold)
            }

            // Contenedor principal de los resultados
            Column(modifier = Modifier.padding(horizontal = 24.dp)) {
                if (isLoading) {
                    Box(modifier = Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Color(0xFFFFB4A2))
                    }
                } else if (errorMensaje != null) {
                    Text(text = errorMensaje!!, color = Color(0xFFFF8A8A), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                } else if (listaCalificaciones.isEmpty()) {
                    Text(text = "No hay calificaciones registradas para la boleta $boleta.", color = Color.White, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                } else {
                    // Dibujamos una tarjeta por cada materia encontrada en Firebase
                    for (materia in listaCalificaciones) {
                        TarjetaMateria(materia)
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun TarjetaMateria(calificacion: CalificacionMateria) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
        border = BorderStroke(1.dp, Color(0x33FFFFFF)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = calificacion.nombre,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 12.dp),
                color = Color(0x22FFFFFF),
                thickness = 1.dp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                ElementoCalificacion(titulo = "Unidad 1", valor = calificacion.u1)
                ElementoCalificacion(titulo = "Unidad 2", valor = calificacion.u2)
                ElementoCalificacion(titulo = "Unidad 3", valor = calificacion.u3)
                ElementoCalificacion(titulo = "Final", valor = calificacion.final, esFinal = true)
            }
        }
    }
}

@Composable
fun ElementoCalificacion(titulo: String, valor: String, esFinal: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = titulo,
            color = if (esFinal) Color(0xFFFFB4A2) else Color(0xFFA0A0A0),
            fontSize = 12.sp,
            fontWeight = if (esFinal) FontWeight.Bold else FontWeight.Normal
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = valor,
            color = if (esFinal) Color(0xFFFFB4A2) else Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )
    }
}