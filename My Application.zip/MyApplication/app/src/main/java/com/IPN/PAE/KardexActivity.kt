package com.IPN.PAE

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.IPN.PAE.ui.theme.MyApplicationTheme

class KardexActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                KardexScreen()
            }
        }
    }
}

@Composable
fun KardexScreen() {
    MainDrawerLayout(currentScreenTitle = "Kárdex Académico") { openDrawer ->
        Box(modifier = Modifier.fillMaxSize()) {
            FondoLavaBackground(modifier = Modifier.fillMaxSize())

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .verticalScroll(rememberScrollState())
            ) {
                TopHeader(title = "Kárdex Académico", onOpenDrawer = openDrawer)

                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
                    border = BorderStroke(1.dp, Color(0x33FFFFFF)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("Kárdex Académico General", style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(text = "Promedio General Acumulado: 9.35", color = Color(0xFFFFB4A2), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "Créditos Acreditados: 240 / 300", color = Color(0xFFE0E0E0), style = MaterialTheme.typography.bodyMedium)
                        Text(text = "Estado: Alumno Regular", color = Color(0xFFE0E0E0), style = MaterialTheme.typography.bodyMedium)
                        Text(text = "Unidad Académica: CECyT / ESIME / UPIITA", color = Color(0xFFD0D0D0), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
