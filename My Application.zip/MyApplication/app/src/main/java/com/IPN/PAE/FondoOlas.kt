package com.IPN.PAE

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.IPN.PAE.ui.theme.AppThemeMode
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun FondoOlasBackground(
    modifier: Modifier = Modifier,
    themeMode: AppThemeMode = AppThemeMode.APP_GUINDA,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "listones_transition")

    val tiempo by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 16000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "tiempo",
    )

    val systemDark = isSystemInDarkTheme()

    val coloresFondo = when (themeMode) {
        AppThemeMode.APP_GUINDA -> listOf(
            Color(0xFF12000A),
            Color(0xFF220013),
            Color(0xFF12000A)
        )
        AppThemeMode.DARK -> listOf(
            Color(0xFF050505),
            Color(0xFF161616),
            Color(0xFF050505)
        )
        AppThemeMode.LIGHT -> listOf(
            Color(0xFFE8E8E8),
            Color(0xFFFAFAFA),
            Color(0xFFE8E8E8)
        )
        AppThemeMode.SYSTEM -> if (systemDark) {
            listOf(Color(0xFF050505), Color(0xFF161616), Color(0xFF050505))
        } else {
            listOf(Color(0xFFE8E8E8), Color(0xFFFAFAFA), Color(0xFFE8E8E8))
        }
    }

    val coloresListon = when (themeMode) {
        AppThemeMode.APP_GUINDA -> listOf(
            Color(0x00000000),
            Color(0x405A002E),
            Color(0x999E224C),
            Color(0xE6E63973),
            Color(0x999E224C),
            Color(0x405A002E),
            Color(0x00000000)
        )
        AppThemeMode.DARK -> listOf(
            Color(0x00000000),
            Color(0x40222222),
            Color(0x99444444),
            Color(0xE6888888),
            Color(0x99444444),
            Color(0x40222222),
            Color(0x00000000)
        )
        AppThemeMode.LIGHT -> listOf(
            Color(0x00000000),
            Color(0x40D0D0D0),
            Color(0x99A0A0A0),
            Color(0xE6333333),
            Color(0x99A0A0A0),
            Color(0x40D0D0D0),
            Color(0x00000000)
        )
        AppThemeMode.SYSTEM -> if (systemDark) {
            listOf(Color(0x00000000), Color(0x40222222), Color(0x99444444), Color(0xE6888888), Color(0x99444444), Color(0x40222222), Color(0x00000000))
        } else {
            listOf(Color(0x00000000), Color(0x40D0D0D0), Color(0x99A0A0A0), Color(0xE6333333), Color(0x99A0A0A0), Color(0x40D0D0D0), Color(0x00000000))
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        if ((width <= 0f) || (height <= 0f)) return@Canvas

        drawRect(
            brush = Brush.verticalGradient(colors = coloresFondo),
            size = Size(width, height)
        )

        val posicionesY = listOf(0.22f, 0.36f, 0.50f, 0.64f, 0.78f)
        val amplitudes = listOf(180f, 220f, 260f, 220f, 180f)
        val opacidades = listOf(0.40f, 0.70f, 0.95f, 0.70f, 0.40f)

        for (i in posicionesY.indices) {
            val desfasamiento = i * 0.45f
            val faseDireccionada = if ((i % 2) == 0) (tiempo + desfasamiento) else ((-tiempo) - desfasamiento)

            dibujarCapaEsparcida(
                yCenter = height * posicionesY[i],
                anchoBand = height * 0.22f,
                amplitud = amplitudes[i],
                fase = faseDireccionada,
                opacidad = opacidades[i],
                coloresDegradado = coloresListon
            )
        }
    }
}

private fun DrawScope.dibujarCapaEsparcida(
    yCenter: Float,
    anchoBand: Float,
    amplitud: Float,
    fase: Float,
    opacidad: Float,
    coloresDegradado: List<Color>
) {
    val width = size.width

    val wave1 = sin(fase) * amplitud
    val wave2 = cos(fase * 2f) * (amplitud * 0.75f)
    val wave3 = sin(fase + (PI / 2).toFloat()) * amplitud

    val halfBand = anchoBand / 2f

    val path = Path().apply {
        reset()
        moveTo(-width * 0.15f, yCenter - halfBand + wave1)
        cubicTo(
            width * 0.30f, yCenter - halfBand + wave1 + cos(fase) * 110f,
            width * 0.70f, yCenter - halfBand + wave2 - sin(fase) * 110f,
            width * 1.15f, yCenter - halfBand + wave3
        )
        lineTo(width * 1.15f, yCenter + halfBand + wave3)
        cubicTo(
            width * 0.70f, yCenter + halfBand + wave2 - sin(fase) * 110f,
            width * 0.30f, yCenter + halfBand + wave1 + cos(fase) * 110f,
            -width * 0.15f, yCenter + halfBand + wave1
        )
        close()
    }

    val coloresConOpacidad = coloresDegradado.map { color ->
        color.copy(alpha = color.alpha * opacidad)
    }

    val startX = width * 0.1f + sin(fase) * 90f
    val endX = width * 0.9f + cos(fase) * 90f

    drawPath(
        path = path,
        brush = Brush.linearGradient(
            colors = coloresConOpacidad,
            start = Offset(startX, yCenter - amplitud * 1.2f),
            end = Offset(endX, yCenter + amplitud * 1.2f)
        )
    )
}
