package com.IPN.PAE

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.IPN.PAE.ui.theme.AppThemeMode
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun FondoLavaBackground(
    modifier: Modifier = Modifier,
    themeMode: AppThemeMode = AppThemeMode.APP_GUINDA
) {
    val infiniteTransition = rememberInfiniteTransition(label = "lava_transition")

    val tiempo by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "tiempo"
    )

    val systemDark = isSystemInDarkTheme()

    val coloresFondoBase = when (themeMode) {
        AppThemeMode.APP_GUINDA -> listOf(Color(0xFF0F0008), Color(0xFF1F0010), Color(0xFF0F0008))
        AppThemeMode.DARK -> listOf(Color(0xFF050505), Color(0xFF161616), Color(0xFF050505))
        AppThemeMode.LIGHT -> listOf(Color(0xFFE8E8E8), Color(0xFFFAFAFA), Color(0xFFE8E8E8))
        AppThemeMode.SYSTEM -> if (systemDark) listOf(Color(0xFF050505), Color(0xFF161616), Color(0xFF050505)) else listOf(Color(0xFFE8E8E8), Color(0xFFFAFAFA), Color(0xFFE8E8E8))
    }

    val coloresLava1 = when (themeMode) {
        AppThemeMode.APP_GUINDA -> listOf(Color(0xFFE63973), Color(0xCC9E224C), Color(0x665A002E), Color(0x0014000A))
        AppThemeMode.DARK -> listOf(Color(0xFF999999), Color(0xCC555555), Color(0x66222222), Color(0x00050505))
        AppThemeMode.LIGHT -> listOf(Color(0xFF222222), Color(0xCC666666), Color(0x66AAAAAA), Color(0x00E8E8E8))
        AppThemeMode.SYSTEM -> if (systemDark) listOf(Color(0xFF999999), Color(0xCC555555), Color(0x66222222), Color(0x00050505)) else listOf(Color(0xFF222222), Color(0xCC666666), Color(0x66AAAAAA), Color(0x00E8E8E8))
    }

    val coloresLava2 = when (themeMode) {
        AppThemeMode.APP_GUINDA -> listOf(Color(0xFFC71585), Color(0xB38A0A40), Color(0x4D3B0020), Color(0x0014000A))
        AppThemeMode.DARK -> listOf(Color(0xFF777777), Color(0xB3444444), Color(0x4D1A1A1A), Color(0x00050505))
        AppThemeMode.LIGHT -> listOf(Color(0xFF444444), Color(0xB3888888), Color(0x4DBBBBBB), Color(0x00E8E8E8))
        AppThemeMode.SYSTEM -> if (systemDark) listOf(Color(0xFF777777), Color(0xB3444444), Color(0x4D1A1A1A), Color(0x00050505)) else listOf(Color(0xFF444444), Color(0xB3888888), Color(0x4DBBBBBB), Color(0x00E8E8E8))
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        if (width <= 0f || height <= 0f) return@Canvas

        drawRect(
            brush = Brush.verticalGradient(colors = coloresFondoBase),
            size = Size(width, height)
        )

        val posX1 = width * 0.5f + (sin(tiempo) * width * 0.25f)
        val posY1 = height * 0.5f + (cos(tiempo * 2f) * height * 0.18f)
        val radio1 = (width.coerceAtLeast(height)) * 0.55f

        dibujarOrbeLava(centro = Offset(posX1, posY1), radio = radio1, colores = coloresLava1)

        val posX2 = width * 0.5f + (cos(tiempo + PI.toFloat()) * width * 0.3f)
        val posY2 = height * 0.5f + (sin(tiempo * 2f + PI.toFloat()) * height * 0.2f)
        val radio2 = (width.coerceAtLeast(height)) * 0.48f

        dibujarOrbeLava(centro = Offset(posX2, posY2), radio = radio2, colores = coloresLava2)

        val posX3 = width * 0.4f + (sin(tiempo * 2f) * width * 0.2f)
        val posY3 = height * 0.6f + (cos(tiempo) * height * 0.25f)
        val radio3 = (width.coerceAtLeast(height)) * 0.32f

        dibujarOrbeLava(centro = Offset(posX3, posY3), radio = radio3, colores = coloresLava1)
    }
}

private fun DrawScope.dibujarOrbeLava(
    centro: Offset,
    radio: Float,
    colores: List<Color>
) {
    drawCircle(
        brush = Brush.radialGradient(colors = colores, center = centro, radius = radio),
        radius = radio,
        center = centro
    )
}
