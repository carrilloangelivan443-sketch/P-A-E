package com.example.myapplication

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun FondoLavaBackground(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "lava_transition")

    // Ciclo exacto de 0 a 2π para garantizar un bucle continuo e imperceptible
    val tiempo by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "tiempo"
    )

    // Fondo base muy oscuro para conservar la viñeta negra en los bordes
    val coloresFondoBase = listOf(
        Color(0xFF0F0008),
        Color(0xFF1F0010),
        Color(0xFF0F0008)
    )

    // Paleta de colores vivos de lava (borgoña, magenta y vino brillante)
    val coloresLava1 = listOf(
        Color(0xFFE63973), // Centro brillante
        Color(0xCC9E224C),
        Color(0x665A002E),
        Color(0x0014000A)  // Borde transparente para fusión suave
    )

    val coloresLava2 = listOf(
        Color(0xFFC71585),
        Color(0xB38A0A40),
        Color(0x4D3B0020),
        Color(0x0014000A)
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        if (width <= 0f || height <= 0f) return@Canvas

        // 1. Fondo Vertical Fijo (Mantiene arriba y abajo completamente oscuros)
        drawRect(
            brush = Brush.verticalGradient(colors = coloresFondoBase),
            size = Size(width, height)
        )

        // 2. Orbe/Masa de lava principal (Flota y orbita suavemente en el centro)
        val posX1 = width * 0.5f + (sin(tiempo) * width * 0.25f)
        val posY1 = height * 0.5f + (cos(tiempo * 2f) * height * 0.18f)
        val radio1 = (width.coerceAtLeast(height)) * 0.55f

        dibujarOrbeLava(
            centro = Offset(posX1, posY1),
            radio = radio1,
            colores = coloresLava1
        )

        // 3. Orbe de lava secundario (Movimiento contrapuesto para mezclarse)
        val posX2 = width * 0.5f + (cos(tiempo + PI.toFloat()) * width * 0.3f)
        val posY2 = height * 0.5f + (sin(tiempo * 2f + PI.toFloat()) * height * 0.2f)
        val radio2 = (width.coerceAtLeast(height)) * 0.48f

        dibujarOrbeLava(
            centro = Offset(posX2, posY2),
            radio = radio2,
            colores = coloresLava2
        )

        // 4. Pequeña gota ascendente para acentuar la fluidez de lava
        val posX3 = width * 0.4f + (sin(tiempo * 2f) * width * 0.2f)
        val posY3 = height * 0.6f + (cos(tiempo) * height * 0.25f)
        val radio3 = (width.coerceAtLeast(height)) * 0.32f

        dibujarOrbeLava(
            centro = Offset(posX3, posY3),
            radio = radio3,
            colores = coloresLava1
        )
    }
}

private fun DrawScope.dibujarOrbeLava(
    centro: Offset,
    radio: Float,
    colores: List<Color>
) {
    drawCircle(
        brush = Brush.radialGradient(
            colors = colores,
            center = centro,
            radius = radio
        ),
        radius = radio,
        center = centro
    )
}
