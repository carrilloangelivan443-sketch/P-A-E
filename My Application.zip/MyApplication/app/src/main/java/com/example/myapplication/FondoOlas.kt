package com.example.myapplication

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun FondoOlasBackground(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "listones_transition")

    // Animación continua y suave
    val tiempo by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "tiempo"
    )

    // Colores oscuros del fondo base
    val coloresFondo = listOf(
        Color(0xFF2A0016),
        Color(0xFF14000A)
    )

    // Paleta de degradado con tonos vinos/rosados de tu código original
    val coloresListonPrimary = listOf(
        Color(0x002B0018), // Transparente en los extremos para desvanecer
        Color(0xCC8A0A40),
        Color(0xFFE63973),
        Color(0xCC8A0A40),
        Color(0x002B0018)
    )

    val coloresListonSecondary = listOf(
        Color(0x002B0018),
        Color(0xB35A002E),
        Color(0xE6B8285C),
        Color(0xB35A002E),
        Color(0x002B0018)
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        if (width <= 0f || height <= 0f) return@Canvas

        // 1. Fondo Oscuro Profundo
        drawRect(
            brush = Brush.verticalGradient(colors = coloresFondo),
            size = Size(width, height)
        )

        // 2. Listón/Velo Secundario (Capa Trasera)
        dibujarListon(
            yCenter = height * 0.45f,
            anchoListon = height * 0.28f,
            amplitud = 140f,
            fase = -tiempo * 0.8f + 1.2f,
            colores = coloresListonSecondary
        )

        // 3. Listón/Velo Principal (Capa Frontal)
        dibujarListon(
            yCenter = height * 0.52f,
            anchoListon = height * 0.32f,
            amplitud = 180f,
            fase = tiempo,
            colores = coloresListonPrimary
        )
    }
}

private fun DrawScope.dibujarListon(
    yCenter: Float,
    anchoListon: Float,
    amplitud: Float,
    fase: Float,
    colores: List<Color>
) {
    val width = size.width

    // Calculamos las posiciones dinámicas de ondulación
    val wave1 = sin(fase) * amplitud
    val wave2 = cos(fase * 1.2f) * (amplitud * 1.1f)
    val wave3 = sin(fase * 0.9f + 1.5f) * amplitud

    val halfBand = anchoListon / 2f

    val path = Path().apply {
        reset()

        // --- BORDE SUPERIOR DEL LISTÓN ---
        moveTo(-width * 0.1f, yCenter - halfBand + wave1)
        cubicTo(
            width * 0.3f, yCenter - halfBand + wave1 + cos(fase) * 90f,
            width * 0.6f, yCenter - halfBand + wave2 - sin(fase) * 90f,
            width * 1.1f, yCenter - halfBand + wave3
        )

        // --- CONEXIÓN AL BORDE INFERIOR ---
        lineTo(width * 1.1f, yCenter + halfBand + wave3)

        // --- BORDE INFERIOR DEL LISTÓN (De regreso de derecha a izquierda) ---
        cubicTo(
            width * 0.6f, yCenter + halfBand + wave2 - sin(fase) * 90f,
            width * 0.3f, yCenter + halfBand + wave1 + cos(fase) * 90f,
            -width * 0.1f, yCenter + halfBand + wave1
        )

        close()
    }

    // Gradient horizontal inclinado para simular reflejo de luz sobre la tela/listón
    val startX = width * 0.1f + sin(fase) * 80f
    val startY = yCenter - amplitud
    val endX = width * 0.9f + cos(fase) * 80f
    val endY = yCenter + amplitud

    drawPath(
        path = path,
        brush = Brush.linearGradient(
            colors = colores,
            start = Offset(startX, startY),
            end = Offset(endX, endY)
        )
    )
}
