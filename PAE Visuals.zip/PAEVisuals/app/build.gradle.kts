plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.paevisuals"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.example.paevisuals"
        minSdk = 24
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = false
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation(libs.androidx.activity.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.core.ktx)
    implementation(libs.material)
    
    // Driver JDBC para SQL Server compatible con Android
    implementation("net.sourceforge.jtds:jtds:1.3.1")
    // Corrutinas para ejecutar consultas en segundo plano sin congelar la app
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0")

    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
}
