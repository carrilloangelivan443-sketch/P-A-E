package com.example.paevisuals

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.sql.Connection
import java.sql.DriverManager

class MainActivity : AppCompatActivity() {

    // =========================================================================
    // CONFIGURACIÓN DE TU BASE DE DATOS SQL SERVER
    // Cambia aquí la IP y la contraseña de tu servidor SQL
    // =========================================================================
    private val dbIp = "10.159.47.103"           // Ip del servidor SQL
    private val dbPuerto = 1433                 // Puerto por defecto de SQL Server
    private val dbNombre = "ALUMNOS IPN"      // Nombre de tu base de datos
    private val dbUsuario = "sa"                // Usuario administrador de SQL Server
    private val dbContrasena = "54321"          // Contraseña del usuario administrador

    private lateinit var etNumeroBoleta: TextInputEditText
    private lateinit var etContrasena: TextInputEditText
    private lateinit var btnIngresar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        etNumeroBoleta = findViewById(R.id.etNumeroBoleta)
        etContrasena = findViewById(R.id.etContrasena)
        btnIngresar = findViewById(R.id.btnIngresar)

        // Acción al presionar el botón de Ingresar
        btnIngresar.setOnClickListener {
            val usuarioIngresado = etNumeroBoleta.text.toString().trim()
            val passwordIngresada = etContrasena.text.toString().trim()

            // Validar que los campos no estén vacíos
            if (usuarioIngresado.isEmpty() || passwordIngresada.isEmpty()) {
                Toast.makeText(this, "Por favor ingresa tu boleta y contraseña", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Realizar la autenticación consultando la tabla Estudiantes en SQL Server
            validarLoginEnSQLServer(usuarioIngresado, passwordIngresada)
        }
    }

    /**
     * Consulta la tabla 'Estudiantes' en SQL Server para verificar la boleta y contraseña ingresadas.
     */
    private fun validarLoginEnSQLServer(boleta: String, contrasena: String) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // Registrar el driver JDBC (Probamos jTDS y fallback al driver de Microsoft)
                try {
                    Class.forName("net.sourceforge.jtds.jdbc.Driver")
                } catch (_: Exception) {
                    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
                }

                // Intentar conexión con URL jTDS y fallback
                val connection: Connection = try {
                    val urlJtds = "jdbc:jtds:sqlserver://$dbIp:$dbPuerto/$dbNombre"
                    DriverManager.getConnection(urlJtds, dbUsuario, dbContrasena)
                } catch (e: Exception) {
                    val urlMssql = "jdbc:sqlserver://$dbIp:$dbPuerto;databaseName=$dbNombre;encrypt=false;"
                    DriverManager.getConnection(urlMssql, dbUsuario, dbContrasena)
                }

                // Consulta en la tabla 'Estudiantes'
                val sqlQuery = "SELECT contrasena FROM Estudiantes WHERE boleta = ?"
                val statement = connection.prepareStatement(sqlQuery)
                statement.setString(1, boleta)

                val resultSet = statement.executeQuery()
                var esCredencialValida = false

                if (resultSet.next()) {
                    val contrasenaBD = resultSet.getString("contrasena")
                    // Comparar la contraseña ingresada con la contraseña guardada en la base de datos
                    if (contrasenaBD != null && contrasenaBD.trim() == contrasena.trim()) {
                        esCredencialValida = true
                    }
                }

                resultSet.close()
                statement.close()
                connection.close()

                withContext(Dispatchers.Main) {
                    if (esCredencialValida) {
                        Toast.makeText(this@MainActivity, "¡Inicio de sesión correcto!", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this@MainActivity, MenuPrincipalActivity::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(this@MainActivity, "Boleta o contraseña incorrectas", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                Log.e("SQL_LOGIN", "Error en la conexión a la base de datos", e)
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        this@MainActivity,
                        "Error BD: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }
}
