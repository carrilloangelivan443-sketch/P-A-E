package com.example.paevisuals

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class FondoOlasView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val paintFondo = Paint()
    private val paintOla = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pathOla = Path()
    private var tiempo = 0f

    private val coloresFondo = intArrayOf(
        0xFF3B0020.toInt(),
        0xFF1F0010.toInt()
    )

    private val coloresDegradado = intArrayOf(
        0xFF2B0018.toInt(),
        0xFF5A002E.toInt(),
        0xFF9E224C.toInt(),
        0xFF5A002E.toInt(),
        0xFF2B0018.toInt()
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (width <= 0 || height <= 0) return

        // Dibujar degradado de fondo en lugar de un color negro plano
        paintFondo.shader = LinearGradient(
            0f, 0f, 0f, height.toFloat(),
            coloresFondo, null, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paintFondo)

        tiempo += 0.015f

        dibujarOlaConDegradadoCompleto(canvas, height * 0.40f, 80f, 0.004f, tiempo)
        dibujarOlaConDegradadoCompleto(canvas, height * 0.55f, 60f, 0.006f, -tiempo * 1.3f)

        if (!isInEditMode) {
            postInvalidateOnAnimation()
        }
    }

    private fun dibujarOlaConDegradadoCompleto(canvas: Canvas, alturaBase: Float, amplitud: Float, frecuencia: Float, velocidad: Float) {
        pathOla.reset()
        pathOla.moveTo(0f, height.toFloat())
        pathOla.lineTo(0f, alturaBase)

        var x = 0f
        val pasoX = 15f
        while (x <= width) {
            val y = alturaBase + sin(x * frecuencia + velocidad) * amplitud
            pathOla.lineTo(x, y)
            x += pasoX
        }
        pathOla.lineTo(width.toFloat(), height.toFloat())
        pathOla.close()

        val gradStartX = width * 0.3f + (sin(velocidad) * 150f)
        val gradStartY = alturaBase + (cos(velocidad) * 100f)
        val gradEndX = width * 0.8f + (cos(velocidad) * 200f)
        val gradEndY = height.toFloat()

        paintOla.shader = LinearGradient(
            gradStartX, gradStartY, gradEndX, gradEndY,
            coloresDegradado, null, Shader.TileMode.CLAMP
        )

        canvas.drawPath(pathOla, paintOla)
    }
}
