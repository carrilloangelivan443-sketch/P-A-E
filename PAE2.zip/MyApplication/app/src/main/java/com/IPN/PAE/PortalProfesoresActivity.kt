package com.IPN.PAE

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit
import com.IPN.PAE.ui.theme.AppThemeMode
import com.IPN.PAE.ui.theme.LocalAppThemeMode
import com.IPN.PAE.ui.theme.MyApplicationTheme
import com.IPN.PAE.ui.theme.getInstitutionalColor
import com.IPN.PAE.api.RetrofitClient
import com.IPN.PAE.api.models.AnuncioPostRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Estructura de datos
data class Anuncio(
    val id: String,
    val autor: String,
    val fecha: String,
    var mensaje: String,
)

class PortalProfesoresActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val sharedPreferences = getSharedPreferences("SesionIPN", MODE_PRIVATE)
        val intentNombre = intent.getStringExtra("NOMBRE_PROFESOR")

        val nombreProfesor = if (!intentNombre.isNullOrBlank()) {
            sharedPreferences.edit {
                putString("nombre_profesor", intentNombre)
                putBoolean("es_profesor", true)
            }
            intentNombre
        } else {
            sharedPreferences.getString("nombre_profesor", "")?.takeIf { it.isNotBlank() } ?: "Docente"
        }

        setContent {
            MyApplicationTheme {
                PortalProfesoresApp(
                    nombreProfesor = nombreProfesor,
                ) {
                    sharedPreferences.edit { clear() }
                    finish()
                }
            }
        }
    }
}

@Composable
fun PortalProfesoresApp(nombreProfesor: String, onBack: () -> Unit) {
    var currentScreen by remember { mutableStateOf(1) }
    var materiaSeleccionada by remember { mutableStateOf("") }

    val currentThemeMode = LocalAppThemeMode.current
    val systemDark = isSystemInDarkTheme()
    val isLightMode = currentThemeMode == AppThemeMode.LIGHT || (currentThemeMode == AppThemeMode.SYSTEM && !systemDark)
    val cardBg = if (isLightMode) MaterialTheme.colorScheme.surface.copy(alpha = 0.8f) else Color(0x33000000)
    val cardBorder = if (isLightMode) BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)) else BorderStroke(1.dp, Color(0x33FFFFFF))

    PortalDrawerLayout(
        currentScreenTitle = if (currentScreen == 1) "Mis Clases" else materiaSeleccionada,
        nombreProfesor = nombreProfesor,
        onLogoutOverride = onBack
    ) { openDrawer ->
        Box(modifier = Modifier.fillMaxSize()) {
            FondoLavaBackground(modifier = Modifier.fillMaxSize())

            when (currentScreen) {
                1 -> ListaClasesProfesorScreen(
                    nombreProfesor = nombreProfesor,
                    onOpenDrawer = openDrawer,
                    onMateriaSeleccionada = { materia ->
                        materiaSeleccionada = materia
                        currentScreen = 2
                    },
                    cardBg = cardBg,
                    cardBorder = cardBorder
                )
                2 -> GestionMateriaProfesorScreen(
                    materia = materiaSeleccionada,
                    nombreProfesor = nombreProfesor,
                    onOpenDrawer = openDrawer,
                    cardBg = cardBg,
                    cardBorder = cardBorder
                ) { currentScreen = 1 }
            }
        }
    }
}

@Composable
fun ListaClasesProfesorScreen(
    nombreProfesor: String,
    onOpenDrawer: () -> Unit,
    onMateriaSeleccionada: (String) -> Unit,
    cardBg: Color,
    cardBorder: BorderStroke
) {
    val institutionalColor = getInstitutionalColor()
    val textColor = MaterialTheme.colorScheme.onBackground

    Column(
        modifier = Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState())
    ) {
        TopHeader(title = "Mis Clases", onOpenDrawer = onOpenDrawer)

        Column(modifier = Modifier.padding(horizontal = 24.dp)) {
            Text(
                text = "Docente: $nombreProfesor",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.tertiary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Materias asignadas para el docente
            val materiasAsignadas = listOf("Base de Datos", "Cálculo Integral", "Inglés V", "Probabilidad y Estadística")

            materiasAsignadas.forEach { materia ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .clickable { onMateriaSeleccionada(materia) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    border = cardBorder
                ) {
                    Column {
                        Box(modifier = Modifier.fillMaxWidth().background(institutionalColor).padding(16.dp)) {
                            Column {
                                Text(
                                    text = materia,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    lineHeight = 26.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = "Aula: Edificio C - 302", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFFFB4A2))
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Class, contentDescription = null, tint = textColor, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "Horario por definir", color = textColor, fontSize = 14.sp)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun GestionMateriaProfesorScreen(
    materia: String,
    nombreProfesor: String,
    onOpenDrawer: () -> Unit,
    cardBg: Color,
    cardBorder: BorderStroke,
    onBack: () -> Unit
) {
    var listaAnuncios by remember { mutableStateOf<List<Anuncio>>(emptyList()) }
    var mostrarDialogo by remember { mutableStateOf(value = false) }
    var anuncioEnEdicion by remember { mutableStateOf<Anuncio?>(null) }
    var textoNuevoAnuncio by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()

    val institutionalColor = getInstitutionalColor()
    val currentThemeMode = LocalAppThemeMode.current
    val systemDark = isSystemInDarkTheme()
    val isLightMode = currentThemeMode == AppThemeMode.LIGHT || (currentThemeMode == AppThemeMode.SYSTEM && !systemDark)

    val loadAnuncios = {
        coroutineScope.launch(Dispatchers.IO) {
            try {
                val response = RetrofitClient.authApi.getAnuncios(materia = materia, grupo = null)
                if (response.isSuccessful && response.body()?.success == true) {
                    val dtos = response.body()?.data ?: emptyList()
                    val mapped = dtos.map { dto ->
                        Anuncio(
                            id = dto.id,
                            autor = dto.autor,
                            fecha = dto.fecha,
                            mensaje = dto.mensaje
                        )
                    }
                    withContext(Dispatchers.Main) {
                        listaAnuncios = mapped
                    }
                }
            } catch (_: Exception) {}
        }
    }

    LaunchedEffect(materia) {
        loadAnuncios()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().systemBarsPadding()) {
            TopHeader(title = materia, onOpenDrawer = onOpenDrawer)

            Column(modifier = Modifier.padding(horizontal = 24.dp).verticalScroll(rememberScrollState())) {
                TextButton(
                    onClick = onBack,
                    modifier = Modifier.padding(bottom = 8.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Regresar",
                        tint = MaterialTheme.colorScheme.tertiary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Volver a Mis Clases",
                        color = MaterialTheme.colorScheme.tertiary,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                listaAnuncios.forEach { anuncio ->
                    CardAnuncioProfesor(
                        anuncio = anuncio,
                        cardBg = cardBg,
                        cardBorder = cardBorder,
                        institutionalColor = institutionalColor,
                        onEdit = { 
                            anuncioEnEdicion = it
                            textoNuevoAnuncio = it.mensaje
                            mostrarDialogo = true 
                        },
                        onDelete = { 
                            coroutineScope.launch(Dispatchers.IO) {
                                try {
                                    withContext(Dispatchers.Main) {
                                        loadAnuncios()
                                    }
                                } catch (_: Exception) {}
                            }
                        },
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }

        FloatingActionButton(
            onClick = { anuncioEnEdicion = null; textoNuevoAnuncio = ""; mostrarDialogo = true },
            containerColor = institutionalColor,
            modifier = Modifier.align(Alignment.BottomEnd).padding(24.dp),
        ) { Icon(Icons.Default.Add, contentDescription = "Nuevo Anuncio", tint = Color.White) }
    }

    if (mostrarDialogo) {
        AlertDialog(
            onDismissRequest = { mostrarDialogo = false },
            containerColor = if (isLightMode) MaterialTheme.colorScheme.surface else Color(0xFF2C2C2C),
            title = { Text(if (anuncioEnEdicion == null) "Crear Anuncio" else "Editar Anuncio", color = MaterialTheme.colorScheme.onSurface) },
            text = {
                OutlinedTextField(
                    value = textoNuevoAnuncio, onValueChange = { textoNuevoAnuncio = it },
                    modifier = Modifier.fillMaxWidth().height(150.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                    ),
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (textoNuevoAnuncio.isNotBlank()) {
                        coroutineScope.launch(Dispatchers.IO) {
                            try {
                                RetrofitClient.authApi.postAnuncio(
                                    AnuncioPostRequest(
                                        autor = nombreProfesor,
                                        mensaje = textoNuevoAnuncio,
                                        materia = materia,
                                        grupo = ""
                                    )
                                )
                                withContext(Dispatchers.Main) {
                                    mostrarDialogo = false
                                    loadAnuncios()
                                }
                            } catch (_: Exception) {}
                        }
                    }
                }, colors = ButtonDefaults.buttonColors(containerColor = institutionalColor)) { Text("Publicar", color = Color.White) }
            },
            dismissButton = { TextButton(onClick = { mostrarDialogo = false }) { Text("Cancelar", color = MaterialTheme.colorScheme.onSurface) } },
        )
    }
}

@Composable
fun CardAnuncioProfesor(
    anuncio: Anuncio,
    cardBg: Color,
    cardBorder: BorderStroke,
    institutionalColor: Color,
    onEdit: (Anuncio) -> Unit,
    onDelete: () -> Unit
) {
    val textColor = MaterialTheme.colorScheme.onBackground
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = cardBg), border = cardBorder) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(institutionalColor), contentAlignment = Alignment.Center) { Text(anuncio.autor.take(1), color = Color.White, fontWeight = FontWeight.Bold) }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(anuncio.autor, color = textColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(anuncio.fecha, color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
                    }
                }
                Row {
                    IconButton(onClick = { onEdit(anuncio) }, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Edit, contentDescription = null, tint = textColor, modifier = Modifier.size(20.dp)) }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFFF8A8A), modifier = Modifier.size(20.dp)) }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(anuncio.mensaje, color = textColor, fontSize = 14.sp)
        }
    }
}
