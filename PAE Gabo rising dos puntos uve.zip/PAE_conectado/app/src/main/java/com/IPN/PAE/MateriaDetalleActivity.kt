package com.IPN.PAE

import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.IPN.PAE.ui.theme.AppThemeMode
import com.IPN.PAE.ui.theme.LocalAppThemeMode
import com.IPN.PAE.ui.theme.getInstitutionalColor
import com.IPN.PAE.ui.theme.MyApplicationTheme
import androidx.compose.foundation.isSystemInDarkTheme
import com.IPN.PAE.api.RetrofitClient
import com.IPN.PAE.api.Videollamadas
import com.IPN.PAE.api.horaCorta
import com.IPN.PAE.api.models.PaeSesionVideollamada
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MateriaDetalleActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Recibiríamos el nombre de la materia a través del Intent en un futuro
        val nombreMateria = intent.getStringExtra("NOMBRE_MATERIA") ?: "Base de Datos"
        val nombreProfesor = intent.getStringExtra("NOMBRE_PROFESOR") ?: "Profesor Asignado"
        val idCurso = intent.getIntExtra("ID_CURSO", -1).takeIf { it > 0 }

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MateriaDetalleScreen(
                    nombreMateria = nombreMateria,
                    nombreProfesor = nombreProfesor,
                    idCurso = idCurso,
                ) { finish() }
            }
        }
    }
}

@Composable
fun MateriaDetalleScreen(nombreMateria: String, nombreProfesor: String, idCurso: Int?, onBack: () -> Unit) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("Novedades", "Tareas", "En vivo")

    Box(modifier = Modifier.fillMaxSize()) {
        FondoLavaBackground(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            // --- HEADER CORREGIDO ---
            val institutionalColor = getInstitutionalColor()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(institutionalColor)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack, 
                    colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack, 
                        contentDescription = "Regresar", 
                        modifier = Modifier.size(28.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = nombreMateria,
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = nombreProfesor,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFFFB4A2)
                    )
                }
            }

            // --- TAB ROW (Pestañas) ---
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = Color.Transparent,
                contentColor = Color.White,
                indicator = { tabPositions ->
                    if (selectedTabIndex < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                            color = Color(0xFFFFB4A2),
                            height = 3.dp
                        )
                    }
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = { 
                            Text(
                                text = title, 
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) Color.White else Color(0x99FFFFFF)
                            ) 
                        }
                    )
                }
            }

            // --- CONTENIDO DE LAS PESTAÑAS ---
            Box(modifier = Modifier.weight(1f)) {
                when (selectedTabIndex) {
                    0 -> PestañaNovedades(nombreMateria)
                    1 -> PestañaTareas(idCurso)
                    2 -> PestañaVideollamada(idCurso)
                }
            }
        }
    }
}

// ==========================================
// PESTAÑA 1: NOVEDADES / MURO DEL PROFESOR
// ==========================================
@Composable
fun PestañaNovedades(nombreMateria: String) {
    var listaAnuncios by remember { mutableStateOf<List<Anuncio>>(emptyList()) }
    var isLoading by remember { mutableStateOf(value = true) }

    LaunchedEffect(nombreMateria) {
        withContext(Dispatchers.IO) {
            try {
                val response = RetrofitClient.authApi.getAnuncios(materia = nombreMateria, grupo = null)
                if (response.isSuccessful && response.body()?.success == true) {
                    val dtos = response.body()?.data ?: emptyList()
                    val mapped = dtos.map { dto ->
                        Anuncio(
                            id = dto.id,
                            autor = dto.autor,
                            fecha = dto.fecha,
                            mensaje = dto.mensaje,
                            idArchivo = dto.idArchivo,
                            nombreArchivo = dto.nombreArchivo
                        )
                    }
                    withContext(Dispatchers.Main) {
                        listaAnuncios = mapped
                        isLoading = false
                    }
                } else {
                    withContext(Dispatchers.Main) { isLoading = false }
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) { isLoading = false }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center),
                color = Color(0xFFFFB4A2),
            )
        } else if (listaAnuncios.isEmpty()) {
            Text(
                text = "Aún no hay anuncios en esta clase.",
                color = Color.Gray,
                modifier = Modifier.align(Alignment.Center),
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                listaAnuncios.forEach { anuncio ->
                    CardAnuncio(
                        autor = anuncio.autor,
                        fecha = anuncio.fecha,
                        mensaje = anuncio.mensaje,
                        idArchivo = anuncio.idArchivo,
                        nombreArchivo = anuncio.nombreArchivo,
                    )
                }
            }
        }
    }
}

@Composable
fun CardAnuncio(autor: String, fecha: String, mensaje: String, idArchivo: Int? = null, nombreArchivo: String? = null) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
        border = BorderStroke(1.dp, Color(0x33FFFFFF)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Avatar circular simulado
                val currentThemeMode = LocalAppThemeMode.current
                val systemDark = isSystemInDarkTheme()
                val isLightMode = currentThemeMode == AppThemeMode.LIGHT || (currentThemeMode == AppThemeMode.SYSTEM && !systemDark)
                val institutionalColor = if (isLightMode) Color(0xFF1B2A3A) else Color(0xFF7D2242)

                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(institutionalColor),
                    contentAlignment = Alignment.Center
                ) {
                    Text(autor.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = autor, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(text = fecha, color = Color(0xFFA0A0A0), fontSize = 12.sp)
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = mensaje,
                color = Color(0xFFE0E0E0),
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
            if (idArchivo != null) {
                Spacer(modifier = Modifier.height(12.dp))
                ArchivoDeAnuncio(idArchivo = idArchivo, nombre = nombreArchivo, textColor = Color(0xFFE0E0E0))
            }
            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0x22FFFFFF))

            // Sección para comentarios de alumnos (Simulado)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Comentarios", tint = Color(0xFFA0A0A0), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Agregar un comentario de clase...", color = Color(0xFFA0A0A0), fontSize = 12.sp)
            }
        }
    }
}

// PESTAÑA 2: TAREAS → ver TareasAlumno.kt

// ==========================================
// PESTAÑA 3: VIDEOLLAMADA Y ASISTENCIA
// ==========================================
@Composable
fun PestañaVideollamada(idCurso: Int?) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var cargando by remember { mutableStateOf(true) }
    var uniendose by remember { mutableStateOf(false) }
    var sesion by remember { mutableStateOf<PaeSesionVideollamada?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var canalEnLlamada by remember { mutableStateOf<String?>(null) }

    val consultar: () -> Unit = {
        if (idCurso == null) {
            cargando = false
            error = "No se pudo identificar la clase. Regresa e intenta de nuevo."
        } else {
            cargando = true
            error = null
            scope.launch {
                Videollamadas.consultar(idCurso)
                    .onSuccess { sesion = it }
                    .onFailure { error = it.message }
                cargando = false
            }
        }
    }

    LaunchedEffect(idCurso) { consultar() }

    val canal = canalEnLlamada
    if (canal != null && idCurso != null) {
        // Al salir de la llamada (colgar, cambiar de pestaña o cerrar la pantalla) se registra la salida.
        DisposableEffect(canal) {
            onDispose { Videollamadas.salir(idCurso) }
        }
        BackHandler { canalEnLlamada = null }
        AgoraVideoCallContainer(
            channelName = canal,
            onEndCall = {
                canalEnLlamada = null
                consultar()
            }
        )
        return
    }

    val currentThemeMode = LocalAppThemeMode.current
    val systemDark = isSystemInDarkTheme()
    val isLightMode = currentThemeMode == AppThemeMode.LIGHT || (currentThemeMode == AppThemeMode.SYSTEM && !systemDark)
    val institutionalColor = if (isLightMode) Color(0xFF1B2A3A) else Color(0xFF7D2242)
    val enVivo = sesion?.enVivo == true

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.VideoCall,
            contentDescription = "Videollamada",
            tint = Color(0xFFFFB4A2),
            modifier = Modifier.size(80.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Aula Virtual (En Vivo)",
            style = MaterialTheme.typography.titleLarge,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))

        when {
            cargando -> {
                Spacer(modifier = Modifier.height(16.dp))
                CircularProgressIndicator(color = Color(0xFFFFB4A2))
            }
            enVivo -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color(0xFFE53935)))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = horaCorta(sesion?.inicio)?.let { "Clase en vivo desde las $it" } ?: "Clase en vivo",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Tu asistencia se registrará al unirte. Después de 10 minutos cuenta como retardo.",
                    color = Color(0xFFE0E0E0),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Spacer(modifier = Modifier.height(32.dp))
                Button(
                    onClick = {
                        if (idCurso == null || uniendose) return@Button
                        uniendose = true
                        error = null
                        scope.launch {
                            Videollamadas.unirse(idCurso)
                                .onSuccess { r ->
                                    val estado = r.asistencia?.uppercase() ?: "PRESENTE"
                                    Toast.makeText(context, "Asistencia registrada: $estado", Toast.LENGTH_LONG).show()
                                    canalEnLlamada = r.canal
                                }
                                .onFailure { e ->
                                    error = e.message
                                    // 409: el profesor todavía no inicia (o ya terminó); se refresca el estado.
                                    if (e is Videollamadas.ClaseNoIniciada) sesion = null
                                }
                            uniendose = false
                        }
                    },
                    enabled = !uniendose,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = institutionalColor)
                ) {
                    if (uniendose) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp, color = Color.White)
                    } else {
                        Text("UNIRSE", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
            else -> {
                Text(
                    text = "El profesor aún no inicia la clase",
                    color = Color(0xFFE0E0E0),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                horaCorta(sesion?.inicio)?.let { hora ->
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Programada para las $hora", color = Color(0xFFA0A0A0), fontSize = 13.sp)
                }
                Spacer(modifier = Modifier.height(32.dp))
                OutlinedButton(
                    onClick = consultar,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0x66FFFFFF))
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ACTUALIZAR", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }

        error?.let {
            Spacer(modifier = Modifier.height(16.dp))
            Text(it, color = Color(0xFFFF8A8A), textAlign = TextAlign.Center, fontSize = 13.sp)
        }
    }
}
