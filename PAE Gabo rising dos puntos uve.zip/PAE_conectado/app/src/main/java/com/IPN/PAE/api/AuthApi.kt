package com.IPN.PAE.api

import com.IPN.PAE.api.models.*
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

/**
 * Interfaz de Retrofit para llamadas de autenticación y servicios académicos.
 */
interface AuthApi {

    @POST("api/auth/login.php")
    suspend fun login(
        @Body request: LoginRequest
    ): Response<LoginResponse>

    @GET("api/materias/get.php")
    suspend fun getMaterias(
        @Query("grupo") grupo: String
    ): Response<MateriaApiResponse>

    @GET("api/calificaciones/get.php")
    suspend fun getCalificaciones(
        @Query("boleta") boleta: String
    ): Response<CalificacionApiResponse>

    @GET("api/anuncios/index.php")
    suspend fun getAnuncios(
        @Query("materia") materia: String?,
        @Query("grupo") grupo: String?
    ): Response<AnuncioApiResponse>

    @POST("api/anuncios/index.php")
    suspend fun postAnuncio(
        @Body request: AnuncioPostRequest
    ): Response<Any>

    /**
     * Sube un archivo adjunto de un anuncio (POST /archivos, categoria "anuncio")
     * y regresa el id_archivo, o un error con mensaje legible.
     */
    suspend fun subirArchivoAnuncio(
        materia: String,
        grupo: String?,
        nombre: String,
        mime: String,
        bytes: ByteArray
    ): Result<Int>
}
