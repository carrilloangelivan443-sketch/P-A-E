package com.IPN.PAE

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit
import com.IPN.PAE.ui.theme.AppThemeMode
import com.IPN.PAE.ui.theme.LocalAppThemeMode
import com.IPN.PAE.ui.theme.MyApplicationTheme
import com.IPN.PAE.ui.theme.getInstitutionalColor
import com.IPN.PAE.api.RetrofitClient
import com.IPN.PAE.api.Videollamadas
import com.IPN.PAE.api.horaCorta
import com.IPN.PAE.api.models.PaeAsistenciaAlumno
import com.IPN.PAE.api.models.PaeSesionVideollamada
import com.IPN.PAE.api.models.PaeTarea
import com.IPN.PAE.api.models.AnuncioPostRequest
import com.IPN.PAE.api.models.MateriaDto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Estructura de datos
data class Anuncio(
    val id: String,
    val autor: String,
    val fecha: String,
    var mensaje: String,
    val idArchivo: Int? = null,
    val nombreArchivo: String? = null,
)

class PortalProfesoresActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val sharedPreferences = getSharedPreferences("SesionIPN", MODE_PRIVATE)
        val intentNombre = intent.getStringExtra("NOMBRE_PROFESOR")

        val nombreProfesor = if (!intentNombre.isNullOrBlank()) {
            sharedPreferences.edit {
                putString("nombre_profesor", intentNombre)
                putBoolean("es_profesor", true)
            }
            intentNombre
        } else {
            sharedPreferences.getString("nombre_profesor", "")?.takeIf { it.isNotBlank() } ?: "Docente"
        }

        setContent {
            MyApplicationTheme {
                PortalProfesoresApp(
                    nombreProfesor = nombreProfesor,
                ) {
                    sharedPreferences.edit { clear() }
                    finish()
                }
            }
        }
    }
}

@Composable
fun PortalProfesoresApp(nombreProfesor: String, onBack: () -> Unit) {
    var currentScreen by remember { mutableStateOf(1) }
    var materiaSeleccionada by remember { mutableStateOf("") }
    var idCursoSeleccionado by remember { mutableStateOf<Int?>(null) }

    val currentThemeMode = LocalAppThemeMode.current
    val systemDark = isSystemInDarkTheme()
    val isLightMode = currentThemeMode == AppThemeMode.LIGHT || (currentThemeMode == AppThemeMode.SYSTEM && !systemDark)
    val cardBg = if (isLightMode) MaterialTheme.colorScheme.surface.copy(alpha = 0.8f) else Color(0x33000000)
    val cardBorder = if (isLightMode) BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)) else BorderStroke(1.dp, Color(0x33FFFFFF))

    PortalDrawerLayout(
        currentScreenTitle = if (currentScreen == 1) "Mis Clases" else materiaSeleccionada,
        nombreProfesor = nombreProfesor,
        onLogoutOverride = onBack
    ) { openDrawer ->
        Box(modifier = Modifier.fillMaxSize()) {
            FondoLavaBackground(modifier = Modifier.fillMaxSize())

            when (currentScreen) {
                1 -> ListaClasesProfesorScreen(
                    nombreProfesor = nombreProfesor,
                    onOpenDrawer = openDrawer,
                    onMateriaSeleccionada = { curso ->
                        materiaSeleccionada = curso.nombre
                        idCursoSeleccionado = curso.id.toIntOrNull()
                        currentScreen = 2
                    },
                    cardBg = cardBg,
                    cardBorder = cardBorder
                )
                2 -> GestionMateriaProfesorScreen(
                    materia = materiaSeleccionada,
                    idCurso = idCursoSeleccionado,
                    nombreProfesor = nombreProfesor,
                    onOpenDrawer = openDrawer,
                    cardBg = cardBg,
                    cardBorder = cardBorder
                ) { currentScreen = 1 }
            }
        }
    }
}

@Composable
fun ListaClasesProfesorScreen(
    nombreProfesor: String,
    onOpenDrawer: () -> Unit,
    onMateriaSeleccionada: (MateriaDto) -> Unit,
    cardBg: Color,
    cardBorder: BorderStroke
) {
    val institutionalColor = getInstitutionalColor()
    val textColor = MaterialTheme.colorScheme.onBackground

    Column(
        modifier = Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState())
    ) {
        TopHeader(title = "Mis Clases", onOpenDrawer = onOpenDrawer)

        Column(modifier = Modifier.padding(horizontal = 24.dp)) {
            Text(
                text = "Docente: $nombreProfesor",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.tertiary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Clases del docente, desde la API del servidor
            var materiasAsignadas by remember { mutableStateOf<List<MateriaDto>>(emptyList()) }
            var cargandoClases by remember { mutableStateOf(true) }
            LaunchedEffect(Unit) {
                val lista = withContext(Dispatchers.IO) {
                    try {
                        RetrofitClient.authApi.getMaterias("").body()?.data ?: emptyList()
                    } catch (_: Exception) {
                        emptyList()
                    }
                }
                materiasAsignadas = lista
                cargandoClases = false
            }

            if (cargandoClases) {
                Text(text = "Cargando clases...", color = textColor, modifier = Modifier.padding(vertical = 8.dp))
            } else if (materiasAsignadas.isEmpty()) {
                Text(text = "No tienes clases asignadas.", color = textColor, modifier = Modifier.padding(vertical = 8.dp))
            }

            materiasAsignadas.forEach { curso ->
                val materia = curso.nombre
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .clickable { onMateriaSeleccionada(curso) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    border = cardBorder
                ) {
                    Column {
                        Box(modifier = Modifier.fillMaxWidth().background(institutionalColor).padding(16.dp)) {
                            Column {
                                Text(
                                    text = materia,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    lineHeight = 26.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = "Aula: ${curso.aula.ifBlank { "Por definir" }}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFFFB4A2))
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Class, contentDescription = null, tint = textColor, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = curso.horario.ifBlank { "Horario por definir" }, color = textColor, fontSize = 14.sp)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun GestionMateriaProfesorScreen(
    materia: String,
    idCurso: Int?,
    nombreProfesor: String,
    onOpenDrawer: () -> Unit,
    cardBg: Color,
    cardBorder: BorderStroke,
    onBack: () -> Unit
) {
    var listaAnuncios by remember { mutableStateOf<List<Anuncio>>(emptyList()) }
    var mostrarDialogo by remember { mutableStateOf(value = false) }
    var anuncioEnEdicion by remember { mutableStateOf<Anuncio?>(null) }
    var textoNuevoAnuncio by remember { mutableStateOf("") }
    // Adjunto del diálogo: un archivo nuevo elegido, o el que ya traía el anuncio que se edita.
    var archivoElegido by remember { mutableStateOf<ArchivoLocal?>(null) }
    var archivoExistente by remember { mutableStateOf<Pair<Int, String?>?>(null) }
    var publicando by remember { mutableStateOf(false) }
    var errorDialogo by remember { mutableStateOf<String?>(null) }
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    val selectorArchivo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val archivo = try { ArchivosAdjuntos.describir(context, uri) } catch (_: Exception) { null }
            when {
                archivo == null -> errorDialogo = "No se pudo leer el archivo elegido"
                ArchivosAdjuntos.validarTamano(archivo) != null -> errorDialogo = ArchivosAdjuntos.validarTamano(archivo)
                else -> { archivoElegido = archivo; archivoExistente = null; errorDialogo = null }
            }
        }
    }

    val abrirDialogo = { anuncio: Anuncio? ->
        anuncioEnEdicion = anuncio
        textoNuevoAnuncio = anuncio?.mensaje.orEmpty()
        archivoElegido = null
        archivoExistente = anuncio?.idArchivo?.let { it to anuncio.nombreArchivo }
        errorDialogo = null
        publicando = false
        mostrarDialogo = true
    }

    val institutionalColor = getInstitutionalColor()
    val currentThemeMode = LocalAppThemeMode.current
    val systemDark = isSystemInDarkTheme()
    val isLightMode = currentThemeMode == AppThemeMode.LIGHT || (currentThemeMode == AppThemeMode.SYSTEM && !systemDark)

    val loadAnuncios = {
        coroutineScope.launch(Dispatchers.IO) {
            try {
                val response = RetrofitClient.authApi.getAnuncios(materia = materia, grupo = null)
                if (response.isSuccessful && response.body()?.success == true) {
                    val dtos = response.body()?.data ?: emptyList()
                    val mapped = dtos.map { dto ->
                        Anuncio(
                            id = dto.id,
                            autor = dto.autor,
                            fecha = dto.fecha,
                            mensaje = dto.mensaje,
                            idArchivo = dto.idArchivo,
                            nombreArchivo = dto.nombreArchivo
                        )
                    }
                    withContext(Dispatchers.Main) {
                        listaAnuncios = mapped
                    }
                }
            } catch (_: Exception) {}
        }
    }

    LaunchedEffect(materia) {
        loadAnuncios()
    }

    // ---------- Clase en vivo ----------
    var sesionVideo by remember { mutableStateOf<PaeSesionVideollamada?>(null) }
    var cargandoVideo by remember { mutableStateOf(true) }
    var ocupadoVideo by remember { mutableStateOf(false) }
    var errorVideo by remember { mutableStateOf<String?>(null) }
    var canalEnLlamada by remember { mutableStateOf<String?>(null) }
    var preguntarFinalizar by remember { mutableStateOf(false) }
    // Asistencia de la última sesión finalizada
    var idSesionAsistencia by remember { mutableStateOf<Int?>(null) }
    var listaAsistencia by remember { mutableStateOf<List<PaeAsistenciaAlumno>?>(null) }
    var cargandoAsistencia by remember { mutableStateOf(false) }
    var errorAsistencia by remember { mutableStateOf<String?>(null) }
    // Tarea cuyas entregas se están revisando (null = vista normal de la clase)
    var tareaEntregas by remember { mutableStateOf<PaeTarea?>(null) }

    val consultarVideo: () -> Unit = {
        if (idCurso == null) {
            cargandoVideo = false
            errorVideo = "No se pudo identificar la clase"
        } else {
            cargandoVideo = true
            coroutineScope.launch {
                Videollamadas.consultar(idCurso)
                    .onSuccess { sesionVideo = it; errorVideo = null }
                    .onFailure { errorVideo = it.message }
                cargandoVideo = false
            }
        }
    }
    LaunchedEffect(idCurso) { consultarVideo() }

    val cargarAsistencia: (Int) -> Unit = { idSesion ->
        idSesionAsistencia = idSesion
        cargandoAsistencia = true
        errorAsistencia = null
        coroutineScope.launch {
            Videollamadas.asistencia(idSesion)
                .onSuccess { listaAsistencia = it }
                .onFailure { errorAsistencia = it.message }
            cargandoAsistencia = false
        }
    }

    val iniciarClase: () -> Unit = {
        if (idCurso != null && !ocupadoVideo) {
            ocupadoVideo = true
            errorVideo = null
            coroutineScope.launch {
                Videollamadas.iniciar(idCurso)
                    .onSuccess { s ->
                        sesionVideo = s
                        canalEnLlamada = s.canal
                    }
                    .onFailure { errorVideo = it.message }
                ocupadoVideo = false
            }
        }
    }

    val finalizarClase: () -> Unit = {
        if (idCurso != null && !ocupadoVideo) {
            ocupadoVideo = true
            errorVideo = null
            val idSesionActual = sesionVideo?.id
            coroutineScope.launch {
                Videollamadas.finalizar(idCurso)
                    .onSuccess { r ->
                        sesionVideo = null
                        Toast.makeText(context, r.mensaje ?: "Clase finalizada", Toast.LENGTH_SHORT).show()
                        (r.idSesion ?: idSesionActual)?.let(cargarAsistencia)
                    }
                    .onFailure { e ->
                        errorVideo = e.message
                        consultarVideo()
                    }
                ocupadoVideo = false
            }
        }
    }

    val canal = canalEnLlamada
    if (canal != null) {
        // Salir de la llamada no termina la clase: se pregunta si se desea finalizar.
        val salirDeLlamada = {
            canalEnLlamada = null
            preguntarFinalizar = true
        }
        BackHandler(onBack = salirDeLlamada)
        Box(modifier = Modifier.fillMaxSize().systemBarsPadding()) {
            AgoraVideoCallContainer(channelName = canal, onEndCall = salirDeLlamada)
        }
        return
    }

    // ---------- Entregas de una tarea (pantalla aparte) ----------
    val tareaAbierta = tareaEntregas
    if (tareaAbierta != null) {
        BackHandler { tareaEntregas = null }
        Column(modifier = Modifier.fillMaxSize().systemBarsPadding()) {
            TopHeader(title = materia, onOpenDrawer = onOpenDrawer)
            PantallaEntregasProfesor(
                tarea = tareaAbierta,
                cardBg = cardBg,
                cardBorder = cardBorder,
                institutionalColor = institutionalColor,
                onBack = { tareaEntregas = null }
            )
        }
        return
    }

    if (preguntarFinalizar) {
        AlertDialog(
            onDismissRequest = { preguntarFinalizar = false },
            containerColor = if (isLightMode) MaterialTheme.colorScheme.surface else Color(0xFF2C2C2C),
            title = { Text("Saliste de la clase", color = MaterialTheme.colorScheme.onSurface) },
            text = {
                Text(
                    "La clase sigue en vivo para los alumnos. ¿Quieres finalizarla y ver la asistencia?",
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            confirmButton = {
                Button(
                    onClick = { preguntarFinalizar = false; finalizarClase() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))
                ) { Text("Finalizar clase", color = Color.White) }
            },
            dismissButton = {
                TextButton(onClick = { preguntarFinalizar = false }) {
                    Text("Mantener en vivo", color = MaterialTheme.colorScheme.onSurface)
                }
            }
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().systemBarsPadding()) {
            TopHeader(title = materia, onOpenDrawer = onOpenDrawer)

            Column(modifier = Modifier.padding(horizontal = 24.dp).verticalScroll(rememberScrollState())) {
                TextButton(
                    onClick = onBack,
                    modifier = Modifier.padding(bottom = 8.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Regresar",
                        tint = MaterialTheme.colorScheme.tertiary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Volver a Mis Clases",
                        color = MaterialTheme.colorScheme.tertiary,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                TarjetaClaseEnVivo(
                    sesion = sesionVideo,
                    cargando = cargandoVideo,
                    ocupado = ocupadoVideo,
                    error = errorVideo,
                    cardBg = cardBg,
                    cardBorder = cardBorder,
                    institutionalColor = institutionalColor,
                    onIniciar = iniciarClase,
                    onFinalizar = finalizarClase,
                    onActualizar = consultarVideo
                )
                Spacer(modifier = Modifier.height(12.dp))

                if (idSesionAsistencia != null) {
                    TarjetaAsistencia(
                        lista = listaAsistencia,
                        cargando = cargandoAsistencia,
                        error = errorAsistencia,
                        cardBg = cardBg,
                        cardBorder = cardBorder,
                        onCerrar = { idSesionAsistencia = null; listaAsistencia = null },
                        onReintentar = { idSesionAsistencia?.let(cargarAsistencia) }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                TarjetaTareasProfesor(
                    idCurso = idCurso,
                    cardBg = cardBg,
                    cardBorder = cardBorder,
                    institutionalColor = institutionalColor,
                    onVerEntregas = { tareaEntregas = it }
                )
                Spacer(modifier = Modifier.height(12.dp))

                listaAnuncios.forEach { anuncio ->
                    CardAnuncioProfesor(
                        anuncio = anuncio,
                        cardBg = cardBg,
                        cardBorder = cardBorder,
                        institutionalColor = institutionalColor,
                        onEdit = { abrirDialogo(it) },
                        onDelete = { 
                            coroutineScope.launch(Dispatchers.IO) {
                                try {
                                    withContext(Dispatchers.Main) {
                                        loadAnuncios()
                                    }
                                } catch (_: Exception) {}
                            }
                        },
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }

        FloatingActionButton(
            onClick = { abrirDialogo(null) },
            containerColor = institutionalColor,
            modifier = Modifier.align(Alignment.BottomEnd).padding(24.dp),
        ) { Icon(Icons.Default.Add, contentDescription = "Nuevo Anuncio", tint = Color.White) }
    }

    if (mostrarDialogo) {
        AlertDialog(
            onDismissRequest = { if (!publicando) mostrarDialogo = false },
            containerColor = if (isLightMode) MaterialTheme.colorScheme.surface else Color(0xFF2C2C2C),
            title = { Text(if (anuncioEnEdicion == null) "Crear Anuncio" else "Editar Anuncio", color = MaterialTheme.colorScheme.onSurface) },
            text = {
                val colorTexto = MaterialTheme.colorScheme.onSurface
                Column {
                    OutlinedTextField(
                        value = textoNuevoAnuncio, onValueChange = { textoNuevoAnuncio = it },
                        enabled = !publicando,
                        modifier = Modifier.fillMaxWidth().height(150.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = colorTexto,
                            unfocusedTextColor = colorTexto
                        ),
                    )
                    Spacer(Modifier.height(12.dp))
                    val elegido = archivoElegido
                    val existente = archivoExistente
                    when {
                        elegido != null -> FilaArchivoAdjunto(
                            nombre = elegido.nombre,
                            detalle = ArchivosAdjuntos.tamanoLegible(elegido.tamano),
                            textColor = colorTexto,
                            onQuitar = if (publicando) null else ({ archivoElegido = null })
                        )
                        existente != null -> FilaArchivoAdjunto(
                            nombre = existente.second ?: "Archivo adjunto",
                            detalle = "Ya adjunto",
                            textColor = colorTexto,
                            onQuitar = if (publicando) null else ({ archivoExistente = null })
                        )
                        else -> OutlinedButton(
                            onClick = { selectorArchivo.launch(arrayOf("*/*")) },
                            enabled = !publicando,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.AttachFile, contentDescription = null, tint = colorTexto, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Adjuntar archivo", color = colorTexto)
                        }
                    }
                    errorDialogo?.let {
                        Spacer(Modifier.height(8.dp))
                        Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (textoNuevoAnuncio.isBlank() || publicando) return@Button
                    publicando = true
                    errorDialogo = null
                    val archivo = archivoElegido
                    val idExistente = archivoExistente?.first
                    val texto = textoNuevoAnuncio
                    coroutineScope.launch(Dispatchers.IO) {
                        val error: String? = try {
                            // 1) Si hay archivo nuevo, se sube primero para obtener su id_archivo.
                            val idArchivo: Int? = if (archivo != null) {
                                val bytes = ArchivosAdjuntos.leerBytes(context, archivo)
                                RetrofitClient.authApi
                                    .subirArchivoAnuncio(materia, null, archivo.nombre, archivo.mime, bytes)
                                    .getOrThrow()
                            } else idExistente
                            // 2) Se publica el anuncio con el id del archivo (si hay).
                            val r = RetrofitClient.authApi.postAnuncio(
                                AnuncioPostRequest(
                                    autor = nombreProfesor,
                                    mensaje = texto,
                                    materia = materia,
                                    grupo = "",
                                    idArchivo = idArchivo
                                )
                            )
                            if (r.isSuccessful) null else "No se pudo publicar el anuncio (${r.code()})"
                        } catch (e: Exception) {
                            e.message ?: "Error de conexión"
                        }
                        withContext(Dispatchers.Main) {
                            publicando = false
                            if (error == null) {
                                mostrarDialogo = false
                                Toast.makeText(context, "Anuncio publicado", Toast.LENGTH_SHORT).show()
                                loadAnuncios()
                            } else {
                                errorDialogo = error
                            }
                        }
                    }
                }, enabled = !publicando, colors = ButtonDefaults.buttonColors(containerColor = institutionalColor)) {
                    if (publicando) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                    } else {
                        Text("Publicar", color = Color.White)
                    }
                }
            },
            dismissButton = { TextButton(onClick = { mostrarDialogo = false }, enabled = !publicando) { Text("Cancelar", color = MaterialTheme.colorScheme.onSurface) } },
        )
    }
}

@Composable
fun CardAnuncioProfesor(
    anuncio: Anuncio,
    cardBg: Color,
    cardBorder: BorderStroke,
    institutionalColor: Color,
    onEdit: (Anuncio) -> Unit,
    onDelete: () -> Unit
) {
    val textColor = MaterialTheme.colorScheme.onBackground
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = cardBg), border = cardBorder) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(institutionalColor), contentAlignment = Alignment.Center) { Text(anuncio.autor.take(1), color = Color.White, fontWeight = FontWeight.Bold) }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(anuncio.autor, color = textColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(anuncio.fecha, color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
                    }
                }
                Row {
                    IconButton(onClick = { onEdit(anuncio) }, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Edit, contentDescription = null, tint = textColor, modifier = Modifier.size(20.dp)) }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFFF8A8A), modifier = Modifier.size(20.dp)) }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(anuncio.mensaje, color = textColor, fontSize = 14.sp)
            anuncio.idArchivo?.let { id ->
                Spacer(modifier = Modifier.height(12.dp))
                ArchivoDeAnuncio(idArchivo = id, nombre = anuncio.nombreArchivo, textColor = textColor)
            }
        }
    }
}

// ==========================================
// CLASE EN VIVO (videollamada + asistencia)
// ==========================================

@Composable
fun TarjetaClaseEnVivo(
    sesion: PaeSesionVideollamada?,
    cargando: Boolean,
    ocupado: Boolean,
    error: String?,
    cardBg: Color,
    cardBorder: BorderStroke,
    institutionalColor: Color,
    onIniciar: () -> Unit,
    onFinalizar: () -> Unit,
    onActualizar: () -> Unit
) {
    val textColor = MaterialTheme.colorScheme.onBackground
    val enVivo = sesion?.enVivo == true
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = cardBorder
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.VideoCall, contentDescription = null, tint = institutionalColor, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Clase en vivo", color = textColor, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    val estado = when {
                        cargando -> "Consultando..."
                        enVivo -> horaCorta(sesion?.inicio)?.let { "En vivo desde las $it" } ?: "En vivo"
                        sesion != null -> horaCorta(sesion.inicio)?.let { "Programada para las $it" } ?: "Programada"
                        else -> "Sin clase en curso"
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (enVivo) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFE53935)))
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text(estado, color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
                    }
                }
                IconButton(onClick = onActualizar, enabled = !cargando && !ocupado, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Refresh, contentDescription = "Actualizar", tint = textColor, modifier = Modifier.size(20.dp))
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onIniciar,
                enabled = !cargando && !ocupado,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = institutionalColor)
            ) {
                if (ocupado) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                } else {
                    Text(if (enVivo) "Volver a la clase en vivo" else "Iniciar clase en vivo", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
            if (enVivo) {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onFinalizar,
                    enabled = !ocupado,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFE53935))
                ) {
                    Text("Finalizar clase", color = Color(0xFFE53935), fontWeight = FontWeight.Bold)
                }
            }
            error?.let {
                Spacer(modifier = Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
            }
        }
    }
}

fun colorEstadoAsistencia(estado: String?): Color = when (estado?.uppercase()) {
    "PRESENTE" -> Color(0xFF43A047)
    "RETARDO" -> Color(0xFFFFA000)
    "AUSENTE" -> Color(0xFFE53935)
    else -> Color.Gray
}

@Composable
fun TarjetaAsistencia(
    lista: List<PaeAsistenciaAlumno>?,
    cargando: Boolean,
    error: String?,
    cardBg: Color,
    cardBorder: BorderStroke,
    onCerrar: () -> Unit,
    onReintentar: () -> Unit
) {
    val textColor = MaterialTheme.colorScheme.onBackground
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = cardBorder
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Asistencia de la sesión", color = textColor, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = onCerrar, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Cerrar", tint = textColor, modifier = Modifier.size(20.dp))
                }
            }
            when {
                cargando -> Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(modifier = Modifier.size(28.dp), color = textColor)
                }
                error != null -> {
                    Text(error, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                    TextButton(onClick = onReintentar) { Text("Reintentar", color = MaterialTheme.colorScheme.tertiary) }
                }
                lista.isNullOrEmpty() -> Text("No hay alumnos registrados en esta sesión.", color = textColor, fontSize = 13.sp)
                else -> {
                    // Resumen por estado
                    val conteo = lista.groupingBy { it.estado?.uppercase() }.eachCount()
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                        listOf("PRESENTE" to "presentes", "RETARDO" to "retardos", "AUSENTE" to "ausentes").forEach { (clave, etiqueta) ->
                            val color = colorEstadoAsistencia(clave)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(color.copy(alpha = 0.18f))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("${conteo[clave] ?: 0} $etiqueta", color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    lista.forEachIndexed { i, a ->
                        if (i > 0) HorizontalDivider(color = textColor.copy(alpha = 0.12f))
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
                            Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(colorEstadoAsistencia(a.estado)))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(a.alumno ?: "Alumno", color = textColor, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                val horas = listOfNotNull(
                                    horaCorta(a.entrada)?.let { "Entrada $it" },
                                    horaCorta(a.salida)?.let { "Salida $it" }
                                ).joinToString(" · ")
                                Text(
                                    listOfNotNull(a.boleta, horas.ifBlank { null }).joinToString(" · "),
                                    color = MaterialTheme.colorScheme.secondary,
                                    fontSize = 12.sp
                                )
                            }
                            Text(
                                a.estado?.uppercase() ?: "-",
                                color = colorEstadoAsistencia(a.estado),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
