package com.IPN.PAE.api

import com.IPN.PAE.api.models.PaeAsistenciaAlumno
import com.IPN.PAE.api.models.PaeFinalizarVideollamadaResponse
import com.IPN.PAE.api.models.PaeSesionVideollamada
import com.IPN.PAE.api.models.PaeUnirseVideollamadaResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Videollamadas de clase (Agora). El canal SIEMPRE viene del servidor.
 * Todas las funciones corren en IO y regresan Result con un mensaje legible en caso de error.
 */
object Videollamadas {

    private val api get() = RetrofitClient.paeApi

    /** Para avisos que deben llegar al servidor aunque la pantalla ya se haya cerrado (salir). */
    private val scopeFondo = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Sesión actual del curso, o null si no hay ninguna. */
    suspend fun consultar(idCurso: Int): Result<PaeSesionVideollamada?> = llamarApi {
        val r = api.videollamada(idCurso)
        if (r.isSuccessful) Result.success(r.body()?.sesion) else fallaApi(r)
    }

    /** Profesor: inicia la clase (o devuelve la que ya estaba en vivo). */
    suspend fun iniciar(idCurso: Int): Result<PaeSesionVideollamada> = llamarApi {
        val r = api.iniciarVideollamada(idCurso)
        val sesion = r.body()?.sesion
        when {
            !r.isSuccessful -> fallaApi(r)
            sesion?.canal.isNullOrBlank() -> Result.failure(Exception("El servidor no envió el canal de la clase"))
            else -> Result.success(sesion!!)
        }
    }

    /** Profesor: finaliza la clase en vivo. */
    suspend fun finalizar(idCurso: Int): Result<PaeFinalizarVideollamadaResponse> = llamarApi {
        val r = api.finalizarVideollamada(idCurso)
        when {
            r.code() == 409 -> Result.failure(Exception("No hay una clase en vivo para finalizar"))
            r.isSuccessful -> Result.success(r.body() ?: PaeFinalizarVideollamadaResponse(null, null))
            else -> fallaApi(r)
        }
    }

    /** Profesor: lista de asistencia de una sesión. */
    suspend fun asistencia(idSesion: Int): Result<List<PaeAsistenciaAlumno>> = llamarApi {
        val r = api.asistenciaSesion(idSesion)
        if (r.isSuccessful) Result.success(r.body()?.asistencia.orEmpty()) else fallaApi(r)
    }

    /** Alumno: se une y registra asistencia. Error con [ClaseNoIniciada] si el profesor no ha iniciado. */
    suspend fun unirse(idCurso: Int): Result<PaeUnirseVideollamadaResponse> = llamarApi {
        val r = api.unirseVideollamada(idCurso)
        val body = r.body()
        when {
            r.code() == 409 -> Result.failure(ClaseNoIniciada())
            !r.isSuccessful -> fallaApi(r)
            body?.canal.isNullOrBlank() -> Result.failure(Exception("El servidor no envió el canal de la clase"))
            else -> Result.success(body!!)
        }
    }

    /** Alumno: registra la hora de salida. No bloquea la pantalla y sobrevive a su cierre. */
    fun salir(idCurso: Int) {
        scopeFondo.launch {
            try { api.salirVideollamada(idCurso) } catch (_: Exception) { }
        }
    }

    class ClaseNoIniciada : Exception("El profesor aún no inicia la clase")
}

/** "2026-11-12 10:05:33" → "10:05". Si no reconoce el formato, regresa el texto tal cual. */
fun horaCorta(fecha: String?): String? {
    if (fecha.isNullOrBlank()) return null
    return Regex("\\d{1,2}:\\d{2}").find(fecha)?.value ?: fecha
}
