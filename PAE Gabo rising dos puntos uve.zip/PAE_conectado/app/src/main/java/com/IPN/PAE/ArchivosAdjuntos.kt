package com.IPN.PAE

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.IPN.PAE.api.RetrofitClient
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Archivo elegido con el selector de Android, aún sin subir. */
data class ArchivoLocal(val uri: Uri, val nombre: String, val mime: String, val tamano: Long?)

object ArchivosAdjuntos {

    /**
     * Límite de la app para archivos adjuntos (anuncios, tareas y entregas), en MB.
     * El servidor acepta hasta 500 MB, pero los archivos se cargan completos en memoria antes de subirlos.
     */
    const val TAMANO_MAXIMO_MB = 25
    const val TAMANO_MAXIMO = TAMANO_MAXIMO_MB * 1024L * 1024L

    /** Mensaje de error si el archivo excede [TAMANO_MAXIMO], o null si está bien. */
    fun validarTamano(archivo: ArchivoLocal): String? =
        if ((archivo.tamano ?: 0) > TAMANO_MAXIMO) "El archivo pesa más de $TAMANO_MAXIMO_MB MB" else null

    /** Abre un enlace externo (por ejemplo, el archivo_url de una entrega). Regresa un error o null. */
    fun abrirEnlace(context: Context, url: String): String? = try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        null
    } catch (_: Exception) {
        "No hay una app para abrir este enlace"
    }

    fun describir(context: Context, uri: Uri): ArchivoLocal {
        var nombre: String? = null
        var tamano: Long? = null
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val iNombre = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val iTamano = c.getColumnIndex(OpenableColumns.SIZE)
                if (iNombre >= 0) nombre = c.getString(iNombre)
                if (iTamano >= 0 && !c.isNull(iTamano)) tamano = c.getLong(iTamano)
            }
        }
        val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
        return ArchivoLocal(uri, nombre ?: uri.lastPathSegment ?: "archivo", mime, tamano)
    }

    fun leerBytes(context: Context, archivo: ArchivoLocal): ByteArray =
        context.contentResolver.openInputStream(archivo.uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("No se pudo leer el archivo")

    /**
     * Descarga el archivo (con el token de la sesión) a la caché y lo abre con la app que corresponda.
     * Se ejecuta en IO; regresa un mensaje de error o null si todo salió bien.
     */
    suspend fun abrir(context: Context, idArchivo: Int, nombreSugerido: String?): String? =
        withContext(Dispatchers.IO) {
            try {
                var r = RetrofitClient.paeApi.descargarArchivo(idArchivo)
                if (!r.isSuccessful) return@withContext "No se pudo descargar el archivo (${r.code()})"
                var tipo = r.body()?.contentType()?.toString()
                var nombre = nombreDeCabecera(r.headers()["Content-Disposition"]) ?: nombreSugerido

                // Si el servidor responde con metadatos en JSON en vez del archivo, se sigue la URL indicada.
                if (tipo?.startsWith("application/json") == true) {
                    val obj = JsonParser.parseString(r.body()!!.string()).asJsonObject
                    val datos = if (obj.has("archivo") && obj.get("archivo").isJsonObject) obj.getAsJsonObject("archivo") else obj
                    val url = listOf("url", "ruta", "enlace").firstNotNullOfOrNull { k ->
                        datos.get(k)?.takeIf { it.isJsonPrimitive }?.asString
                    } ?: return@withContext "El servidor no envió el contenido del archivo"
                    nombre = nombre ?: listOf("nombre_archivo", "nombre_original", "nombre").firstNotNullOfOrNull { k ->
                        datos.get(k)?.takeIf { it.isJsonPrimitive }?.asString
                    }
                    r = RetrofitClient.paeApi.descargarUrl(url)
                    if (!r.isSuccessful) return@withContext "No se pudo descargar el archivo (${r.code()})"
                    tipo = r.body()?.contentType()?.toString()
                }

                val nombreFinal = limpiarNombre(nombre ?: "archivo_$idArchivo")
                val carpeta = File(context.cacheDir, "archivos/$idArchivo").apply { mkdirs() }
                val destino = File(carpeta, nombreFinal)
                r.body()!!.byteStream().use { entrada -> destino.outputStream().use { entrada.copyTo(it) } }

                val extension = nombreFinal.substringAfterLast('.', "").lowercase()
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
                    ?: tipo?.substringBefore(';')?.takeIf { it != "application/octet-stream" }
                    ?: "*/*"
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.archivos", destino)
                val intent = Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                withContext(Dispatchers.Main) {
                    try {
                        context.startActivity(Intent.createChooser(intent, "Abrir con").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        null
                    } catch (_: ActivityNotFoundException) {
                        "No hay una app para abrir este archivo"
                    }
                }
            } catch (e: Exception) {
                "No se pudo abrir el archivo: ${e.message ?: "error de conexión"}"
            }
        }

    private fun nombreDeCabecera(cabecera: String?): String? {
        if (cabecera.isNullOrBlank()) return null
        Regex("filename\\*=UTF-8''([^;]+)", RegexOption.IGNORE_CASE).find(cabecera)?.let {
            return Uri.decode(it.groupValues[1].trim('"'))
        }
        return Regex("filename=\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(cabecera)?.groupValues?.get(1)?.trim()
    }

    private fun limpiarNombre(nombre: String): String =
        nombre.substringAfterLast('/').replace(Regex("[\\\\:*?\"<>|]"), "_").ifBlank { "archivo" }

    fun tamanoLegible(bytes: Long?): String? = when {
        bytes == null -> null
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        else -> String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
    }
}

/**
 * Fila con el nombre de un archivo adjunto. Si [onQuitar] no es null se muestra la "X" para quitarlo.
 */
@Composable
fun FilaArchivoAdjunto(
    nombre: String,
    detalle: String? = null,
    textColor: Color,
    cargando: Boolean = false,
    onClick: (() -> Unit)? = null,
    onQuitar: (() -> Unit)? = null
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, textColor.copy(alpha = 0.3f)),
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null && !cargando) Modifier.clickable(onClick = onClick) else Modifier)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            if (cargando) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = textColor)
            } else {
                Icon(Icons.Default.AttachFile, contentDescription = "Archivo adjunto", tint = textColor, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(nombre, color = textColor, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (detalle != null) Text(detalle, color = textColor.copy(alpha = 0.6f), fontSize = 11.sp)
            }
            if (onQuitar != null) {
                IconButton(onClick = onQuitar, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Quitar archivo", tint = textColor, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

/** Archivo adjunto de un anuncio publicado: al tocarlo se descarga y se abre. */
@Composable
fun ArchivoDeAnuncio(idArchivo: Int, nombre: String?, textColor: Color) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var cargando by remember { mutableStateOf(false) }
    FilaArchivoAdjunto(
        nombre = nombre ?: "Archivo adjunto",
        detalle = "Toca para abrir",
        textColor = textColor,
        cargando = cargando,
        onClick = {
            cargando = true
            scope.launch {
                val error = ArchivosAdjuntos.abrir(context, idArchivo, nombre)
                cargando = false
                if (error != null) Toast.makeText(context, error, Toast.LENGTH_LONG).show()
            }
        }
    )
}
