package com.IPN.PAE.api

import com.IPN.PAE.api.models.PaeAnuncioRequest
import com.IPN.PAE.api.models.PaeAsistenciaResponse
import com.IPN.PAE.api.models.PaeFinalizarVideollamadaResponse
import com.IPN.PAE.api.models.PaeIniciarVideollamadaResponse
import com.IPN.PAE.api.models.PaeUnirseVideollamadaResponse
import com.IPN.PAE.api.models.PaeVideollamadaResponse
import com.IPN.PAE.api.models.PaeAnunciosResponse
import com.IPN.PAE.api.models.PaeCursosResponse
import com.IPN.PAE.api.models.PaeLoginRequest
import com.IPN.PAE.api.models.PaeLoginResponse
import com.IPN.PAE.api.models.PaeYoResponse
import com.IPN.PAE.api.models.PaeKardexResponse
import com.IPN.PAE.api.models.PaeCalificarRequest
import com.IPN.PAE.api.models.PaeCrearTareaRequest
import com.IPN.PAE.api.models.PaeCrearTareaResponse
import com.IPN.PAE.api.models.PaeEntregaRequest
import com.IPN.PAE.api.models.PaeEntregasResponse
import com.IPN.PAE.api.models.PaeTareasResponse
import com.google.gson.JsonObject
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Streaming

/**
 * Rutas reales de la API del servidor PAE.
 * El token se agrega solo (ver RetrofitClient), salvo en "yo" justo después del login.
 */
interface PaeApi {

    @POST("login")
    suspend fun login(@Body body: PaeLoginRequest): Response<PaeLoginResponse>

    @GET("yo")
    suspend fun yo(@Header("Authorization") autorizacion: String?): Response<PaeYoResponse>

    @GET("cursos")
    suspend fun cursos(): Response<PaeCursosResponse>

    @GET("kardex")
    suspend fun kardex(): Response<PaeKardexResponse>

    /** Datos del usuario con el token de la sesión (el interceptor lo agrega). */
    @GET("yo")
    suspend fun yoSesion(): Response<PaeYoResponse>

    @GET("cursos/{id}/anuncios")
    suspend fun anuncios(@Path("id") idCurso: Int): Response<PaeAnunciosResponse>

    @POST("cursos/{id}/anuncios")
    suspend fun publicarAnuncio(
        @Path("id") idCurso: Int,
        @Body body: PaeAnuncioRequest
    ): Response<Map<String, Any>>

    /** Sube un archivo (multipart). La respuesta trae el id_archivo asignado. */
    @Multipart
    @POST("archivos")
    suspend fun subirArchivo(
        @Part archivo: MultipartBody.Part,
        @Part("categoria") categoria: RequestBody,
        @Part("id_curso") idCurso: RequestBody
    ): Response<JsonObject>

    /** Descarga el contenido de un archivo (requiere token). */
    @Streaming
    @GET("archivos/{id}")
    suspend fun descargarArchivo(@Path("id") idArchivo: Int): Response<ResponseBody>

    @Streaming
    @GET
    suspend fun descargarUrl(@retrofit2.http.Url url: String): Response<ResponseBody>

    // ---------- Videollamadas ----------

    @GET("cursos/{id}/videollamada")
    suspend fun videollamada(@Path("id") idCurso: Int): Response<PaeVideollamadaResponse>

    @POST("cursos/{id}/videollamada/iniciar")
    suspend fun iniciarVideollamada(@Path("id") idCurso: Int): Response<PaeIniciarVideollamadaResponse>

    @POST("cursos/{id}/videollamada/finalizar")
    suspend fun finalizarVideollamada(@Path("id") idCurso: Int): Response<PaeFinalizarVideollamadaResponse>

    @POST("cursos/{id}/videollamada/unirse")
    suspend fun unirseVideollamada(@Path("id") idCurso: Int): Response<PaeUnirseVideollamadaResponse>

    @POST("cursos/{id}/videollamada/salir")
    suspend fun salirVideollamada(@Path("id") idCurso: Int): Response<Map<String, Any>>

    @GET("sesiones/{id}/asistencia")
    suspend fun asistenciaSesion(@Path("id") idSesion: Int): Response<PaeAsistenciaResponse>

    // ---------- Tareas ----------

    @GET("cursos/{id}/tareas")
    suspend fun tareas(@Path("id") idCurso: Int): Response<PaeTareasResponse>

    @POST("cursos/{id}/tareas")
    suspend fun crearTarea(
        @Path("id") idCurso: Int,
        @Body body: PaeCrearTareaRequest
    ): Response<PaeCrearTareaResponse>

    @POST("tareas/{id}/entrega")
    suspend fun entregarTarea(
        @Path("id") idTarea: Int,
        @Body body: PaeEntregaRequest
    ): Response<Map<String, Any>>

    @GET("tareas/{id}/entregas")
    suspend fun entregasTarea(@Path("id") idTarea: Int): Response<PaeEntregasResponse>

    @POST("entregas/{id}/calificar")
    suspend fun calificarEntrega(
        @Path("id") idEntrega: Int,
        @Body body: PaeCalificarRequest
    ): Response<Map<String, Any>>

    @POST("logout")
    suspend fun logout(): Response<Map<String, Any>>
}
