package com.IPN.PAE.api

import com.IPN.PAE.api.models.AnuncioApiResponse
import com.IPN.PAE.api.models.AnuncioDto
import com.IPN.PAE.api.models.AnuncioPostRequest
import com.IPN.PAE.api.models.CalificacionApiResponse
import com.IPN.PAE.api.models.CalificacionDto
import com.IPN.PAE.api.models.LoginRequest
import com.IPN.PAE.api.models.LoginResponse
import com.IPN.PAE.api.models.MateriaApiResponse
import com.IPN.PAE.api.models.MateriaDto
import com.IPN.PAE.api.models.PaeAnuncioRequest
import com.IPN.PAE.api.models.PaeCurso
import com.IPN.PAE.api.models.PaeLoginRequest
import com.IPN.PAE.api.models.UserData
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.ResponseBody.Companion.toResponseBody
import retrofit2.Response

/**
 * Traduce entre lo que esperan las pantallas de la app (AuthApi) y la API real del servidor (PaeApi).
 * Gracias a esto, las pantallas casi no tuvieron que cambiar.
 */
class PaeApiAdapter(private val api: PaeApi) : AuthApi {

    override suspend fun login(request: LoginRequest): Response<LoginResponse> {
        val r = api.login(PaeLoginRequest(usuario = request.usuario, contrasena = request.password))
        val body = r.body()
        val token = body?.token
        if (!r.isSuccessful || body == null || token.isNullOrBlank()) return error(r)

        val rol = body.rol ?: "alumno"
        // El grupo del alumno viene en /yo; se pide con el token recién recibido.
        val grupo = if (rol.equals("alumno", ignoreCase = true)) {
            try {
                api.yo("Bearer $token").body()?.datos?.grupo
            } catch (_: Exception) {
                null
            }
        } else null

        return Response.success(
            LoginResponse(
                success = true,
                message = "Sesión iniciada",
                accessToken = token,
                tokenType = "Bearer",
                expiresAt = null,
                user = UserData(
                    id = body.usuario?.id.orEmpty(),
                    nombre = body.usuario?.nombre.orEmpty(),
                    rol = rol,
                    grupo = grupo
                )
            )
        )
    }

    override suspend fun getMaterias(grupo: String): Response<MateriaApiResponse> {
        val r = api.cursos()
        val cursos = r.body()?.cursos
        if (!r.isSuccessful || cursos == null) return error(r)
        val data = cursos.map { c ->
            MateriaDto(
                id = c.idCurso.toString(),
                nombre = etiqueta(c),
                profesor = c.profesor.orEmpty(),
                aula = c.aula.orEmpty(),
                horario = c.horario.orEmpty()
            )
        }
        return Response.success(MateriaApiResponse(success = true, data = data))
    }

    override suspend fun getCalificaciones(boleta: String): Response<CalificacionApiResponse> {
        val r = api.cursos()
        val cursos = r.body()?.cursos
        if (!r.isSuccessful || cursos == null) return error(r)
        val data = cursos.map { c ->
            CalificacionDto(
                materia = c.materia.orEmpty(),
                u1 = formato(c.parcial1),
                u2 = formato(c.parcial2),
                u3 = formato(c.parcial3),
                final = formato(c.calificacionFinal)
            )
        }
        return Response.success(CalificacionApiResponse(success = true, data = data))
    }

    override suspend fun getAnuncios(materia: String?, grupo: String?): Response<AnuncioApiResponse> {
        val curso = buscarCurso(materia, grupo)
            ?: return Response.success(AnuncioApiResponse(success = true, data = emptyList()))
        val r = api.anuncios(curso.idCurso)
        val anuncios = r.body()?.anuncios
        if (!r.isSuccessful || anuncios == null) return error(r)
        val data = anuncios.map { a ->
            AnuncioDto(
                id = a.id.toString(),
                autor = a.autor.orEmpty(),
                fecha = a.fecha.orEmpty(),
                mensaje = unirTexto(a.titulo.orEmpty(), a.contenido.orEmpty()),
                materia = curso.materia,
                grupo = curso.grupo,
                idArchivo = a.idArchivo,
                nombreArchivo = a.nombreArchivo
            )
        }
        return Response.success(AnuncioApiResponse(success = true, data = data))
    }

    override suspend fun postAnuncio(request: AnuncioPostRequest): Response<Any> {
        val curso = buscarCurso(request.materia, request.grupo.ifBlank { null })
            ?: return errorConMensaje(404, "No se encontró la materia ${request.materia}")
        val mensaje = request.mensaje.trim()
        val titulo = mensaje.lineSequence().first().trim().take(150).ifBlank { "Anuncio" }
        val r = api.publicarAnuncio(curso.idCurso, PaeAnuncioRequest(titulo = titulo, contenido = mensaje, idArchivo = request.idArchivo)
        )
        if (!r.isSuccessful) return error(r)
        return Response.success(r.body() ?: emptyMap<String, Any>())
    }

    override suspend fun subirArchivoAnuncio(
        materia: String,
        grupo: String?,
        nombre: String,
        mime: String,
        bytes: ByteArray
    ): Result<Int> {
        val curso = buscarCurso(materia, grupo?.ifBlank { null })
            ?: return Result.failure(IllegalStateException("No se encontró la materia $materia"))
        val texto = "text/plain".toMediaType()
        val parte = MultipartBody.Part.createFormData(
            "archivo", nombre, bytes.toRequestBody(mime.toMediaTypeOrNull())
        )
        val r = api.subirArchivo(
            archivo = parte,
            categoria = "anuncio".toRequestBody(texto),
            idCurso = curso.idCurso.toString().toRequestBody(texto)
        )
        if (!r.isSuccessful) {
            val cuerpo = try { r.errorBody()?.string() } catch (_: Exception) { null }
            val msg = extraerMensaje(cuerpo) ?: "No se pudo subir el archivo (${r.code()})"
            return Result.failure(IllegalStateException(msg))
        }
        val id = extraerIdArchivo(r.body())
            ?: return Result.failure(IllegalStateException("El servidor no regresó el id del archivo"))
        return Result.success(id)
    }

    // ---------- utilidades ----------

    /** El profesor puede dar la misma materia a varios grupos, por eso se muestra "Materia (Grupo)". */
    private fun etiqueta(c: PaeCurso): String {
        val materia = c.materia.orEmpty()
        return if (c.profesor == null && !c.grupo.isNullOrBlank()) "$materia (${c.grupo})" else materia
    }

    private suspend fun buscarCurso(materia: String?, grupo: String?): PaeCurso? {
        if (materia.isNullOrBlank()) return null
        val cursos = (try {
            api.cursos().body()?.cursos
        } catch (_: Exception) {
            null
        }) ?: return null
        return cursos.firstOrNull { c ->
            (etiqueta(c).equals(materia, ignoreCase = true) || c.materia.equals(materia, ignoreCase = true)) &&
                (grupo == null || c.grupo.equals(grupo, ignoreCase = true))
        }
    }

    /** Acepta {"id_archivo": 5}, {"id": 5} o {"archivo": {"id_archivo": 5}}. */
    private fun extraerIdArchivo(obj: JsonObject?): Int? {
        if (obj == null) return null
        for (clave in listOf("id_archivo", "id")) {
            val v = obj.get(clave)
            if (v != null && v.isJsonPrimitive) v.asString.toIntOrNull()?.let { return it }
        }
        val anidado = obj.get("archivo")
        return if (anidado != null && anidado.isJsonObject) extraerIdArchivo(anidado.asJsonObject) else null
    }

    private fun formato(valor: Double?): String {
        if (valor == null) return "-"
        return if (valor % 1.0 == 0.0) valor.toInt().toString() else valor.toString()
    }

    private fun unirTexto(titulo: String, contenido: String): String =
        if (titulo.isBlank() || contenido.startsWith(titulo)) contenido else "$titulo\n$contenido"

    /** Convierte {"error": "..."} del servidor al formato {"success": false, "message": "..."} que lee la app. */
    private fun <T> error(r: Response<*>): Response<T> {
        val texto = try {
            r.errorBody()?.string()
        } catch (_: Exception) {
            null
        }
        val mensaje = extraerMensaje(texto) ?: "Error del servidor (${r.code()})"
        return errorConMensaje(if (r.code() >= 400) r.code() else 500, mensaje)
    }

    private fun <T> errorConMensaje(codigo: Int, mensaje: String): Response<T> {
        val json = JsonObject().apply {
            addProperty("success", false)
            addProperty("message", mensaje)
        }
        return Response.error(codigo, json.toString().toResponseBody("application/json".toMediaType()))
    }

    private fun extraerMensaje(texto: String?): String? {
        if (texto.isNullOrBlank()) return null
        return try {
            val obj = JsonParser.parseString(texto).asJsonObject
            when {
                obj.has("error") -> obj.get("error").asString
                obj.has("message") -> obj.get("message").asString
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }
}
