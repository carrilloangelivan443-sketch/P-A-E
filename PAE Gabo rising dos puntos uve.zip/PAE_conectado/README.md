# PAE conectado

App Android del PAE para alumnos y profesores. Los alumnos consultan sus clases, calificaciones, kárdex, anuncios y tareas, entregan tareas y se unen a clases en vivo. Los profesores publican anuncios y tareas, califican entregas y dan clases en vivo con pase de lista automático.

Está hecha en Kotlin con Jetpack Compose, usa Retrofit para conectarse a la API y Agora para las videollamadas.

## Abrir el proyecto

1. Clona el repositorio y ábrelo en Android Studio (**File → Open** y elige la carpeta del proyecto).
2. Crea el archivo `local.properties` en la raíz (ver abajo).
3. Espera a que termine la sincronización de Gradle y ejecuta la configuración `app` en un emulador o celular (Android 7.0 o superior).

## local.properties

Este archivo no se sube a git. Android Studio lo crea con la ruta del SDK; además hay que agregar el App ID de Agora:

```properties
sdk.dir=/ruta/a/Android/Sdk
AGORA_APP_ID=tu_app_id_de_agora
```

Sin `AGORA_APP_ID` la app compila, pero las clases en vivo no funcionan.

## API

La app se conecta a la API del servidor PAE (`https://pae.tail98eed5.ts.net/api/`). El código de la API está en el repositorio **pae-api**. Las rutas que usa la app están documentadas en `CLAUDE.md`.
