try {
    val peClass = Class.forName("java.lang.ProcessEnvironment")
    val nameValueOf = peClass.getDeclaredClasses().firstOrNull { it.simpleName == "Variable" }?.getMethod("valueOf", String::class.java)
    fun modifyEnv(fieldMapName: String, removeName: String) {
        runCatching {
            val f = peClass.getDeclaredField(fieldMapName)
            f.isAccessible = true
            @Suppress("UNCHECKED_CAST")
            val map = f.get(null) as? MutableMap<Any, Any> ?: return
            if (nameValueOf != null) {
                val key = nameValueOf.invoke(null, removeName)
                map.remove(key)
            } else {
                map.remove(removeName)
            }
        }
    }
    modifyEnv("theEnvironment", "ANDROID_PREFS_ROOT")
    modifyEnv("theCaseInsensitiveEnvironment", "ANDROID_PREFS_ROOT")
    modifyEnv("theEnvironment", "android.prefs.root")
    modifyEnv("theCaseInsensitiveEnvironment", "android.prefs.root")
} catch (_: Throwable) {}

pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0"
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://maven.jitsi.org") }
    }
}

rootProject.name = "PAE"
include(":app")
