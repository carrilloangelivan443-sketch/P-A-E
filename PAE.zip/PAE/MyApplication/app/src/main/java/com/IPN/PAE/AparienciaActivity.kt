package com.IPN.PAE

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit
import com.IPN.PAE.ui.theme.AppThemeMode
import com.IPN.PAE.ui.theme.MyApplicationTheme
import com.IPN.PAE.ui.theme.getSavedThemeMode
import com.IPN.PAE.ui.theme.saveThemeMode

class AparienciaActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            var currentThemeMode by remember { mutableStateOf(getSavedThemeMode(context)) }

            MyApplicationTheme(themeMode = currentThemeMode) {
                AparienciaScreen(
                    currentThemeMode = currentThemeMode,
                    onThemeSelected = { newMode ->
                        currentThemeMode = newMode
                        saveThemeMode(context, newMode)
                    }
                )
            }
        }
    }
}

@Composable
fun AparienciaScreen(
    currentThemeMode: AppThemeMode = AppThemeMode.APP_GUINDA,
    onThemeSelected: (AppThemeMode) -> Unit = {}
) {
    val context = LocalContext.current
    val sharedPreferences = remember { context.getSharedPreferences("SesionIPN", Context.MODE_PRIVATE) }
    var highContrastEnabled by remember {
        mutableStateOf(sharedPreferences.getBoolean("high_contrast_enabled", false))
    }

    val textColor = MaterialTheme.colorScheme.onBackground
    val cardBg = MaterialTheme.colorScheme.surface.copy(alpha = 0.45f)
    val cardBorder = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)

    MainDrawerLayout(currentScreenTitle = "Apariencia") { openDrawer ->
        Box(modifier = Modifier.fillMaxSize()) {
            FondoLavaBackground(modifier = Modifier.fillMaxSize())

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .verticalScroll(rememberScrollState()),
            ) {
                TopHeader(title = "Apariencia", onOpenDrawer = openDrawer)

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    border = BorderStroke(1.dp, cardBorder),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "Modo de Tema",
                            style = MaterialTheme.typography.titleMedium,
                            color = textColor,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Selecciona el tema de color para toda la aplicación",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.padding(top = 2.dp, bottom = 16.dp)
                        )

                        val options = listOf(
                            ThemeOption(
                                mode = AppThemeMode.APP_GUINDA,
                                title = "Guinda IPN (Predeterminado)",
                                description = "Colores institucionales en tonos guinda",
                                icon = Icons.Default.Palette,
                                colorPreview = Color(0xFF9E224C)
                            ),
                            ThemeOption(
                                mode = AppThemeMode.DARK,
                                title = "Modo Oscuro",
                                description = "Elegante y cómodo para la vista nocturna",
                                icon = Icons.Default.DarkMode,
                                colorPreview = Color(0xFF141414)
                            ),
                            ThemeOption(
                                mode = AppThemeMode.LIGHT,
                                title = "Modo Claro",
                                description = "Fondo hueso con acentos azules",
                                icon = Icons.Default.LightMode,
                                colorPreview = Color(0xFFFBF8EF)
                            ),
                            ThemeOption(
                                mode = AppThemeMode.SYSTEM,
                                title = "Según el Sistema",
                                description = "Ajusta automáticamente según el sistema",
                                icon = Icons.Default.BrightnessAuto,
                                colorPreview = Color(0xFF888888)
                            )
                        )

                        options.forEachIndexed { index, option ->
                            ThemeOptionRow(
                                option = option,
                                isSelected = currentThemeMode == option.mode,
                                onSelect = { onThemeSelected(option.mode) },
                                textColor = textColor,
                                secondaryTextColor = MaterialTheme.colorScheme.secondary
                            )
                            if (index < options.size - 1) {
                                HorizontalDivider(
                                    color = textColor.copy(alpha = 0.15f),
                                    thickness = 0.5.dp,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    border = BorderStroke(1.dp, cardBorder),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "Accesibilidad",
                            style = MaterialTheme.typography.titleMedium,
                            color = textColor,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                                Text("Alto Contraste", color = textColor, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "Mejorar legibilidad de los textos",
                                    color = MaterialTheme.colorScheme.secondary,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            Switch(
                                checked = highContrastEnabled,
                                onCheckedChange = { checked ->
                                    highContrastEnabled = checked
                                    sharedPreferences.edit { putBoolean("high_contrast_enabled", checked) }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

private data class ThemeOption(
    val mode: AppThemeMode,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val colorPreview: Color
)

@Composable
private fun ThemeOptionRow(
    option: ThemeOption,
    isSelected: Boolean,
    onSelect: () -> Unit,
    textColor: Color,
    secondaryTextColor: Color
) {
    val selectedColor = MaterialTheme.colorScheme.tertiary

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onSelect() }
            .padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(option.colorPreview)
                    .border(1.dp, textColor.copy(alpha = 0.3f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = option.icon,
                    contentDescription = null,
                    tint = if (option.colorPreview == Color(0xFFFBF8EF)) Color(0xFF1B2A3A) else Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = option.title,
                    color = textColor,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                Text(
                    text = option.description,
                    color = secondaryTextColor,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        RadioButton(
            selected = isSelected,
            onClick = onSelect,
            colors = RadioButtonDefaults.colors(
                selectedColor = selectedColor,
                unselectedColor = textColor.copy(alpha = 0.6f)
            )
        )
    }
}
