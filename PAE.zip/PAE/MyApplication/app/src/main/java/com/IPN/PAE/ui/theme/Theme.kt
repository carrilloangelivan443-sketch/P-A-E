package com.IPN.PAE.ui.theme

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.edit

enum class AppThemeMode {
    APP_GUINDA,
    DARK,
    LIGHT,
    SYSTEM
}

val LocalAppThemeMode = staticCompositionLocalOf { AppThemeMode.APP_GUINDA }

fun getSavedThemeMode(context: Context): AppThemeMode {
    val prefsConfig = context.getSharedPreferences("AppConfig", Context.MODE_PRIVATE)
    val prefsSesion = context.getSharedPreferences("SesionIPN", Context.MODE_PRIVATE)
    val name = prefsConfig.getString("app_theme_mode", null)
        ?: prefsSesion.getString("app_theme_mode", AppThemeMode.APP_GUINDA.name)
    return try {
        AppThemeMode.valueOf(name ?: AppThemeMode.APP_GUINDA.name)
    } catch (_: Exception) {
        AppThemeMode.APP_GUINDA
    }
}

fun saveThemeMode(context: Context, mode: AppThemeMode) {
    context.getSharedPreferences("AppConfig", Context.MODE_PRIVATE)
        .edit { putString("app_theme_mode", mode.name) }
    context.getSharedPreferences("SesionIPN", Context.MODE_PRIVATE)
        .edit { putString("app_theme_mode", mode.name) }
}

@Composable
fun MyApplicationTheme(
    themeMode: AppThemeMode? = null,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    var savedThemeMode by remember { mutableStateOf(getSavedThemeMode(context)) }

    DisposableEffect(context) {
        val configPrefs = context.getSharedPreferences("AppConfig", Context.MODE_PRIVATE)
        val sesionPrefs = context.getSharedPreferences("SesionIPN", Context.MODE_PRIVATE)

        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "app_theme_mode") {
                savedThemeMode = getSavedThemeMode(context)
            }
        }
        configPrefs.registerOnSharedPreferenceChangeListener(listener)
        sesionPrefs.registerOnSharedPreferenceChangeListener(listener)

        onDispose {
            configPrefs.unregisterOnSharedPreferenceChangeListener(listener)
            sesionPrefs.unregisterOnSharedPreferenceChangeListener(listener)
        }
    }

    val effectiveThemeMode = themeMode ?: savedThemeMode
    val systemDark = isSystemInDarkTheme()

    val colorScheme = when (effectiveThemeMode) {
        AppThemeMode.APP_GUINDA -> darkColorScheme(
            primary = Color(0xFF9E224C),
            secondary = Color(0xFF7D2242),
            tertiary = Color(0xFFFFB4A2),
            background = Color(0xFF2B0018),
            surface = Color(0xFF3B0020),
            onBackground = Color.White,
            onSurface = Color.White
        )
        AppThemeMode.DARK -> darkColorScheme(
            primary = Color(0xFF888888),
            secondary = Color(0xFF555555),
            tertiary = Color(0xFFAAAAAA),
            background = Color(0xFF0A0A0A),
            surface = Color(0xFF141414),
            onBackground = Color.White,
            onSurface = Color.White
        )
        AppThemeMode.LIGHT -> lightColorScheme(
            primary = Color(0xFF9EB6BD),
            secondary = Color(0xFF444444),
            tertiary = Color(0xFF9EB6BD),
            background = Color(0xFFFBF8EF),
            surface = Color(0xFFFBF8EF),
            onBackground = Color.Black,
            onSurface = Color.Black
        )
        AppThemeMode.SYSTEM -> if (systemDark) darkColorScheme(
            primary = Color(0xFF888888),
            secondary = Color(0xFF555555),
            tertiary = Color(0xFFAAAAAA),
            background = Color(0xFF0A0A0A),
            surface = Color(0xFF141414),
            onBackground = Color.White,
            onSurface = Color.White
        ) else lightColorScheme(
            primary = Color(0xFF9EB6BD),
            secondary = Color(0xFF444444),
            tertiary = Color(0xFF9EB6BD),
            background = Color(0xFFFBF8EF),
            surface = Color(0xFFFBF8EF),
            onBackground = Color.Black,
            onSurface = Color.Black
        )
    }

    CompositionLocalProvider(LocalAppThemeMode provides effectiveThemeMode) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}

@Composable
fun getInstitutionalColor(): Color {
    val currentThemeMode = LocalAppThemeMode.current
    val systemDark = isSystemInDarkTheme()
    return when (currentThemeMode) {
        AppThemeMode.APP_GUINDA -> Color(0xFF7D2242)
        AppThemeMode.DARK -> Color(0xFF262626)
        AppThemeMode.LIGHT -> Color(0xFF1B2A3A)
        AppThemeMode.SYSTEM -> if (systemDark) Color(0xFF262626) else Color(0xFF1B2A3A)
    }
}
