package com.example.paevisuals

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class FondoLavaView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val paintFondo = Paint()
    private val paintCapa2 = Paint()
    private var tiempo = 0f

    private val colores1 = intArrayOf(0xFF3B0020.toInt(), 0xFF6A0036.toInt(), 0xFF9E224C.toInt())
    private val colores2 = intArrayOf(0xFF9E224C.toInt(), 0xFF6A0036.toInt(), 0xFF3B0020.toInt())

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (width <= 0 || height <= 0) return

        tiempo += 0.008f

        val startX1 = width * 0.2f + (sin(tiempo) * 300f)
        val startY1 = height * 0.2f + (cos(tiempo * 0.8f) * 250f)
        val endX1 = width * 0.8f + (cos(tiempo) * 200f)
        val endY1 = height * 0.8f + (sin(tiempo * 1.2f) * 300f)

        paintFondo.shader = LinearGradient(
            startX1, startY1, endX1, endY1,
            colores1, null, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paintFondo)

        val startX2 = width * 0.8f + (cos(tiempo * 1.1f) * 250f)
        val startY2 = height * 0.1f + (sin(tiempo) * 300f)
        val endX2 = width * 0.1f + (sin(tiempo * 0.7f) * 200f)
        val endY2 = height * 0.9f + (cos(tiempo) * 250f)

        paintCapa2.shader = LinearGradient(
            startX2, startY2, endX2, endY2,
            colores2, null, Shader.TileMode.CLAMP
        )

        paintCapa2.alpha = 120
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paintCapa2)

        if (!isInEditMode) {
            postInvalidateOnAnimation()
        }
    }
}
