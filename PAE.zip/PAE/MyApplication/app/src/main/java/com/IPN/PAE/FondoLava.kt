package com.IPN.PAE

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.IPN.PAE.ui.theme.AppThemeMode
import com.IPN.PAE.ui.theme.LocalAppThemeMode
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun FondoLavaBackground(
    modifier: Modifier = Modifier,
    themeMode: AppThemeMode = LocalAppThemeMode.current,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "lava_view_transition")

    val tiempo by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "tiempo",
    )

    val systemDark = isSystemInDarkTheme()

    val (colores1, colores2) = when (themeMode) {
        AppThemeMode.APP_GUINDA -> Pair(
            listOf(Color(0xFF3B0020), Color(0xFF6A0036), Color(0xFF9E224C)),
            listOf(Color(0xFF9E224C), Color(0xFF6A0036), Color(0xFF3B0020))
        )
        AppThemeMode.DARK -> Pair(
            listOf(Color(0xFF0A0A0A), Color(0xFF1E1E1E), Color(0xFF333333)),
            listOf(Color(0xFF333333), Color(0xFF1E1E1E), Color(0xFF0A0A0A))
        )
        AppThemeMode.LIGHT -> Pair(
            listOf(Color(0xFFFBF8EF), Color(0xFF1B2A3A), Color(0xFF0F1B29)),
            listOf(Color(0xFF0F1B29), Color(0xFF1B2A3A), Color(0xFFFBF8EF))
        )
        AppThemeMode.SYSTEM -> if (systemDark) Pair(
            listOf(Color(0xFF0A0A0A), Color(0xFF1E1E1E), Color(0xFF333333)),
            listOf(Color(0xFF333333), Color(0xFF1E1E1E), Color(0xFF0A0A0A))
        ) else Pair(
            listOf(Color(0xFFFBF8EF), Color(0xFF1B2A3A), Color(0xFF0F1B29)),
            listOf(Color(0xFF0F1B29), Color(0xFF1B2A3A), Color(0xFFFBF8EF))
        )
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        if (width <= 0f || height <= 0f) return@Canvas

        val startX1 = width * 0.2f + (sin(tiempo) * 300f)
        val startY1 = height * 0.2f + (cos(tiempo * 0.8f) * 250f)
        val endX1 = width * 0.8f + (cos(tiempo) * 200f)
        val endY1 = height * 0.8f + (sin(tiempo * 1.2f) * 300f)

        drawRect(
            brush = Brush.linearGradient(
                colors = colores1,
                start = Offset(startX1, startY1),
                end = Offset(endX1, endY1)
            ),
            size = Size(width, height)
        )

        val startX2 = width * 0.8f + (cos(tiempo * 1.1f) * 250f)
        val startY2 = height * 0.1f + (sin(tiempo) * 300f)
        val endX2 = width * 0.1f + (sin(tiempo * 0.7f) * 200f)
        val endY2 = height * 0.9f + (cos(tiempo) * 250f)

        drawRect(
            brush = Brush.linearGradient(
                colors = colores2,
                start = Offset(startX2, startY2),
                end = Offset(endX2, endY2)
            ),
            size = Size(width, height),
            alpha = 120f / 255f
        )
    }
}
