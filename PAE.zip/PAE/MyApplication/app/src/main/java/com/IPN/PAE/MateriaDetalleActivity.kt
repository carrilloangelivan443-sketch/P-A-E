package com.IPN.PAE

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.IPN.PAE.ui.theme.AppThemeMode
import com.IPN.PAE.ui.theme.LocalAppThemeMode
import com.IPN.PAE.ui.theme.getInstitutionalColor
import com.IPN.PAE.ui.theme.MyApplicationTheme
import androidx.compose.foundation.isSystemInDarkTheme
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.google.firebase.firestore.FirebaseFirestore
import androidx.compose.ui.platform.LocalContext


class MateriaDetalleActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Recibiríamos el nombre de la materia a través del Intent en un futuro
        val nombreMateria = intent.getStringExtra("NOMBRE_MATERIA") ?: "Base de Datos"
        val nombreProfesor = intent.getStringExtra("NOMBRE_PROFESOR") ?: "Profesor Asignado"

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MateriaDetalleScreen(
                    nombreMateria = nombreMateria,
                    nombreProfesor = nombreProfesor,
                ) { finish() }
            }
        }
    }
}

@Composable
fun MateriaDetalleScreen(nombreMateria: String, nombreProfesor: String, onBack: () -> Unit) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("Novedades", "Tareas", "Reunion")

    Box(modifier = Modifier.fillMaxSize()) {
        FondoLavaBackground(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            // --- HEADER CORREGIDO ---
            val institutionalColor = getInstitutionalColor()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(institutionalColor)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack, 
                    colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack, 
                        contentDescription = "Regresar", 
                        modifier = Modifier.size(28.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = nombreMateria,
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = nombreProfesor,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFFFB4A2)
                    )
                }
            }

            // --- TAB ROW (Pestañas) ---
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = Color.Transparent,
                contentColor = Color.White,
                indicator = { tabPositions ->
                    if (selectedTabIndex < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                            color = Color(0xFFFFB4A2),
                            height = 3.dp
                        )
                    }
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = { 
                            Text(
                                text = title, 
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) Color.White else Color(0x99FFFFFF)
                            ) 
                        }
                    )
                }
            }

            // --- CONTENIDO DE LAS PESTAÑAS ---
            Box(modifier = Modifier.weight(1f)) {
                when (selectedTabIndex) {
                    0 -> PestañaNovedades(nombreMateria, nombreProfesor)
                    1 -> PestañaTareas()
                    2 -> PestañaVideollamada(nombreMateria)
                }
            }
        }
    }
}

// ==========================================
// PESTAÑA 1: NOVEDADES / MURO DEL PROFESOR
// ==========================================
@Composable
fun PestañaNovedades(nombreMateria: String, nombreProfesor: String) {
    val db = FirebaseFirestore.getInstance()
    var listaAnuncios by remember { mutableStateOf<List<Anuncio>>(emptyList()) }
    var isLoading by remember { mutableStateOf(value = true) }
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("SesionIPN", Context.MODE_PRIVATE)
    val grupoAlumno = sharedPreferences.getString("grupo", "") ?: ""

    // DESCARGAR ANUNCIOS DE FIREBASE EN TIEMPO REAL PARA EL ALUMNO
    LaunchedEffect(nombreMateria, nombreProfesor, grupoAlumno) {
        var query = db.collection("Anuncios")
            .whereEqualTo("materia", nombreMateria)

        if (nombreProfesor.isNotBlank() && nombreProfesor != "Profesor Asignado") {
            query = query.whereEqualTo("autor", nombreProfesor)
        }
        if (grupoAlumno.isNotBlank()) {
            query = query.whereEqualTo("grupo", grupoAlumno)
        }

        query.addSnapshotListener { snapshot, _ ->
            if (snapshot != null) {
                listaAnuncios = snapshot.documents.map { doc ->
                    Anuncio(
                        id = doc.id,
                        autor = doc.getString("autor") ?: "Profesor",
                        fecha = doc.getString("fecha") ?: "",
                        mensaje = doc.getString("mensaje") ?: "",
                    )
                }
            }
            isLoading = false
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center),
                color = Color(0xFFFFB4A2),
            )
        } else if (listaAnuncios.isEmpty()) {
            Text(
                text = "Aún no hay anuncios en esta clase.",
                color = Color.Gray,
                modifier = Modifier.align(Alignment.Center),
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                listaAnuncios.forEach { anuncio ->
                    CardAnuncio(
                        autor = anuncio.autor,
                        fecha = anuncio.fecha,
                        mensaje = anuncio.mensaje,
                    )
                }
            }
        }
    }
}

@Composable
fun CardAnuncio(autor: String, fecha: String, mensaje: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
        border = BorderStroke(1.dp, Color(0x33FFFFFF)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Avatar circular simulado
                val currentThemeMode = LocalAppThemeMode.current
                val systemDark = isSystemInDarkTheme()
                val isLightMode = currentThemeMode == AppThemeMode.LIGHT || (currentThemeMode == AppThemeMode.SYSTEM && !systemDark)
                val institutionalColor = if (isLightMode) Color(0xFF1B2A3A) else Color(0xFF7D2242)

                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(institutionalColor),
                    contentAlignment = Alignment.Center
                ) {
                    Text(autor.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = autor, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(text = fecha, color = Color(0xFFA0A0A0), fontSize = 12.sp)
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = mensaje,
                color = Color(0xFFE0E0E0),
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0x22FFFFFF))

            // Sección para comentarios de alumnos (Simulado)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Comentarios", tint = Color(0xFFA0A0A0), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Agregar un comentario de clase...", color = Color(0xFFA0A0A0), fontSize = 12.sp)
            }
        }
    }
}

// ==========================================
// PESTAÑA 2: TAREAS
// ==========================================
@Composable
fun PestañaTareas() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        CardTarea(
            titulo = "Diagrama Entidad-Relación",
            fechaEntrega = "Entrega: Mañana 23:59",
            estado = "Asignada"
        )
        CardTarea(
            titulo = "Investigación: Llaves Foráneas",
            fechaEntrega = "Vencida el Lunes",
            estado = "Sin entregar",
            colorEstado = Color(0xFFFF8A8A) // Rojo
        )
    }
}

@Composable
fun CardTarea(titulo: String, fechaEntrega: String, estado: String, colorEstado: Color = Color(0xFFFFB4A2)) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x22000000)),
        border = BorderStroke(1.dp, Color(0x22FFFFFF))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color(0x447D2242)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.AutoMirrored.Filled.Assignment, contentDescription = "Tarea", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = titulo, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = fechaEntrega, color = Color(0xFFA0A0A0), fontSize = 12.sp)
            }
            Text(text = estado, color = colorEstado, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

// ==========================================
// PESTAÑA 3: VIDEOLLAMADA Y ASISTENCIA
// ==========================================
// ==========================================
// PESTAÑA 3: CLASE VIRTUAL (JITSI MEET)
// ==========================================
@Composable
fun PestañaVideollamada(nombreMateria: String) {
    // Obtenemos el contexto para poder lanzar la actividad de Jitsi
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.VideoCall,
            contentDescription = "Videollamada",
            tint = Color(0xFFFFB4A2),
            modifier = Modifier.size(80.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Aula Virtual: $nombreMateria",
            style = MaterialTheme.typography.titleLarge,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "La asistencia se registrará automáticamente al ingresar a la sesión.",
            color = Color(0xFFE0E0E0),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {
                try {
                    val roomName = "PAE_" + nombreMateria.replace(" ", "_")
                    val url = "https://meet.jit.si/$roomName"
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    context.startActivity(intent)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7D2242)) // Guinda IPN
        ) {
            Text("UNIRSE A LA CLASE VIRTUAL", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}