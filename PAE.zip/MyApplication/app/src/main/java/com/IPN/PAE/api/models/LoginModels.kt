package com.IPN.PAE.api.models

import com.google.gson.annotations.SerializedName

data class LoginRequest(
    @SerializedName("usuario")
    val usuario: String,

    @SerializedName("password")
    val password: String
)

data class UserData(
    @SerializedName("id")
    val id: String,

    @SerializedName("nombre")
    val nombre: String,

    @SerializedName("rol")
    val rol: String,

    @SerializedName("grupo")
    val grupo: String? = null
)

data class LoginResponse(
    @SerializedName("success")
    val success: Boolean,

    @SerializedName("message")
    val message: String,

    @SerializedName("access_token")
    val accessToken: String? = null,

    @SerializedName("token_type")
    val tokenType: String? = null,

    @SerializedName("expires_at")
    val expiresAt: String? = null,

    @SerializedName("user")
    val user: UserData? = null
)

data class MateriaDto(
    @SerializedName("id") val id: String,
    @SerializedName("nombre") val nombre: String,
    @SerializedName("profesor") val profesor: String,
    @SerializedName("aula") val aula: String,
    @SerializedName("horario") val horario: String
)

data class MateriaApiResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("data") val data: List<MateriaDto>
)

data class CalificacionDto(
    @SerializedName("materia") val materia: String,
    @SerializedName("u1") val u1: String,
    @SerializedName("u2") val u2: String,
    @SerializedName("u3") val u3: String,
    @SerializedName("final") val final: String
)

data class CalificacionApiResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("data") val data: List<CalificacionDto>
)

data class AnuncioDto(
    @SerializedName("id") val id: String,
    @SerializedName("autor") val autor: String,
    @SerializedName("fecha") val fecha: String,
    @SerializedName("mensaje") val mensaje: String,
    @SerializedName("materia") val materia: String?,
    @SerializedName("grupo") val grupo: String?
)

data class AnuncioApiResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("data") val data: List<AnuncioDto>
)

data class AnuncioPostRequest(
    @SerializedName("autor") val autor: String,
    @SerializedName("mensaje") val mensaje: String,
    @SerializedName("materia") val materia: String,
    @SerializedName("grupo") val grupo: String
)
