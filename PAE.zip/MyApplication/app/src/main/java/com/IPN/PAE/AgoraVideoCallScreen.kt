@file:Suppress("PackageName")

package com.IPN.PAE

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.view.SurfaceView
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import io.agora.rtc2.ChannelMediaOptions
import io.agora.rtc2.Constants
import io.agora.rtc2.IRtcEngineEventHandler
import io.agora.rtc2.RtcEngine
import io.agora.rtc2.RtcEngineConfig
import io.agora.rtc2.ScreenCaptureParameters
import io.agora.rtc2.video.VideoCanvas
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

const val AGORA_APP_ID = "d5cfb0aabc704c26ba89cca49e974f55"

// Modelo de datos para participantes
data class MeetParticipant(
    val id: String,
    val name: String,
    val uid: Int? = null,
    val isLocal: Boolean = false,
    val isCameraOn: Boolean = true,
    val isMicOn: Boolean = true,
    val isSpeaking: Boolean = false,
    val isHandRaised: Boolean = false,
    val isSharingScreen: Boolean = false,
    val avatarBgColor: Color = Color(0xFF673AB7)
)

// Modelo para emojis flotantes en pantalla con posición horizontal aleatoria
data class FloatingEmoji(
    val id: Long = System.currentTimeMillis() + Random.nextLong(1, 100000),
    val emoji: String,
    val participantName: String,
    val startXRatio: Float = Random.nextFloat() * 0.7f + 0.15f
)

@Composable
fun AgoraVideoCallContainer(
    channelName: String,
    onEndCall: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var hasPermissions by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        val cameraGranted = permissions[Manifest.permission.CAMERA] ?: false
        hasPermissions = audioGranted && cameraGranted
        if (!hasPermissions) {
            Toast.makeText(context, "Se requieren permisos de cámara y micrófono para la videollamada.", Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(Unit) {
        if (!hasPermissions) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CAMERA
                )
            )
        }
    }

    if (hasPermissions) {
        AgoraVideoCallContent(
            channelName = channelName,
            onEndCall = onEndCall,
            modifier = modifier
        )
    } else {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFF202124))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.VideocamOff,
                    contentDescription = null,
                    tint = Color(0xFFEA4335),
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Permisos necesarios no concedidos",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Google Meet requiere acceso a tu cámara y micrófono para ingresar a la videollamada.",
                    color = Color(0xFFBDC1C6),
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = {
                        permissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.RECORD_AUDIO,
                                Manifest.permission.CAMERA
                            )
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8AB4F8)),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Text("Conceder Permisos", color = Color(0xFF202124), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@SuppressLint("NewApi", "ContextCastToActivity")
@Composable
private fun AgoraVideoCallContent(
    channelName: String,
    onEndCall: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    var rtcEngine by remember { mutableStateOf<RtcEngine?>(null) }
    var isJoined by remember { mutableStateOf(false) }

    // Estados del usuario local
    var isMutedAudio by remember { mutableStateOf(false) }
    var isMutedVideo by remember { mutableStateOf(false) }
    var isSharingScreen by remember { mutableStateOf(false) }
    var isHandRaised by remember { mutableStateOf(false) }
    var pinnedParticipantId by remember { mutableStateOf<String?>(null) }

    // Emojis flotantes y menús
    var floatingEmojis by remember { mutableStateOf<List<FloatingEmoji>>(emptyList()) }
    var showEmojiPicker by remember { mutableStateOf(false) }
    var showParticipantsList by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }

    // Nombre formateado de la clase
    val formattedChannel = remember(channelName) {
        channelName.trim().ifBlank { "MICROECONOMIA - Aula Virtual" }
    }

    // Lista dinámica de participantes reales (inicia con el usuario local)
    var participants by remember {
        mutableStateOf(
            listOf(
                MeetParticipant("local", "Tú (Estudiante)", uid = 0, isLocal = true, avatarBgColor = Color(0xFF3F51B5))
            )
        )
    }

    // Actualizar participante local en la lista dinámica
    LaunchedEffect(isMutedAudio, isMutedVideo, isSharingScreen, isHandRaised) {
        participants = participants.map { p ->
            if (p.isLocal) {
                p.copy(
                    isMicOn = !isMutedAudio,
                    isCameraOn = !isMutedVideo,
                    isSharingScreen = isSharingScreen,
                    isHandRaised = isHandRaised
                )
            } else p
        }
    }

    // Launcher para MediaProjection (Transmitir Pantalla)
    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            try {
                val screenParams = ScreenCaptureParameters().apply {
                    captureAudio = true
                    captureVideo = true
                    videoCaptureParameters.width = 1280
                    videoCaptureParameters.height = 720
                    videoCaptureParameters.framerate = 15
                }
                rtcEngine?.startScreenCapture(screenParams)
                val options = ChannelMediaOptions().apply {
                    publishCameraTrack = false
                    publishScreenCaptureVideo = true
                    publishScreenCaptureAudio = true
                    publishMicrophoneTrack = !isMutedAudio
                }
                rtcEngine?.updateChannelMediaOptions(options)
                isSharingScreen = true
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Función para activar / desactivar transmisión de pantalla
    val toggleScreenShare = {
        if (!isSharingScreen) {
            try {
                val mediaProjectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                val intent = mediaProjectionManager.createScreenCaptureIntent()
                mediaProjectionLauncher.launch(intent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            try {
                rtcEngine?.stopScreenCapture()
                val options = ChannelMediaOptions().apply {
                    publishCameraTrack = !isMutedVideo
                    publishScreenCaptureVideo = false
                    publishScreenCaptureAudio = false
                    publishMicrophoneTrack = !isMutedAudio
                }
                rtcEngine?.updateChannelMediaOptions(options)
                isSharingScreen = false
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Inicializar Motor RTC de Agora
    DisposableEffect(formattedChannel) {
        val channelIdClean = formattedChannel.trim().replace(" ", "_").lowercase().ifBlank { "clase_general" }
        val eventHandler = object : IRtcEngineEventHandler() {
            override fun onJoinChannelSuccess(channel: String?, uid: Int, elapsed: Int) {
                mainHandler.post {
                    isJoined = true
                }
            }

            override fun onUserJoined(uid: Int, elapsed: Int) {
                mainHandler.post {
                    // Agregar nuevo participante dinámicamente cuando se conecta a la llamada
                    participants = participants.filterNot { it.uid == uid } + MeetParticipant(
                        id = "agora_$uid",
                        name = "Participante ($uid)",
                        uid = uid,
                        isCameraOn = true,
                        isMicOn = true,
                        avatarBgColor = Color(0xFF0F9D58)
                    )
                }
            }

            override fun onUserOffline(uid: Int, reason: Int) {
                mainHandler.post {
                    participants = participants.filterNot { it.uid == uid }
                }
            }

            override fun onAudioVolumeIndication(speakers: Array<out AudioVolumeInfo>?, totalVolume: Int) {
                mainHandler.post {
                    val speakingUids = speakers?.filter { it.volume > 8 }?.map { if (it.uid == 0) "local" else "agora_${it.uid}" }?.toSet() ?: emptySet()
                    participants = participants.map { p ->
                        val isSpeakingNow = speakingUids.contains(p.id) || (p.isLocal && !isMutedAudio && totalVolume > 12)
                        if (p.isSpeaking != isSpeakingNow) p.copy(isSpeaking = isSpeakingNow) else p
                    }
                }
            }

            override fun onError(errorCode: Int) {
                // Silencioso o log interno sin alerta emergente
            }
        }

        try {
            val config = RtcEngineConfig().apply {
                mContext = context
                mAppId = AGORA_APP_ID
                mEventHandler = eventHandler
            }
            val engine = RtcEngine.create(config)
            engine.enableVideo()
            engine.enableAudio()
            engine.enableAudioVolumeIndication(200, 3, true)
            engine.setChannelProfile(Constants.CHANNEL_PROFILE_COMMUNICATION)
            engine.startPreview()
            engine.joinChannel(null, channelIdClean, "", 0)
            rtcEngine = engine
        } catch (e: Exception) {
            e.printStackTrace()
        }

        onDispose {
            rtcEngine?.apply {
                stopPreview()
                stopScreenCapture()
                leaveChannel()
            }
            RtcEngine.destroy()
            rtcEngine = null
        }
    }

    // Identificar si alguien está transmitiendo pantalla (local o remoto)
    val presenter = remember(participants, isSharingScreen) {
        participants.firstOrNull { it.isSharingScreen } ?: if (isSharingScreen) participants.firstOrNull { it.isLocal } else null
    }

    val isScreenSharingActive = presenter != null || isSharingScreen

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF18191B))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 1. BARRA SUPERIOR (GOOGLE MEET HEADER)
            GoogleMeetTopBar(
                channelTitle = formattedChannel,
                participantCount = participants.size,
                onOpenParticipants = { showParticipantsList = true }
            )

            // CONTENIDO PRINCIPAL: TRANSMISIÓN O PARRILLA 2 x 3 DE PARTICIPANTES
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                if (isScreenSharingActive) {
                    // ==========================================
                    // MODO TRANSMISIÓN: SOLO MOSTRAR LO QUE SE TRANSMITE
                    // ==========================================
                    val activePresenter = presenter ?: participants.first { it.isLocal }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF202124))
                    ) {
                        if (activePresenter.isLocal && isSharingScreen) {
                            // VISTA DE LA PANTALLA TRANSMITIDA POR EL USUARIO LOCAL
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color(0xFF282A2D)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center,
                                    modifier = Modifier.padding(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PresentToAll,
                                        contentDescription = null,
                                        tint = Color(0xFF8AB4F8),
                                        modifier = Modifier.size(72.dp)
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = "Estás presentando tu pantalla a la clase",
                                        color = Color.White,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Los demás participantes están viendo lo que compartes.",
                                        color = Color(0xFFBDC1C6),
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        } else if (activePresenter.uid != null && rtcEngine != null) {
                            // VISTA DE VIDEO/PANTALLA DEL PARTICIPANTE EN ESCENARIO
                            AndroidView(
                                factory = { ctx ->
                                    SurfaceView(ctx).apply {
                                        rtcEngine?.setupRemoteVideo(VideoCanvas(this, VideoCanvas.RENDER_MODE_FIT, activePresenter.uid))
                                    }
                                },
                                update = { surfaceView ->
                                    rtcEngine?.setupRemoteVideo(VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_FIT, activePresenter.uid))
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        // TÍTULO DE TRANSMISIÓN
                        Row(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black.copy(alpha = 0.65f))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.PresentToAll,
                                contentDescription = null,
                                tint = Color(0xFF8AB4F8),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Transmisión en vivo • ${activePresenter.name}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        // BANNER ESTILO GOOGLE MEET (SOLO SI SE TRANSMITE PANTALLA)
                        if (isSharingScreen) {
                            Surface(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 12.dp),
                                shape = RoundedCornerShape(24.dp),
                                color = Color(0xFF202124).copy(alpha = 0.95f),
                                tonalElevation = 6.dp,
                                shadowElevation = 4.dp
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PausePresentation,
                                        contentDescription = null,
                                        tint = Color(0xFFBDC1C6),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "pae.edu.mx está compartiendo tu pantalla.",
                                        color = Color(0xFFE8EAED),
                                        fontSize = 12.sp
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Button(
                                        onClick = { toggleScreenShare() },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A73E8)),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("Dejar de compartir", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // ==========================================
                    // MODO NORMAL: PARRILLA 2 x 3 DE PARTICIPANTES VISIBLES
                    // ==========================================
                    val visibleParticipants = participants.take(5)
                    val hasMore = participants.size > 6
                    val displayList = if (hasMore) visibleParticipants else participants.take(6)
                    val remainingCount = (participants.size - displayList.size).coerceAtLeast(0)

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(displayList) { participant ->
                            ParticipantTile(
                                participant = participant,
                                rtcEngine = rtcEngine,
                                isPinned = pinnedParticipantId == participant.id,
                                onTogglePin = {
                                    pinnedParticipantId = if (pinnedParticipantId == participant.id) null else participant.id
                                },
                                modifier = Modifier.height(170.dp)
                            )
                        }

                        // TARJETA "+N MÁS" SI HAY MÁS DE 6 PARTICIPANTES
                        if (remainingCount > 0) {
                            item {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(170.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .clickable { showParticipantsList = true },
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF282A2D)),
                                    border = BorderStroke(1.dp, Color(0x22FFFFFF))
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Row(
                                                horizontalArrangement = Arrangement.Center,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(36.dp)
                                                        .clip(CircleShape)
                                                        .background(Color(0xFF673AB7)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text("P", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Text(
                                                text = "+$remainingCount más",
                                                color = Color.White,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "Ver lista completa",
                                                color = Color(0xFF8AB4F8),
                                                fontSize = 12.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // BARRA DE CONTROLES INFERIOR (CONTROLES FLOTANTES MEET)
            GoogleMeetBottomToolbar(
                isMutedAudio = isMutedAudio,
                isMutedVideo = isMutedVideo,
                isSharingScreen = isSharingScreen,
                isHandRaised = isHandRaised,
                onToggleAudio = {
                    isMutedAudio = !isMutedAudio
                    rtcEngine?.muteLocalAudioStream(isMutedAudio)
                },
                onToggleVideo = {
                    isMutedVideo = !isMutedVideo
                    rtcEngine?.muteLocalVideoStream(isMutedVideo)
                },
                onToggleScreenShare = { toggleScreenShare() },
                onToggleHandRaised = {
                    isHandRaised = !isHandRaised
                },
                onOpenEmojiPicker = { showEmojiPicker = !showEmojiPicker },
                onMoreOptions = { showMoreMenu = true },
                onEndCall = {
                    rtcEngine?.stopPreview()
                    rtcEngine?.stopScreenCapture()
                    rtcEngine?.leaveChannel()
                    onEndCall()
                }
            )
        }

        // OVERLAY DE EMOJIS FLOTANTES ANIMADOS
        floatingEmojis.forEach { emoji ->
            AnimatedFloatingEmoji(
                emoji = emoji,
                onFinished = {
                    floatingEmojis = floatingEmojis.filterNot { it.id == emoji.id }
                }
            )
        }

        // SELECTOR DE REACCIONES EMOJI FLOTANTE
        if (showEmojiPicker) {
            EmojiReactionPicker(
                onEmojiSelected = { emojiStr ->
                    floatingEmojis = floatingEmojis + FloatingEmoji(emoji = emojiStr, participantName = "Tú")
                    showEmojiPicker = false
                },
                onDismiss = { showEmojiPicker = false },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 88.dp)
            )
        }

        // DIÁLOGO DE LISTA DE PARTICIPANTES
        if (showParticipantsList) {
            ParticipantsListModal(
                participants = participants,
                onDismiss = { showParticipantsList = false }
            )
        }

        // MENÚ DE MÁS OPCIONES
        if (showMoreMenu) {
            MoreOptionsMenuModal(
                onDismiss = { showMoreMenu = false },
                onSwitchCamera = { rtcEngine?.switchCamera() },
                onToggleScreenShare = {
                    showMoreMenu = false
                    toggleScreenShare()
                }
            )
        }
    }
}

// ==========================================
// COMPONENTE: BARRA SUPERIOR EN LA LLAMADA
// ==========================================
@Composable
private fun GoogleMeetTopBar(
    channelTitle: String,
    participantCount: Int,
    onOpenParticipants: () -> Unit
) {
    val currentTime = remember {
        val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
        sdf.format(Date())
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = channelTitle,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF34A853))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Clase en vivo • pae-aula-meet",
                    color = Color(0xFFBDC1C6),
                    fontSize = 11.sp
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                onClick = onOpenParticipants,
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF282A2D)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.People,
                        contentDescription = "Participantes",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "$participantCount",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = currentTime,
                color = Color(0xFFE8EAED),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

// ==========================================
// COMPONENTE: ONDAS/ESPECTRO ANIMADO DE AUDIO
// ==========================================
@Composable
private fun SpeakingAudioBars(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "audioBars")

    val h1 by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(280, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "h1"
    )
    val h2 by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 0.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(210, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "h2"
    )
    val h3 by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(320, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "h3"
    )

    Row(
        modifier = modifier.padding(horizontal = 3.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(3.dp)
                .fillMaxHeight(h1)
                .clip(RoundedCornerShape(2.dp))
                .background(Color(0xFF34A853))
        )
        Box(
            modifier = Modifier
                .width(3.dp)
                .fillMaxHeight(h2)
                .clip(RoundedCornerShape(2.dp))
                .background(Color(0xFF34A853))
        )
        Box(
            modifier = Modifier
                .width(3.dp)
                .fillMaxHeight(h3)
                .clip(RoundedCornerShape(2.dp))
                .background(Color(0xFF34A853))
        )
    }
}

// ==========================================
// COMPONENTE: TARJETA DE PARTICIPANTE
// ==========================================
@Composable
private fun ParticipantTile(
    participant: MeetParticipant,
    rtcEngine: RtcEngine?,
    isPinned: Boolean,
    onTogglePin: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = when {
        isPinned -> Color(0xFF8AB4F8)
        participant.isSpeaking -> Color(0xFF34A853)
        else -> Color.Transparent
    }
    val strokeWidth = if (isPinned || participant.isSpeaking) 3.dp else 0.dp

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(strokeWidth, borderColor, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF202124)),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // VIDEO STREAM O AVATAR
            if (participant.isLocal && participant.isCameraOn && rtcEngine != null) {
                AndroidView(
                    factory = { ctx ->
                        SurfaceView(ctx).apply {
                            setZOrderMediaOverlay(true)
                            rtcEngine.setupLocalVideo(VideoCanvas(this, VideoCanvas.RENDER_MODE_HIDDEN, 0))
                        }
                    },
                    update = { surfaceView ->
                        rtcEngine.setupLocalVideo(VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_HIDDEN, 0))
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else if (participant.uid != null && participant.isCameraOn && rtcEngine != null) {
                AndroidView(
                    factory = { ctx ->
                        SurfaceView(ctx).apply {
                            setZOrderMediaOverlay(true)
                            rtcEngine.setupRemoteVideo(VideoCanvas(this, VideoCanvas.RENDER_MODE_HIDDEN, participant.uid))
                        }
                    },
                    update = { surfaceView ->
                        rtcEngine.setupRemoteVideo(VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_HIDDEN, participant.uid))
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                // VISTA CON AVATAR CIRCULAR SI LA CÁMARA ESTÁ APAGADA
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(participant.avatarBgColor.copy(alpha = 0.35f)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(participant.avatarBgColor),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = participant.name.take(1).uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 22.sp
                        )
                    }
                }
            }

            // ICONO O ESPECTRO ANIMADO DE MICRÓFONO EN ESQUINA SUPERIOR DERECHA
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            !participant.isMicOn -> Color(0xFF302345).copy(alpha = 0.95f)
                            participant.isSpeaking -> Color(0xFF1E3A2B).copy(alpha = 0.95f)
                            else -> Color.Black.copy(alpha = 0.6f)
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (!participant.isMicOn) {
                    Icon(
                        imageVector = Icons.Default.MicOff,
                        contentDescription = null,
                        tint = Color(0xFFF28B82),
                        modifier = Modifier.size(15.dp)
                    )
                } else if (participant.isSpeaking) {
                    SpeakingAudioBars(modifier = Modifier.height(14.dp))
                } else {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = null,
                        tint = Color(0xFF8AB4F8),
                        modifier = Modifier.size(15.dp)
                    )
                }
            }

            // INDICADOR DE MANO LEVANTADA
            if (participant.isHandRaised) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFF9AB00)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("✋", fontSize = 13.sp)
                }
            }

            // NOMBRE DEL PARTICIPANTE EN ESQUINA INFERIOR IZQUIERDA
            Row(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.Black.copy(alpha = 0.65f))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = participant.name,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // BOTÓN DE PIN AL HACER CLICK EN LA TARJETA
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable { onTogglePin() }
            )
        }
    }
}

// ==========================================
// COMPONENTE: BARRA DE CONTROLES FLOTANTE MEET
// ==========================================
@Composable
private fun GoogleMeetBottomToolbar(
    isMutedAudio: Boolean,
    isMutedVideo: Boolean,
    isSharingScreen: Boolean,
    isHandRaised: Boolean,
    onToggleAudio: () -> Unit,
    onToggleVideo: () -> Unit,
    onToggleScreenShare: () -> Unit,
    onToggleHandRaised: () -> Unit,
    onOpenEmojiPicker: () -> Unit,
    onMoreOptions: () -> Unit,
    onEndCall: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 12.dp),
        shape = RoundedCornerShape(32.dp),
        color = Color(0xFF202124),
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 1. Micrófono
            MeetControlButton(
                icon = if (isMutedAudio) Icons.Default.MicOff else Icons.Default.Mic,
                isActive = !isMutedAudio,
                isDanger = isMutedAudio,
                onClick = onToggleAudio,
                contentDescription = "Micrófono"
            )

            // 2. Cámara
            MeetControlButton(
                icon = if (isMutedVideo) Icons.Default.VideocamOff else Icons.Default.Videocam,
                isActive = !isMutedVideo,
                isDanger = isMutedVideo,
                onClick = onToggleVideo,
                contentDescription = "Cámara"
            )

            // 3. Transmitir Pantalla (Screen Share)
            MeetControlButton(
                icon = Icons.Default.PresentToAll,
                isActive = isSharingScreen,
                activeColor = Color(0xFF8AB4F8),
                onClick = onToggleScreenShare,
                contentDescription = "Transmitir pantalla"
            )

            // 4. Reacciones Emoji
            MeetControlButton(
                icon = Icons.Default.SentimentSatisfiedAlt,
                isActive = false,
                onClick = onOpenEmojiPicker,
                contentDescription = "Reacciones"
            )

            // 5. Levantar la mano
            MeetControlButton(
                icon = Icons.Default.PanTool,
                isActive = isHandRaised,
                activeColor = Color(0xFFF9AB00),
                onClick = onToggleHandRaised,
                contentDescription = "Levantar la mano"
            )

            // 6. Más opciones (3 Puntos)
            MeetControlButton(
                icon = Icons.Default.MoreVert,
                isActive = false,
                onClick = onMoreOptions,
                contentDescription = "Más opciones"
            )

            // 7. Colgar / Salir de la Clase
            IconButton(
                onClick = onEndCall,
                modifier = Modifier
                    .size(48.dp)
                    .background(Color(0xFFEA4335), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.CallEnd,
                    contentDescription = "Finalizar llamada",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
private fun MeetControlButton(
    icon: ImageVector,
    isActive: Boolean,
    isDanger: Boolean = false,
    activeColor: Color = Color(0xFF3C4043),
    onClick: () -> Unit,
    contentDescription: String
) {
    val bgColor = when {
        isDanger -> Color(0xFFEA4335)
        isActive -> activeColor
        else -> Color(0xFF3C4043)
    }

    val iconColor = when {
        isDanger -> Color.White
        isActive && activeColor == Color(0xFF8AB4F8) -> Color(0xFF202124)
        isActive && activeColor == Color(0xFFF9AB00) -> Color(0xFF202124)
        else -> Color.White
    }

    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(44.dp)
            .background(bgColor, CircleShape)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = iconColor,
            modifier = Modifier.size(22.dp)
        )
    }
}

// ==========================================
// COMPONENTE: PANEL DE REACCIONES EMOJI
// ==========================================
@Composable
private fun EmojiReactionPicker(
    onEmojiSelected: (String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .clickable { onDismiss() }
    ) {
        Surface(
            modifier = modifier,
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF3C4043),
            shadowElevation = 8.dp
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val emojis = listOf("👍", "👏", "💖", "😂", "😮", "🎉")
                emojis.forEach { emoji ->
                    Text(
                        text = emoji,
                        fontSize = 26.sp,
                        modifier = Modifier
                            .clip(CircleShape)
                            .clickable { onEmojiSelected(emoji) }
                            .padding(6.dp)
                    )
                }
            }
        }
    }
}

// ==========================================
// COMPONENTE: ANIMACIÓN DE EMOJIS FLOTANTES
// ==========================================
@Composable
private fun AnimatedFloatingEmoji(
    emoji: FloatingEmoji,
    onFinished: () -> Unit
) {
    val animY = remember { Animatable(0f) }
    val animAlpha = remember { Animatable(1f) }
    val animScale = remember { Animatable(0.4f) }

    LaunchedEffect(emoji.id) {
        launch {
            animScale.animateTo(
                targetValue = 1.3f,
                animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing)
            )
            animScale.animateTo(
                targetValue = 1.0f,
                animationSpec = tween(durationMillis = 300)
            )
        }
        launch {
            animY.animateTo(
                targetValue = -550f,
                animationSpec = tween(durationMillis = 2400, easing = LinearOutSlowInEasing)
            )
        }
        launch {
            delay(1400)
            animAlpha.animateTo(
                targetValue = 0f,
                animationSpec = tween(durationMillis = 1000, easing = LinearEasing)
            )
            onFinished()
        }
    }

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize()
    ) {
        val xPos = maxWidth * emoji.startXRatio

        Box(
            modifier = Modifier
                .offset(x = xPos, y = maxHeight - 120.dp + animY.value.dp)
                .graphicsLayer {
                    alpha = animAlpha.value
                    scaleX = animScale.value
                    scaleY = animScale.value
                }
        ) {
            Text(
                text = emoji.emoji,
                fontSize = 42.sp
            )
        }
    }
}

// ==========================================
// COMPONENTE: MODAL LISTA DE PARTICIPANTES
// ==========================================
@Composable
private fun ParticipantsListModal(
    participants: List<MeetParticipant>,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF282A2D),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Participantes (${participants.size})",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Cerrar", tint = Color.White)
                }
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 350.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(participants) { p ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(p.avatarBgColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(p.name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(p.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            if (p.isSharingScreen) {
                                Text("Presentando pantalla", color = Color(0xFF8AB4F8), fontSize = 11.sp)
                            }
                        }
                        Icon(
                            imageVector = if (p.isMicOn) Icons.Default.Mic else Icons.Default.MicOff,
                            contentDescription = null,
                            tint = if (p.isMicOn) Color(0xFF8AB4F8) else Color(0xFFEA4335),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("CERRAR", color = Color(0xFF8AB4F8))
            }
        }
    )
}

// ==========================================
// COMPONENTE: MODAL MÁS OPCIONES
// ==========================================
@Composable
private fun MoreOptionsMenuModal(
    onDismiss: () -> Unit,
    onSwitchCamera: () -> Unit,
    onToggleScreenShare: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF282A2D),
        title = {
            Text("Opciones de la llamada", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            onSwitchCamera()
                            onDismiss()
                        }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.SwitchCamera, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("Cambiar cámara", color = Color.White, fontSize = 14.sp)
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onToggleScreenShare() }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.PresentToAll, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("Compartir pantalla", color = Color.White, fontSize = 14.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCELAR", color = Color(0xFF8AB4F8))
            }
        }
    )
}
