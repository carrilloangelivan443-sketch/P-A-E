package com.IPN.PAE.ui.theme

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.IPN.PAE.MainDrawerLayout
import com.IPN.PAE.TopHeader

// --- PALETA DARK MINIMALISTA + GUINDA IPN ---
val DarkBg = Color(0xFF111218)
val DarkSurface = Color(0xFF1C1E26)
val DarkSurfaceAlt = Color(0xFF262934)
val DarkBorder = Color(0xFF2D313E)
val GuindaBright = Color(0xFF9E1F54)
val GuindaAccent = Color(0xFFD82E75)
val TextWhite = Color(0xFFF3F4F6)
val TextMuted = Color(0xFF9CA3AF)

data class AlertaVial(
    val id: String,
    val titulo: String,
    val calle: String,
    val descripcion: String,
    val estado: String,
    val zona: String,
    val tiempoRetraso: String,
)

class AnunciosActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                AnunciosScreen()
            }
        }
    }
}

@Composable
fun AnunciosScreen() {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("Alertas y Tráfico", "Anuncios IPN")

    MainDrawerLayout(currentScreenTitle = "Anuncios y Alertas") { openDrawer ->
        Box(modifier = Modifier.fillMaxSize().background(DarkBg)) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
            ) {
                TopHeader(title = "Portal de Anuncios", onOpenDrawer = openDrawer)

                TabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = Color.Transparent,
                    contentColor = TextWhite,
                    indicator = { tabPositions ->
                        if (selectedTabIndex < tabPositions.size) {
                            TabRowDefaults.SecondaryIndicator(
                                Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                                color = GuindaAccent,
                                height = 3.dp
                            )
                        }
                    }
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTabIndex == index,
                            onClick = { selectedTabIndex = index },
                            text = {
                                Text(
                                    text = title,
                                    fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTabIndex == index) TextWhite else TextMuted,
                                    fontSize = 13.sp
                                )
                            }
                        )
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    when (selectedTabIndex) {
                        0 -> PestanaAlertasViales()
                        1 -> PestanaAnunciosEscolares()
                    }
                }
            }
        }
    }
}

@Composable
fun PestanaAlertasViales() {
    val context = LocalContext.current
    val listaAlertas = remember {
        listOf(
            AlertaVial(
                id = "1",
                titulo = "Cierre por Manifestación en Bucareli",
                calle = "Eje 1 Sur Bucareli y Av. Juárez",
                descripcion = "Cierre total de carriles en dirección a la Ciudadela. Se recomienda desviación por Balderas.",
                estado = "CIERRE_TOTAL",
                zona = "Zona Centro - CECyT 5",
                tiempoRetraso = "+20 min de retraso"
            ),
            AlertaVial(
                id = "2",
                titulo = "Obras de Mantenimiento Metro Balderas",
                calle = "Av. Balderas y Tolsá",
                descripcion = "Reducción a un solo carril por trabajos de mantenimiento en la estación del Metro.",
                estado = "TRAFICO_DENSO",
                zona = "Acceso Metro Balderas",
                tiempoRetraso = "+12 min de retraso"
            ),
            AlertaVial(
                id = "3",
                titulo = "Acceso Principal Despejado",
                calle = "Calle Emilio Dondé y Plaza de la Ciudadela",
                descripcion = "Flujo vehicular constante sin contratiempos hacia la entrada principal de CECyT 5.",
                estado = "VIA_DESPEJADA",
                zona = "Entrada Principal CECyT 5",
                tiempoRetraso = "Sin retrasos"
            )
        )
    }

    var mostrarReporteDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            color = DarkSurface,
            border = BorderStroke(1.dp, DarkBorder)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Traffic,
                            contentDescription = null,
                            tint = Color(0xFF34A853),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Tráfico Escolar CECyT 5",
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF34A853).copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, Color(0xFF34A853))
                    ) {
                        Text(
                            text = "● Monitoreo Activo",
                            color = Color(0xFF34A853),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Estado del tráfico y cierres viales alrededor del plantel CECyT 5 \"Benito Juárez\" (Ciudadela / Balderas). Consulta las rutas recomendadas.",
                    color = TextMuted,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Alertas y Cierres Registrados",
                color = TextWhite,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold
            )
            IconButton(
                onClick = { mostrarReporteDialog = true },
                modifier = Modifier.size(40.dp).clip(CircleShape).background(DarkSurface)
            ) {
                Icon(Icons.Default.AddAlert, contentDescription = "Reportar Alerta", tint = GuindaAccent)
            }
        }

        listaAlertas.forEach { alerta ->
            CardAlertaVial(
                alerta = alerta,
                onVerDetalle = {
                    Toast.makeText(context, "Ruta alternativa sugerida: Usar Av. Balderas", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }

    if (mostrarReporteDialog) {
        AlertDialog(
            onDismissRequest = { mostrarReporteDialog = false },
            containerColor = DarkSurface,
            title = {
                Text("Reportar Alerta de Cierre Vial", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Ayuda a la comunidad de CECyT 5 notificando sobre cierres o tráfico denso.",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = "",
                        onValueChange = {},
                        label = { Text("Calle / Avenida del cierre", color = TextMuted) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = GuindaBright,
                            unfocusedBorderColor = DarkBorder,
                            focusedContainerColor = DarkSurfaceAlt,
                            unfocusedContainerColor = DarkSurfaceAlt
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        mostrarReporteDialog = false
                        Toast.makeText(context, "Alerta enviada para verificación comunitaria", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GuindaBright)
                ) {
                    Text("Enviar Reporte", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarReporteDialog = false }) {
                    Text("Cancelar", color = TextWhite)
                }
            }
        )
    }
}

@Composable
fun CardAlertaVial(
    alerta: AlertaVial,
    onVerDetalle: () -> Unit
) {
    val (estadoColor, estadoTexto) = when (alerta.estado) {
        "CIERRE_TOTAL" -> Color(0xFFEA4335) to "🔴 Cierre Total"
        "TRAFICO_DENSO" -> Color(0xFFFBBC04) to "🟡 Tráfico Denso"
        else -> Color(0xFF34A853) to "🟢 Vía Despejada"
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = DarkSurface,
        border = BorderStroke(1.dp, DarkBorder)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = alerta.titulo,
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = estadoColor.copy(alpha = 0.2f),
                    border = BorderStroke(1.dp, estadoColor)
                ) {
                    Text(
                        text = estadoTexto,
                        color = estadoColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = GuindaAccent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = alerta.calle,
                    color = TextWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = alerta.descripcion,
                color = TextMuted,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = DarkBorder)
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = alerta.tiempoRetraso,
                    color = GuindaAccent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                OutlinedButton(
                    onClick = onVerDetalle,
                    shape = CircleShape,
                    border = BorderStroke(1.dp, GuindaBright),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextWhite),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AltRoute,
                        contentDescription = null,
                        tint = GuindaAccent,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Ruta Alternativa", color = TextWhite, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun PestanaAnunciosEscolares() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            color = DarkSurface,
            border = BorderStroke(1.dp, DarkBorder)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "📢 Convocatoria de Becas Institucionales 2026 - CECyT 5",
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Estimada comunidad estudiantil del CECyT 5 \"Benito Juárez\": Se encuentra abierto el registro para la solicitud de becas de Transporte y Excelencia Académica.",
                    color = TextMuted,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Publicado: Hace 2 horas por Gestión Escolar CECyT 5",
                    color = TextMuted.copy(alpha = 0.7f),
                    fontSize = 11.sp
                )
            }
        }
    }
}
