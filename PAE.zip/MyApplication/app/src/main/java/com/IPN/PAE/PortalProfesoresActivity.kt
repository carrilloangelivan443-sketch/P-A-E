package com.IPN.PAE

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.IPN.PAE.ui.theme.MyApplicationTheme
import com.google.firebase.firestore.FirebaseFirestore

// Estructura de datos
data class Anuncio(
    val id: String,
    val autor: String,
    val fecha: String,
    var mensaje: String,
)

class PortalProfesoresActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Recibimos el nombre del profesor directamente desde el MainActivity Inteligente
        val nombreProfesor = intent.getStringExtra("NOMBRE_PROFESOR") ?: "Docente"

        setContent {
            MyApplicationTheme {
                PortalProfesoresApp(
                    nombreProfesor = nombreProfesor,
                ) { finish() }
            }
        }
    }
}

@Composable
fun PortalProfesoresApp(nombreProfesor: String, onBack: () -> Unit) {
    // Ya no hay currentScreen = 0 (Login). Empezamos directo en la Lista de Clases (1)
    var currentScreen by remember { mutableStateOf(1) }
    var materiaSeleccionada by remember { mutableStateOf("") }

    Box(modifier = Modifier.fillMaxSize()) {
        FondoLavaBackground(modifier = Modifier.fillMaxSize())

        when (currentScreen) {
            1 -> ListaClasesProfesorScreen(
                nombreProfesor = nombreProfesor,
                onMateriaSeleccionada = { materia ->
                    materiaSeleccionada = materia
                    currentScreen = 2
                },
                onLogout = onBack, // Regresa al Login principal
            )
            2 -> GestionMateriaProfesorScreen(
                materia = materiaSeleccionada,
                nombreProfesor = nombreProfesor,
            ) { currentScreen = 1 }
        }
    }
}

@Composable
fun ListaClasesProfesorScreen(nombreProfesor: String, onMateriaSeleccionada: (String) -> Unit, onLogout: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Mis Clases", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold)
                Text(nombreProfesor, color = Color(0xFFFFB4A2))
            }
            TextButton(onClick = onLogout) {
                Text("Cerrar Sesión", color = Color.White)
            }
        }

        // Datos de prueba (Reemplazar con Firebase después)
        val materiasAsignadas = listOf("Base de Datos", "Cálculo Integral", "Inglés V", "Probabilidad y Estadística")

        materiasAsignadas.forEach { materia ->
            // DISEÑO DE TARJETA CORREGIDO PARA EVITAR TEXTO SUPERPUESTO
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .clickable { onMateriaSeleccionada(materia) },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
                border = BorderStroke(1.dp, Color(0x33FFFFFF))
            ) {
                Column {
                    Box(modifier = Modifier.fillMaxWidth().background(Color(0xFF7D2242)).padding(16.dp)) {
                        Column {
                            Text(
                                text = materia,
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 26.sp, // Evita que líneas múltiples se aplasten
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "Aula: Edificio C - 302", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFFFB4A2))
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Class, contentDescription = null, tint = Color(0xFFE0E0E0), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Horario por definir", color = Color(0xFFE0E0E0), fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun GestionMateriaProfesorScreen(materia: String, nombreProfesor: String, onBack: () -> Unit) {
    val db = FirebaseFirestore.getInstance()
    var listaAnuncios by remember { mutableStateOf<List<Anuncio>>(emptyList()) }
    var mostrarDialogo by remember { mutableStateOf(value = false) }
    var anuncioEnEdicion by remember { mutableStateOf<Anuncio?>(null) }
    var textoNuevoAnuncio by remember { mutableStateOf("") }

    // DESCARGAR ANUNCIOS DE FIREBASE EN TIEMPO REAL
    LaunchedEffect(materia) {
        db.collection("Anuncios")
            .whereEqualTo("materia", materia)
            .addSnapshotListener { snapshot, _ ->
                if (snapshot != null) {
                    listaAnuncios = snapshot.documents.map { doc ->
                        Anuncio(
                            id = doc.id,
                            autor = doc.getString("autor") ?: "Profesor",
                            fecha = doc.getString("fecha") ?: "Reciente",
                            mensaje = doc.getString("mensaje") ?: "",
                        )
                    }
                }
            }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().systemBarsPadding()) {
            Row(modifier = Modifier.fillMaxWidth().background(Color(0xFF7D2242)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Regresar", tint = Color.White) }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(materia, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("Panel de Gestión", color = Color(0xFFFFB4A2), fontSize = 12.sp)
                }
            }
            Column(modifier = Modifier.padding(16.dp).verticalScroll(rememberScrollState())) {
                listaAnuncios.forEach { anuncio ->
                    CardAnuncioProfesor(
                        anuncio = anuncio,
                        onEdit = { 
                            anuncioEnEdicion = it
                            textoNuevoAnuncio = it.mensaje
                            mostrarDialogo = true 
                        },
                        onDelete = { 
                            // ELIMINAR DE FIREBASE
                            db.collection("Anuncios").document(anuncio.id).delete()
                        },
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }

        FloatingActionButton(
            onClick = { anuncioEnEdicion = null; textoNuevoAnuncio = ""; mostrarDialogo = true },
            containerColor = Color(0xFF7D2242),
            modifier = Modifier.align(Alignment.BottomEnd).padding(24.dp),
        ) { Icon(Icons.Default.Add, contentDescription = "Nuevo Anuncio", tint = Color.White) }
    }

    if (mostrarDialogo) {
        AlertDialog(
            onDismissRequest = { mostrarDialogo = false },
            containerColor = Color(0xFF2C2C2C),
            title = { Text(if (anuncioEnEdicion == null) "Crear Anuncio" else "Editar Anuncio", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = textoNuevoAnuncio, onValueChange = { textoNuevoAnuncio = it },
                    modifier = Modifier.fillMaxWidth().height(150.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White),
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (textoNuevoAnuncio.isNotBlank()) {
                        if (anuncioEnEdicion == null) {
                            // GUARDAR NUEVO EN FIREBASE
                            val nuevoAnuncio = hashMapOf(
                                "materia" to materia,
                                "autor" to nombreProfesor,
                                "fecha" to "Reciente",
                                "mensaje" to textoNuevoAnuncio,
                            )
                            db.collection("Anuncios").add(nuevoAnuncio)
                        } else {
                            // ACTUALIZAR EN FIREBASE
                            db.collection("Anuncios").document(anuncioEnEdicion!!.id)
                                .update("mensaje", textoNuevoAnuncio)
                        }
                        mostrarDialogo = false
                    }
                }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7D2242))) { Text("Publicar", color = Color.White) }
            },
            dismissButton = { TextButton(onClick = { mostrarDialogo = false }) { Text("Cancelar", color = Color.White) } },
        )
    }
}

@Composable
fun CardAnuncioProfesor(anuncio: Anuncio, onEdit: (Anuncio) -> Unit, onDelete: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0x33000000)), border = BorderStroke(1.dp, Color(0x33FFFFFF))) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0xFF7D2242)), contentAlignment = Alignment.Center) { Text(anuncio.autor.take(1), color = Color.White, fontWeight = FontWeight.Bold) }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(anuncio.autor, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(anuncio.fecha, color = Color(0xFFA0A0A0), fontSize = 12.sp)
                    }
                }
                Row {
                    IconButton(onClick = { onEdit(anuncio) }, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Edit, contentDescription = null, tint = Color(0xFFE0E0E0), modifier = Modifier.size(20.dp)) }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFFF8A8A), modifier = Modifier.size(20.dp)) }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(anuncio.mensaje, color = Color.White, fontSize = 14.sp)
        }
    }
}