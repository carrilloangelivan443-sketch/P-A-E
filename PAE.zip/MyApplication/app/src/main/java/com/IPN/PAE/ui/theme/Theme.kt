package com.IPN.PAE.ui.theme

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.edit

enum class AppThemeMode {
    APP_GUINDA,
    DARK,
    LIGHT,
    SYSTEM
}

val LocalAppThemeMode = staticCompositionLocalOf { AppThemeMode.APP_GUINDA }

fun getSavedThemeMode(context: Context): AppThemeMode {
    val prefsConfig = context.getSharedPreferences("AppConfig", Context.MODE_PRIVATE)
    val prefsSesion = context.getSharedPreferences("SesionIPN", Context.MODE_PRIVATE)
    val name = prefsConfig.getString("app_theme_mode", null)
        ?: prefsSesion.getString("app_theme_mode", AppThemeMode.APP_GUINDA.name)
    return try {
        AppThemeMode.valueOf(name ?: AppThemeMode.APP_GUINDA.name)
    } catch (_: Exception) {
        AppThemeMode.APP_GUINDA
    }
}

fun saveThemeMode(context: Context, mode: AppThemeMode) {
    context.getSharedPreferences("AppConfig", Context.MODE_PRIVATE)
        .edit { putString("app_theme_mode", mode.name) }
    context.getSharedPreferences("SesionIPN", Context.MODE_PRIVATE)
        .edit { putString("app_theme_mode", mode.name) }
}

data class ThemeColors(
    val bg: Color,
    val surface: Color,
    val surfaceAlt: Color,
    val border: Color,
    val primary: Color,
    val accent: Color,
    val textWhite: Color,
    val textMuted: Color
)

@Composable
fun getThemeColors(): ThemeColors {
    val themeMode = LocalAppThemeMode.current
    val systemDark = isSystemInDarkTheme()
    return when (themeMode) {
        AppThemeMode.APP_GUINDA -> ThemeColors(
            bg = Color(0xFF1B0511),
            surface = Color(0xFF2E1020),
            surfaceAlt = Color(0xFF42172F),
            border = Color(0xFF5C2341),
            primary = Color(0xFF9E1F54),
            accent = Color(0xFFD82E75),
            textWhite = Color(0xFFF3F4F6),
            textMuted = Color(0xFFD1A1B8)
        )
        AppThemeMode.DARK -> ThemeColors(
            bg = Color(0xFF111218),
            surface = Color(0xFF1C1E26),
            surfaceAlt = Color(0xFF262934),
            border = Color(0xFF2D313E),
            primary = Color(0xFF9E1F54),
            accent = Color(0xFFD82E75),
            textWhite = Color(0xFFF3F4F6),
            textMuted = Color(0xFF9CA3AF)
        )
        AppThemeMode.LIGHT -> ThemeColors(
            bg = Color(0xFFFBF8EF),
            surface = Color(0xFFFFFFFF),
            surfaceAlt = Color(0xFFF0EBE1),
            border = Color(0xFFD9D3C6),
            primary = Color(0xFF9E1F54),
            accent = Color(0xFFD82E75),
            textWhite = Color(0xFF1A1A1A),
            textMuted = Color(0xFF666666)
        )
        AppThemeMode.SYSTEM -> if (systemDark) ThemeColors(
            bg = Color(0xFF111218),
            surface = Color(0xFF1C1E26),
            surfaceAlt = Color(0xFF262934),
            border = Color(0xFF2D313E),
            primary = Color(0xFF9E1F54),
            accent = Color(0xFFD82E75),
            textWhite = Color(0xFFF3F4F6),
            textMuted = Color(0xFF9CA3AF)
        ) else ThemeColors(
            bg = Color(0xFFFBF8EF),
            surface = Color(0xFFFFFFFF),
            surfaceAlt = Color(0xFFF0EBE1),
            border = Color(0xFFD9D3C6),
            primary = Color(0xFF9E1F54),
            accent = Color(0xFFD82E75),
            textWhite = Color(0xFF1A1A1A),
            textMuted = Color(0xFF666666)
        )
    }
}

@Composable
fun MyApplicationTheme(
    themeMode: AppThemeMode? = null,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    var savedThemeMode by remember { mutableStateOf(getSavedThemeMode(context)) }

    DisposableEffect(context) {
        val configPrefs = context.getSharedPreferences("AppConfig", Context.MODE_PRIVATE)
        val sesionPrefs = context.getSharedPreferences("SesionIPN", Context.MODE_PRIVATE)

        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "app_theme_mode") {
                savedThemeMode = getSavedThemeMode(context)
            }
        }
        configPrefs.registerOnSharedPreferenceChangeListener(listener)
        sesionPrefs.registerOnSharedPreferenceChangeListener(listener)

        onDispose {
            configPrefs.unregisterOnSharedPreferenceChangeListener(listener)
            sesionPrefs.unregisterOnSharedPreferenceChangeListener(listener)
        }
    }

    val effectiveThemeMode = themeMode ?: savedThemeMode
    val systemDark = isSystemInDarkTheme()

    val colorScheme = when (effectiveThemeMode) {
        AppThemeMode.APP_GUINDA -> darkColorScheme(
            primary = Color(0xFF9E224C),
            secondary = Color(0xFF7D2242),
            tertiary = Color(0xFFFFB4A2),
            background = Color(0xFF2B0018),
            surface = Color(0xFF3B0020),
            onBackground = Color.White,
            onSurface = Color.White
        )
        AppThemeMode.DARK -> darkColorScheme(
            primary = Color(0xFF888888),
            secondary = Color(0xFF555555),
            tertiary = Color(0xFFAAAAAA),
            background = Color(0xFF0A0A0A),
            surface = Color(0xFF141414),
            onBackground = Color.White,
            onSurface = Color.White
        )
        AppThemeMode.LIGHT -> lightColorScheme(
            primary = Color(0xFF9EB6BD),
            secondary = Color(0xFF444444),
            tertiary = Color(0xFF9EB6BD),
            background = Color(0xFFFBF8EF),
            surface = Color(0xFFFBF8EF),
            onBackground = Color.Black,
            onSurface = Color.Black
        )
        AppThemeMode.SYSTEM -> if (systemDark) darkColorScheme(
            primary = Color(0xFF888888),
            secondary = Color(0xFF555555),
            tertiary = Color(0xFFAAAAAA),
            background = Color(0xFF0A0A0A),
            surface = Color(0xFF141414),
            onBackground = Color.White,
            onSurface = Color.White
        ) else lightColorScheme(
            primary = Color(0xFF9EB6BD),
            secondary = Color(0xFF444444),
            tertiary = Color(0xFF9EB6BD),
            background = Color(0xFFFBF8EF),
            surface = Color(0xFFFBF8EF),
            onBackground = Color.Black,
            onSurface = Color.Black
        )
    }

    CompositionLocalProvider(LocalAppThemeMode provides effectiveThemeMode) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}

@Composable
fun getInstitutionalColor(): Color {
    val currentThemeMode = LocalAppThemeMode.current
    val systemDark = isSystemInDarkTheme()
    return when (currentThemeMode) {
        AppThemeMode.APP_GUINDA -> Color(0xFF7D2242)
        AppThemeMode.DARK -> Color(0xFF262626)
        AppThemeMode.LIGHT -> Color(0xFF1B2A3A)
        AppThemeMode.SYSTEM -> if (systemDark) Color(0xFF262626) else Color(0xFF1B2A3A)
    }
}
