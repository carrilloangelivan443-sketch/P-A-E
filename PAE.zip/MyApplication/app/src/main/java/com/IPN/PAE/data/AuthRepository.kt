package com.IPN.PAE.data

import com.IPN.PAE.api.RetrofitClient
import com.IPN.PAE.api.models.LoginRequest
import com.IPN.PAE.api.models.LoginResponse
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Representa el resultado de la operación de autenticación (Éxito o Error).
 */
sealed class AuthResult<out T> {
    data class Success<out T>(val data: T) : AuthResult<T>()
    data class Error(val message: String) : AuthResult<Nothing>()
}

/**
 * Repositorio encargado de gestionar la comunicación de inicio de sesión con el backend PHP.
 */
class AuthRepository {

    suspend fun login(usuario: String, password: String): AuthResult<LoginResponse> =
        withContext(Dispatchers.IO) {
            try {
                val api = RetrofitClient.authApi
                val response = api.login(LoginRequest(usuario = usuario, password = password))

                if (response.isSuccessful) {
                    val body = response.body()
                    if (body != null) {
                        AuthResult.Success(body)
                    } else {
                        AuthResult.Error("Respuesta vacía del servidor.")
                    }
                } else {
                    // Procesar errores HTTP (400 Bad Request, 401 Unauthorized, 403 Forbidden, 500 Internal Error)
                    val errorBody = response.errorBody()?.string()
                    val errorMessage = parseErrorMessage(errorBody)
                        ?: when (response.code()) {
                            400 -> "Solicitud incorrecta (400)."
                            401 -> "Usuario o contraseña incorrectos (401)."
                            403 -> "Acceso denegado o cuenta desactivada (403)."
                            500 -> "Error interno del servidor (500)."
                            else -> "Error en la solicitud (${response.code()})."
                        }
                    AuthResult.Error(errorMessage)
                }
            } catch (e: Exception) {
                // Respetar la cancelación explícita de Corrutinas en Kotlin
                if (e is CancellationException) throw e

                AuthResult.Error("No se pudo conectar con el servidor: ${e.localizedMessage ?: "Verifica la conexión a la API"}")
            }
        }

    private fun parseErrorMessage(errorBodyJson: String?): String? {
        if (errorBodyJson.isNullOrEmpty()) return null
        return try {
            val jsonObject = com.google.gson.JsonParser.parseString(errorBodyJson).asJsonObject
            if (jsonObject.has("message") && !jsonObject.get("message").isJsonNull) {
                jsonObject.get("message").asString
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }
}
