package com.IPN.PAE.api.models

import com.google.gson.annotations.SerializedName

// Modelos de la API del servidor PAE (https://pae.tail98eed5.ts.net/api/).
// Los campos son "nullable" para que la app no truene si el servidor omite alguno.

data class PaeLoginRequest(
    @SerializedName("usuario") val usuario: String,
    @SerializedName("contrasena") val contrasena: String
)

data class PaeUsuario(
    @SerializedName("id") val id: String?,
    @SerializedName("nombre") val nombre: String?
)

data class PaeLoginResponse(
    @SerializedName("token") val token: String?,
    @SerializedName("rol") val rol: String?,
    @SerializedName("expira_en_horas") val expiraEnHoras: Int?,
    @SerializedName("usuario") val usuario: PaeUsuario?
)

data class PaeYoDatos(
    @SerializedName("nombre") val nombre: String?,
    @SerializedName("grupo") val grupo: String?
)

data class PaeYoResponse(
    @SerializedName("rol") val rol: String?,
    @SerializedName("datos") val datos: PaeYoDatos?
)

data class PaeCurso(
    @SerializedName("id_curso") val idCurso: Int,
    @SerializedName("materia") val materia: String?,
    @SerializedName("grupo") val grupo: String?,
    @SerializedName("profesor") val profesor: String?,
    @SerializedName("horario") val horario: String?,
    @SerializedName("aula") val aula: String?,
    @SerializedName("parcial_1") val parcial1: Double?,
    @SerializedName("parcial_2") val parcial2: Double?,
    @SerializedName("parcial_3") val parcial3: Double?,
    @SerializedName("final") val calificacionFinal: Double?
)

data class PaeCursosResponse(
    @SerializedName("cursos") val cursos: List<PaeCurso>?
)

data class PaeAnuncio(
    @SerializedName("id") val id: Int,
    @SerializedName("titulo") val titulo: String?,
    @SerializedName("contenido") val contenido: String?,
    @SerializedName("fecha") val fecha: String?,
    @SerializedName("autor") val autor: String?
)

data class PaeAnunciosResponse(
    @SerializedName("anuncios") val anuncios: List<PaeAnuncio>?
)

data class PaeAnuncioRequest(
    @SerializedName("titulo") val titulo: String,
    @SerializedName("contenido") val contenido: String
)
