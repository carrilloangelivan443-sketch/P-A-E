package com.IPN.PAE

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.core.content.edit
import coil.compose.AsyncImage
import com.IPN.PAE.ui.theme.AppThemeMode
import com.IPN.PAE.ui.theme.LocalAppThemeMode
import com.IPN.PAE.ui.theme.getInstitutionalColor
import com.IPN.PAE.ui.theme.MyApplicationTheme
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage

// --- MODELO DE DATOS COMPLETO ---
data class Materia(
    val id: String = "",
    val nombre: String = "",
    val profesor: String = "",
    val aula: String = "",
    val horario: String = "",
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp()
            }
        }
    }
}

@Composable
fun MainApp() {
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("SesionIPN", Context.MODE_PRIVATE)

    var loggedInBoleta by remember { mutableStateOf(sharedPreferences.getString("boleta", null)) }
    var loggedInGrupo by remember { mutableStateOf(sharedPreferences.getString("grupo", null)) }
    var loggedInHorario by remember { mutableStateOf(sharedPreferences.getString("horario", null)) }
    var loggedInHorarioUrl by remember { mutableStateOf(sharedPreferences.getString("horarioUrl", null)) }

    if (loggedInBoleta == null) {
        LoginScreen { boleta, grupo, horario, horarioUrl ->
            sharedPreferences.edit {
                putString("boleta", boleta)
                putString("grupo", grupo)
                putString("horario", horario)
                putString("horarioUrl", horarioUrl)
            }
            loggedInBoleta = boleta
            loggedInGrupo = grupo
            loggedInHorario = horario
            loggedInHorarioUrl = horarioUrl
        }
    } else {
        // HomeScreen ahora maneja internamente la navegación sin perder el menú lateral
        HomeScreen(
            boleta = loggedInBoleta!!,
            grupo = loggedInGrupo ?: "",
            horario = loggedInHorario ?: "",
            horarioUrl = loggedInHorarioUrl ?: "",
            onLogout = {
                sharedPreferences.edit { clear() }
                loggedInBoleta = null
                loggedInGrupo = null
                loggedInHorario = null
                loggedInHorarioUrl = null
            }
        )
    }
}

@Composable
fun LoginScreen(
    onLoginSuccess: (String, String, String, String) -> Unit
) {
    var boleta by remember { mutableStateOf(value = "") }
    var password by remember { mutableStateOf(value = "") }
    var isPasswordVisible by remember { mutableStateOf(value = false) }
    var errorMessage by remember { mutableStateOf<String?>(value = null) }
    var isLoading by remember { mutableStateOf(value = false) }

    val context = LocalContext.current
    val db = try {
        if (FirebaseApp.getApps(context).isEmpty()) {
            FirebaseApp.initializeApp(context)
        }
        FirebaseFirestore.getInstance()
    } catch (_: Exception) {
        null
    }

    Box(modifier = Modifier.fillMaxSize()) {
        FondoOlasBackground(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(modifier = Modifier.height(48.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)
            ) {
                val currentThemeMode = LocalAppThemeMode.current
                val systemDark = isSystemInDarkTheme()
                val isLightMode = currentThemeMode == AppThemeMode.LIGHT || (currentThemeMode == AppThemeMode.SYSTEM && !systemDark)
                val logoResId = if (isLightMode) R.drawable.logo_ipn_negro else R.drawable.logo_ipn
                val titleTextColor = MaterialTheme.colorScheme.onBackground

                Image(
                    painter = painterResource(id = logoResId),
                    contentDescription = "Escudo Oficial IPN",
                    modifier = Modifier.size(140.dp).padding(bottom = 12.dp)
                )
                Text(
                    text = "INSTITUTO POLITÉCNICO NACIONAL",
                    style = MaterialTheme.typography.titleMedium,
                    color = titleTextColor,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "La Técnica al Servicio de la Patria",
                    style = MaterialTheme.typography.bodySmall,
                    color = titleTextColor.copy(alpha = 0.8f),
                    fontStyle = FontStyle.Italic,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
                )
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
                border = BorderStroke(1.dp, Color(0x33FFFFFF))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Iniciar Sesión",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    OutlinedTextField(
                        value = boleta,
                        onValueChange = { boleta = it; errorMessage = null },
                        label = { Text("Boleta / Usuario Docente", color = Color(0xFFE0E0E0)) },
                        placeholder = { Text("Ej. 2023600001 o Victor Hugo", color = Color(0xFFA0A0A0)) },
                        leadingIcon = { Icon(Icons.Default.Badge, "Usuario", tint = Color.White) },
                        singleLine = true,
                        // Permitimos texto para que los profesores puedan escribir su nombre
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFFFB4A2), unfocusedBorderColor = Color(0x88FFFFFF),
                            focusedLabelColor = Color.White, unfocusedLabelColor = Color(0xFFE0E0E0), cursorColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp),
                        shape = RoundedCornerShape(16.dp)
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it; errorMessage = null },
                        label = { Text("Contraseña", color = Color(0xFFE0E0E0)) },
                        placeholder = { Text("••••••••", color = Color(0xFFA0A0A0)) },
                        leadingIcon = { Icon(Icons.Default.Lock, "Contraseña", tint = Color.White) },
                        trailingIcon = {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = null, tint = Color.White
                                )
                            }
                        },
                        singleLine = true,
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFFFB4A2), unfocusedBorderColor = Color(0x88FFFFFF),
                            focusedLabelColor = Color.White, unfocusedLabelColor = Color(0xFFE0E0E0), cursorColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        shape = RoundedCornerShape(16.dp)
                    )

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage!!,
                            color = Color(0xFFFF8A8A),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                    }

                    Button(
                        onClick = {
                            val inputBoleta = boleta.trim()
                            val inputPass = password.trim()
                            if (inputBoleta.isEmpty() || inputPass.isEmpty()) {
                                errorMessage = "Ingresa usuario y contraseña"
                                return@Button
                            }

                            if (db == null) {
                                isLoading = false
                                errorMessage = "Firebase no disponible"
                                return@Button
                            }

                            isLoading = true

                            // --- FUNCION INTERNA PARA CARGAR AL ALUMNO ---
                            fun handleDocumentAlumno(documento: DocumentSnapshot) {
                                val passwordRegistrada = (documento.getString("Contraseña")
                                    ?: documento.getString("contraseña")
                                    ?: documento.getString("Contrasena")
                                    ?: documento.getString("contrasena")
                                    ?: documento.getString("Password")
                                    ?: documento.getString("password")
                                    ?: documento["Contraseña"]?.toString()
                                    ?: documento["Password"]?.toString())?.trim() ?: ""

                                if (passwordRegistrada == inputPass) {
                                    val grupoDelAlumno = documento.getString("Grupo") ?: documento.getString("grupo") ?: ""

                                    fun fetchGroup(collectionName: String) {
                                        db.collection(collectionName).document(grupoDelAlumno)
                                            .get()
                                            .addOnSuccessListener { docGrupo ->
                                                if (docGrupo.exists()) {
                                                    val horario = docGrupo.getString("Horario") ?: docGrupo.getString("horario") ?: "Sin horario registrado"
                                                    val rawHorarioUrl = docGrupo.getString("horarioimg")
                                                        ?: docGrupo.getString("HorarioUrl") ?: ""

                                                    val storage = FirebaseStorage.getInstance()
                                                    fun resolveUrl(urlToResolve: String) {
                                                        if (urlToResolve.startsWith("gs://")) {
                                                            storage.getReferenceFromUrl(urlToResolve).downloadUrl
                                                                .addOnSuccessListener { uri: Uri ->
                                                                    isLoading = false
                                                                    onLoginSuccess(inputBoleta, grupoDelAlumno, horario, uri.toString())
                                                                }.addOnFailureListener {
                                                                    isLoading = false
                                                                    onLoginSuccess(inputBoleta, grupoDelAlumno, horario, urlToResolve)
                                                                }
                                                        } else {
                                                            isLoading = false
                                                            onLoginSuccess(inputBoleta, grupoDelAlumno, horario, urlToResolve)
                                                        }
                                                    }
                                                    resolveUrl(rawHorarioUrl)
                                                } else {
                                                    if (collectionName == "Grupos") fetchGroup("GRUPOS")
                                                    else {
                                                        isLoading = false
                                                        onLoginSuccess(inputBoleta, grupoDelAlumno, "Horario no encontrado", "")
                                                    }
                                                }
                                            }
                                            .addOnFailureListener {
                                                if (collectionName == "Grupos") fetchGroup("GRUPOS")
                                                else {
                                                    isLoading = false
                                                    onLoginSuccess(inputBoleta, grupoDelAlumno, "Error", "")
                                                }
                                            }
                                    }
                                    fetchGroup("Grupos")
                                } else {
                                    isLoading = false
                                    errorMessage = "Contraseña incorrecta"
                                }
                            }

                            // --- ENRUTADOR INTELIGENTE: ¿PROFESOR O ALUMNO? ---
                            
                            // 1. Buscamos primero en la colección de Profesores
                            db.collection("Profesores").document(inputBoleta).get()
                                .addOnSuccessListener { docProfesor ->
                                    if (docProfesor.exists()) {
                                        // ¡SÍ ES PROFESOR! Verificamos su contraseña
                                        val passwordRegistrada = (docProfesor.getString("Contraseña")
                                            ?: docProfesor.getString("contraseña")
                                            ?: docProfesor.getString("Password")
                                            ?: docProfesor.getString("password"))?.trim() ?: ""

                                        if (passwordRegistrada == inputPass) {
                                            isLoading = false
                                            // Lanzamos su portal exclusivo
                                            val intent = Intent(context, PortalProfesoresActivity::class.java).apply {
                                                putExtra("NOMBRE_PROFESOR", inputBoleta)
                                            }
                                            context.startActivity(intent)
                                        } else {
                                            isLoading = false
                                            errorMessage = "Contraseña de docente incorrecta"
                                        }
                                    } else {
                                        // 2. NO ES PROFESOR, Buscamos como Alumno
                                        db.collection("Alumnos").document(inputBoleta).get()
                                            .addOnSuccessListener { documento ->
                                                if (documento.exists()) handleDocumentAlumno(documento)
                                                else {
                                                    db.collection("AlumnosIPN").document(inputBoleta).get()
                                                        .addOnSuccessListener { doc2 ->
                                                            if (doc2.exists()) handleDocumentAlumno(doc2)
                                                            else {
                                                                isLoading = false
                                                                errorMessage = "Usuario o Boleta no registrada"
                                                            }
                                                        }
                                                        .addOnFailureListener { e -> isLoading = false; errorMessage = "Error: ${e.localizedMessage}" }
                                                }
                                            }
                                            .addOnFailureListener { e -> isLoading = false; errorMessage = "Error: ${e.localizedMessage}" }
                                    }
                                }
                                .addOnFailureListener { e -> 
                                    isLoading = false; errorMessage = "Error de conexión: ${e.localizedMessage}" 
                                }
                        },
                        enabled = !isLoading,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = getInstitutionalColor(), contentColor = Color.White),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                    ) {
                        if (isLoading) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                        else Text(text = "INICIAR SESIÓN", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    boleta: String,
    grupo: String,
    horario: String,
    horarioUrl: String,
    onLogout: () -> Unit
) {
    val db = FirebaseFirestore.getInstance()
    var materiasList by remember { mutableStateOf<List<Materia>>(emptyList()) }
    var isLoadingMaterias by remember { mutableStateOf(value = true) }

    // Estado interno para saber si estamos viendo una materia específica
    var materiaSeleccionada by remember { mutableStateOf<Materia?>(null) }

    val localDrawableResId = remember(grupo) {
        when (grupo.trim().uppercase()) {
            "5IV11" -> R.drawable.horario_5iv11
            "5IV12" -> R.drawable.horario_5iv12
            "6IV11" -> R.drawable.horario_6iv11
            else -> R.drawable.horario_default
        }
    }

    // --- CONSULTA A LA COLECCIÓN "Materias" EN FIREBASE ---
    LaunchedEffect(grupo) {
        if (grupo.isNotBlank()) {
            db.collection("Materias")
                .whereEqualTo("Grupo", grupo)
                .get()
                .addOnSuccessListener { snapshot ->
                    if (!snapshot.isEmpty) {
                        materiasList = snapshot.documents.map { doc ->
                            Materia(
                                id = doc.id,
                                nombre = doc.getString("Nombre") ?: "Materia sin nombre",
                                profesor = doc.getString("Profesor") ?: "Sin profesor asignado",
                                aula = doc.getString("Aula") ?: "",
                                horario = doc.getString("Horario") ?: "Horario por definir"
                            )
                        }.sortedBy { it.nombre }
                    }
                    isLoadingMaterias = false
                }
                .addOnFailureListener { isLoadingMaterias = false }
        } else {
            isLoadingMaterias = false
        }
    }

    // ENVOLVEMOS TODO DENTRO DE MainDrawerLayout PARA QUE LA BARRA LATERAL ESTÉ SIEMPRE PRESENTE
    MainDrawerLayout(
        currentScreenTitle = if (materiaSeleccionada == null) "Inicio" else materiaSeleccionada!!.nombre,
        onLogoutOverride = onLogout
    ) { openDrawer ->
        Box(modifier = Modifier.fillMaxSize()) {
            FondoLavaBackground(modifier = Modifier.fillMaxSize())

            // Condicional interno: si hay materia seleccionada muestra su detalle, si no, muestra el contenido normal de la Home
            if (materiaSeleccionada != null) {
                DetalleMateriaInterno(
                    materia = materiaSeleccionada!!,
                    onOpenDrawer = openDrawer,
                    onBack = { materiaSeleccionada = null }
                )
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .systemBarsPadding()
                        .verticalScroll(rememberScrollState())
                ) {
                    TopHeader(title = "Inicio", onOpenDrawer = openDrawer)

                    // TARJETA DE BIENVENIDA Y HORARIO GENERAL
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.45f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text("¡Bienvenido Politécnico!", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Boleta: $boleta", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
                            Text("Grupo: $grupo", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.tertiary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Horario: $horario", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    ScheduleCard(grupo = grupo, horarioUrl = horarioUrl, localDrawableResId = localDrawableResId)
                    Spacer(modifier = Modifier.height(24.dp))

                    // SECCIÓN DE CLASES ESTILO CLASSROOM
                    Text(
                        text = "Mis Clases",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                    )

                    if (isLoadingMaterias) {
                        val institutionalColor = getInstitutionalColor()
                        Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = institutionalColor)
                        }
                    } else if (materiasList.isEmpty()) {
                        Box(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp).height(100.dp), contentAlignment = Alignment.Center) {
                            Text(
                                text = "Aún no hay materias registradas para el grupo $grupo.",
                                color = Color(0xFFA0A0A0),
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        materiasList.forEach { materia ->
                            MateriaClassroomCard(materia = materia) {
                                // Al hacer clic, cargamos el detalle de la materia pero conservando la barra lateral
                                materiaSeleccionada = materia
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}

// --- PANTALLA DE DETALLE INTERNA CON LA BARRA LATERAL (TOPHEADER) ---
@Composable
fun DetalleMateriaInterno(materia: Materia, onOpenDrawer: () -> Unit, onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
    ) {
        // Reutilizamos tu TopHeader para mantener la barra lateral en su lugar
        TopHeader(title = materia.nombre, onOpenDrawer = onOpenDrawer)

        Column(modifier = Modifier.padding(horizontal = 24.dp)) {

            // Botón sutil para regresar a la lista de clases
            TextButton(
                onClick = onBack,
                modifier = Modifier.padding(bottom = 8.dp, top = 8.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Regresar",
                    tint = Color(0xFFFFB4A2) // Tono contrastante de tu paleta
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Volver a Mis Clases",
                    color = Color(0xFFFFB4A2),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            // Cabecera Estilo Classroom con el Nombre Real de la Materia
            val currentThemeMode = LocalAppThemeMode.current
            val systemDark = isSystemInDarkTheme()
            val isLightMode = currentThemeMode == AppThemeMode.LIGHT || (currentThemeMode == AppThemeMode.SYSTEM && !systemDark)
            val institutionalColor = if (isLightMode) Color(0xFF1B2A3A) else Color(0xFF7D2242)

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = institutionalColor),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = materia.nombre,
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Profesor: ${materia.profesor}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFFFFB4A2)
                    )
                    Text(
                        text = "Aula: ${materia.aula} | Horario: ${materia.horario}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFE0E0E0)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Espacio Futuro para Archivos y Comentarios
            Card(
                modifier = Modifier.fillMaxWidth().height(300.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
                border = BorderStroke(1.dp, Color(0x33FFFFFF))
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "Aquí los profesores subirán archivos\ny los alumnos podrán comentar.",
                        color = Color(0xFFA0A0A0),
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
// --- TARJETA DE CLASE ESTILO GOOGLE CLASSROOM ---
@Composable
fun MateriaClassroomCard(materia: Materia, onClick: () -> Unit = {}) {
    val context = LocalContext.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 8.dp)
            .height(140.dp)
            .clickable {
                val intent = Intent(context, MateriaDetalleActivity::class.java).apply {
                    putExtra("NOMBRE_MATERIA", materia.nombre)
                    putExtra("NOMBRE_PROFESOR", materia.profesor)
                }
                context.startActivity(intent)
                onClick()
            },
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        border = BorderStroke(1.dp, Color(0x22FFFFFF))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            val currentThemeMode = LocalAppThemeMode.current
            val systemDark = isSystemInDarkTheme()
            val isLightMode = currentThemeMode == AppThemeMode.LIGHT || (currentThemeMode == AppThemeMode.SYSTEM && !systemDark)
            val institutionalColor = if (isLightMode) Color(0xFF1B2A3A) else Color(0xFF7D2242)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(institutionalColor)
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
                    Text(
                        text = materia.nombre,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (materia.aula.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Aula: ${materia.aula}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFFFB4A2),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF232323)) // Gris oscuro
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Profesor",
                            tint = Color(0xFFA0A0A0),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = materia.profesor,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFD0D0D0),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = "Horario",
                            tint = Color(0xFFA0A0A0),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = materia.horario,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFA0A0A0),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ScheduleCard(grupo: String, horarioUrl: String, localDrawableResId: Int) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
        border = BorderStroke(1.dp, Color(0x33FFFFFF)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Horario Escolar - Grupo $grupo", style = MaterialTheme.typography.titleSmall, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))

            if (horarioUrl.isNotBlank()) {
                AsyncImage(model = horarioUrl, contentDescription = null, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.FillWidth)
            } else if (localDrawableResId != 0) {
                Image(painter = painterResource(id = localDrawableResId), contentDescription = null, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.FillWidth)
            } else {
                Box(modifier = Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Text("Horario no disponible para el grupo $grupo", color = Color(0xFFE0E0E0), style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, modifier = Modifier.padding(16.dp))
                }
            }
        }
    }
}