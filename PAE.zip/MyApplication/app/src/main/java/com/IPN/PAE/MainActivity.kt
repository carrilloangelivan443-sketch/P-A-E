package com.IPN.PAE

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.core.content.edit
import kotlinx.coroutines.launch
import com.IPN.PAE.data.AuthRepository
import com.IPN.PAE.data.AuthResult
import com.IPN.PAE.data.SessionManager
import com.IPN.PAE.ui.theme.AppThemeMode
import com.IPN.PAE.ui.theme.LocalAppThemeMode
import com.IPN.PAE.ui.theme.getInstitutionalColor
import com.IPN.PAE.ui.theme.MyApplicationTheme
import com.IPN.PAE.ui.theme.getThemeColors
import com.IPN.PAE.api.RetrofitClient
import com.IPN.PAE.ui.theme.AnunciosActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// --- PALETA DINÁMICA SEGÚN EL TEMA SELECCIONADO (GUINDA, OSCURO, CLARO, SISTEMA) ---
val DarkBg: Color @Composable get() = getThemeColors().bg
val DarkSurface: Color @Composable get() = getThemeColors().surface
val DarkSurfaceAlt: Color @Composable get() = getThemeColors().surfaceAlt
val DarkBorder: Color @Composable get() = getThemeColors().border
val GuindaBright: Color @Composable get() = getThemeColors().primary
val GuindaDeep: Color @Composable get() = getThemeColors().primary
val GuindaAccent: Color @Composable get() = getThemeColors().accent
val TextWhite: Color @Composable get() = getThemeColors().textWhite
val TextMuted: Color @Composable get() = getThemeColors().textMuted

val GuindaGradient: Brush
    @Composable get() = Brush.linearGradient(
        colors = listOf(GuindaBright, GuindaDeep)
    )

// Modelos de datos de la interfaz
data class MateriaItem(
    val id: String = "",
    val nombre: String = "",
    val profesor: String = "",
    val aula: String = "",
    val horario: String = "",
    val iniciales: String = "IPN",
    val descripcion: String = "Material, avisos y sesiones en vivo disponibles para el curso del semestre actual."
)

data class AccesoRapido(val titulo: String, val icono: ImageVector)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val openTab = intent?.getStringExtra("OPEN_TAB")
        setContent {
            MyApplicationTheme {
                MainApp(initialTab = openTab)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val openTab = intent.getStringExtra("OPEN_TAB")
        if (openTab != null) {
            setContent {
                MyApplicationTheme {
                    MainApp(initialTab = openTab)
                }
            }
        }
    }
}

@Composable
fun MainApp(initialTab: String? = null) {
    val context = LocalContext.current
    val sessionManager = remember { SessionManager(context) }

    var loggedInBoleta by remember { mutableStateOf(sessionManager.getBoleta()) }
    var loggedInGrupo by remember { mutableStateOf(sessionManager.getGrupo()) }
    var loggedInHorario by remember { mutableStateOf(sessionManager.getHorario()) }
    var loggedInHorarioUrl by remember { mutableStateOf(sessionManager.getHorarioUrl()) }
    var loggedInRol by remember { mutableStateOf(sessionManager.getRol()) }

    var hasLaunchedPortal by remember { mutableStateOf(false) }

    LaunchedEffect(loggedInBoleta, loggedInRol) {
        if (loggedInBoleta != null && loggedInRol.equals("profesor", ignoreCase = true) && !hasLaunchedPortal) {
            hasLaunchedPortal = true
            val intent = Intent(context, PortalProfesoresActivity::class.java).apply {
                putExtra("NOMBRE_PROFESOR", sessionManager.getNombre() ?: loggedInBoleta)
            }
            context.startActivity(intent)
        }
    }

    if (loggedInBoleta == null) {
        LoginScreen { boleta, grupo, horario, horarioUrl ->
            loggedInBoleta = sessionManager.getBoleta() ?: boleta
            loggedInGrupo = sessionManager.getGrupo() ?: grupo
            loggedInHorario = sessionManager.getHorario() ?: horario
            loggedInHorarioUrl = sessionManager.getHorarioUrl() ?: horarioUrl
            loggedInRol = sessionManager.getRol()
            hasLaunchedPortal = false
        }
    } else if (loggedInRol.equals("profesor", ignoreCase = true)) {
        Box(
            modifier = Modifier.fillMaxSize().background(DarkBg),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                Text(
                    text = "Sesión activa de Docente: ${sessionManager.getNombre() ?: loggedInBoleta}",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextWhite
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        val intent = Intent(context, PortalProfesoresActivity::class.java).apply {
                            putExtra("NOMBRE_PROFESOR", sessionManager.getNombre() ?: loggedInBoleta)
                        }
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GuindaBright)
                ) {
                    Text("ABRIR PORTAL DOCENTE", color = Color.White)
                }
                Spacer(modifier = Modifier.height(8.dp))
                TextButton(
                    onClick = {
                        sessionManager.clearSession()
                        loggedInBoleta = null
                        loggedInGrupo = null
                        loggedInHorario = null
                        loggedInHorarioUrl = null
                        loggedInRol = null
                        hasLaunchedPortal = false
                    }
                ) {
                    Text("Cerrar Sesión", color = Color(0xFFFF8A8A))
                }
            }
        }
    } else {
        HomeScreen(
            boleta = loggedInBoleta!!,
            grupo = loggedInGrupo ?: "",
            horario = loggedInHorario ?: "",
            horarioUrl = loggedInHorarioUrl ?: "",
            initialTab = initialTab,
            onLogout = {
                sessionManager.clearSession()
                loggedInBoleta = null
                loggedInGrupo = null
                loggedInHorario = null
                loggedInHorarioUrl = null
                loggedInRol = null
                hasLaunchedPortal = false
            }
        )
    }
}

@Composable
fun LoginScreen(
    onLoginSuccess: (String, String, String, String) -> Unit
) {
    var boleta by remember { mutableStateOf(value = "") }
    var password by remember { mutableStateOf(value = "") }
    var isPasswordVisible by remember { mutableStateOf(value = false) }
    var errorMessage by remember { mutableStateOf<String?>(value = null) }
    var isLoading by remember { mutableStateOf(value = false) }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val authRepository = remember { AuthRepository() }
    val sessionManager = remember { SessionManager(context) }

    Box(modifier = Modifier.fillMaxSize()) {
        FondoOlasBackground(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(modifier = Modifier.height(48.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)
            ) {
                val currentThemeMode = LocalAppThemeMode.current
                val systemDark = isSystemInDarkTheme()
                val isLightMode = currentThemeMode == AppThemeMode.LIGHT || (currentThemeMode == AppThemeMode.SYSTEM && !systemDark)
                val logoResId = if (isLightMode) R.drawable.logo_ipn_negro else R.drawable.logo_ipn

                Image(
                    painter = painterResource(id = logoResId),
                    contentDescription = "Escudo Oficial IPN",
                    modifier = Modifier.size(130.dp).padding(bottom = 12.dp)
                )
                Text(
                    text = "INSTITUTO POLITÉCNICO NACIONAL",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "La Técnica al Servicio de la Patria",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted,
                    fontStyle = FontStyle.Italic,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
                )
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = Color(0x331C1E26),
                border = BorderStroke(1.dp, Color(0x33FFFFFF))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Iniciar Sesión",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    OutlinedTextField(
                        value = boleta,
                        onValueChange = { boleta = it; errorMessage = null },
                        label = { Text("Boleta / Usuario Docente", color = TextMuted) },
                        placeholder = { Text("Ej. 2023600001", color = TextMuted) },
                        leadingIcon = { Icon(Icons.Default.Badge, "Usuario", tint = TextWhite) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Next),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite, unfocusedTextColor = TextWhite,
                            focusedBorderColor = GuindaBright, unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedLabelColor = TextWhite, unfocusedLabelColor = TextMuted, cursorColor = TextWhite,
                            focusedContainerColor = Color(0x22000000), unfocusedContainerColor = Color(0x22000000)
                        ),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp),
                        shape = RoundedCornerShape(16.dp)
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it; errorMessage = null },
                        label = { Text("Contraseña", color = TextMuted) },
                        placeholder = { Text("••••••••", color = TextMuted) },
                        leadingIcon = { Icon(Icons.Default.Lock, "Contraseña", tint = TextWhite) },
                        trailingIcon = {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = null, tint = TextWhite
                                )
                            }
                        },
                        singleLine = true,
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite, unfocusedTextColor = TextWhite,
                            focusedBorderColor = GuindaBright, unfocusedBorderColor = Color(0x33FFFFFF),
                            focusedLabelColor = TextWhite, unfocusedLabelColor = TextMuted, cursorColor = TextWhite,
                            focusedContainerColor = Color(0x22000000), unfocusedContainerColor = Color(0x22000000)
                        ),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        shape = RoundedCornerShape(16.dp)
                    )

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage!!,
                            color = Color(0xFFFF8A8A),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                    }

                    Button(
                        onClick = {
                            val inputBoleta = boleta.trim()
                            val inputPass = password.trim()
                            if (inputBoleta.isEmpty() || inputPass.isEmpty()) {
                                errorMessage = "Ingresa usuario y contraseña"
                                return@Button
                            }

                            isLoading = true
                            errorMessage = null

                            coroutineScope.launch {
                                when (val result = authRepository.login(inputBoleta, inputPass)) {
                                    is AuthResult.Success -> {
                                        isLoading = false
                                        val loginResponse = result.data
                                        if (
                                            loginResponse.success &&
                                            loginResponse.user != null &&
                                            !loginResponse.accessToken.isNullOrBlank()
                                        ) {
                                            val userData = loginResponse.user
                                            val token = loginResponse.accessToken
                                            val rol = userData.rol
                                            val userBoleta = userData.id
                                            val nombre = userData.nombre
                                            val grupo = userData.grupo.orEmpty()
                                            val horario = "Sin horario registrado"
                                            val horarioUrl = ""

                                            sessionManager.saveSession(
                                                token = token,
                                                rol = rol,
                                                boleta = userBoleta,
                                                nombre = nombre,
                                                grupo = grupo,
                                                horario = horario,
                                                horarioUrl = horarioUrl
                                            )

                                            if (rol.equals("profesor", ignoreCase = true)) {
                                                val intent = Intent(
                                                    context,
                                                    PortalProfesoresActivity::class.java
                                                ).apply {
                                                    putExtra("NOMBRE_PROFESOR", nombre)
                                                }
                                                context.startActivity(intent)
                                            } else {
                                                onLoginSuccess(
                                                    userBoleta,
                                                    grupo,
                                                    horario,
                                                    horarioUrl
                                                )
                                            }
                                        } else {
                                            errorMessage = loginResponse.message
                                        }
                                    }
                                    is AuthResult.Error -> {
                                        isLoading = false
                                        errorMessage = result.message
                                    }
                                }
                            }
                        },
                        enabled = !isLoading,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GuindaBright, contentColor = Color.White),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                    ) {
                        if (isLoading) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                        else Text(text = "INICIAR SESIÓN", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

// =========================================================
// PANTALLA PRINCIPAL CON DISEÑO DARK MINIMALISTA + GUINDA IPN
// =========================================================
@Composable
fun HomeScreen(
    boleta: String,
    grupo: String,
    horario: String,
    horarioUrl: String,
    initialTab: String? = null,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    var materiasList by remember { mutableStateOf<List<MateriaItem>>(emptyList()) }
    var isLoadingMaterias by remember { mutableStateOf(true) }

    var pantallaActual by remember { mutableStateOf(initialTab ?: "inicio") }
    var materiaSeleccionada by remember { mutableStateOf<MateriaItem?>(null) }

    // --- CONSULTA A LA API REST (MARIADB) ---
    LaunchedEffect(grupo) {
        if (grupo.isNotBlank()) {
            withContext(Dispatchers.IO) {
                try {
                    val response = RetrofitClient.authApi.getMaterias(grupo)
                    if (response.isSuccessful && response.body()?.success == true) {
                        val dtos = response.body()?.data ?: emptyList()
                        val list = dtos.map { dto ->
                            val initials = dto.nombre.split(" ")
                                .mapNotNull { it.firstOrNull()?.uppercase() }
                                .take(2)
                                .joinToString("")
                                .ifBlank { "IPN" }
                            MateriaItem(
                                id = dto.id,
                                nombre = dto.nombre,
                                profesor = dto.profesor,
                                aula = dto.aula,
                                horario = dto.horario,
                                iniciales = initials
                            )
                        }.sortedBy { it.nombre }
                        withContext(Dispatchers.Main) {
                            materiasList = list
                            isLoadingMaterias = false
                        }
                    } else {
                        withContext(Dispatchers.Main) { isLoadingMaterias = false }
                    }
                } catch (_: Exception) {
                    withContext(Dispatchers.Main) { isLoadingMaterias = false }
                }
            }
        } else {
            isLoadingMaterias = false
        }
    }

    MainDrawerLayout(
        currentScreenTitle = if (materiaSeleccionada == null) "Inicio" else materiaSeleccionada!!.nombre,
        onLogoutOverride = onLogout
    ) { openDrawer ->
        Box(modifier = Modifier.fillMaxSize().background(DarkBg)) {
            when {
                materiaSeleccionada != null -> {
                    DetalleMateriaScreen(
                        materia = materiaSeleccionada!!,
                        onOpenDrawer = openDrawer,
                        onBack = { materiaSeleccionada = null }
                    )
                }
                pantallaActual == "inicio" -> {
                    InicioPoliScreen(
                        boleta = boleta,
                        grupo = grupo,
                        onOpenDrawer = openDrawer,
                        onVerTodasClases = { pantallaActual = "clases" },
                        onSelectCategoria = { categoria ->
                            when (categoria) {
                                "Mis Clases" -> pantallaActual = "clases"
                                "Horario" -> context.startActivity(Intent(context, HorarioActivity::class.java))
                                "Calificaciones" -> context.startActivity(Intent(context, CalificacionesActivity::class.java))
                                "Anuncios" -> context.startActivity(Intent(context, AnunciosActivity::class.java))
                                "Kárdex" -> context.startActivity(Intent(context, KardexActivity::class.java))
                            }
                        }
                    )
                }
                pantallaActual == "clases" -> {
                    MisClasesScreen(
                        materias = materiasList,
                        isLoading = isLoadingMaterias,
                        onOpenDrawer = openDrawer,
                        onBack = { pantallaActual = "inicio" },
                        onMateriaClick = { materiaSeleccionada = it }
                    )
                }
            }
        }
    }
}

// =========================================================
// PANTALLA 1: INICIO CON DISEÑO DARK MINIMALISTA + GUINDA
// =========================================================
@Composable
fun InicioPoliScreen(
    boleta: String,
    grupo: String,
    onOpenDrawer: () -> Unit,
    onVerTodasClases: () -> Unit,
    onSelectCategoria: (String) -> Unit
) {
    val accesos = listOf(
        AccesoRapido("Mis Clases", Icons.Outlined.School),
        AccesoRapido("Horario", Icons.Outlined.CalendarToday),
        AccesoRapido("Calificaciones", Icons.Outlined.Assignment),
        AccesoRapido("Anuncios", Icons.Outlined.Notifications)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Header superior: Botón menú lateral + Saludo + Campana de Anuncios
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                IconButton(
                    onClick = onOpenDrawer,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(DarkSurface)
                ) {
                    Icon(Icons.Default.Person, contentDescription = "Menú", tint = TextWhite)
                }
                Column {
                    Text("Bienvenido de vuelta", fontSize = 12.sp, color = TextMuted)
                    Text("Politécnico", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                }
            }

            val context = LocalContext.current
            IconButton(
                onClick = { context.startActivity(Intent(context, AnunciosActivity::class.java)) },
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(DarkSurface)
            ) {
                Icon(Icons.Outlined.Notifications, contentDescription = "Avisos", tint = TextWhite, modifier = Modifier.size(20.dp))
            }
        }

        // Tarjeta Hero con degradado Guinda IPN
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(GuindaGradient)
                .padding(24.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "BOLETA: $boleta",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(alpha = 0.8f),
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Grupo $grupo",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Surface(
                    color = Color.White.copy(alpha = 0.18f),
                    shape = CircleShape
                ) {
                    Text(
                        text = "CECyT 5 \"Benito Juárez\"",
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        fontSize = 12.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Sección de Accesos / Categorías (Grid 2x2)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Accesos rápidos", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextWhite)
            Text(
                text = "Ver clases",
                fontSize = 13.sp,
                color = GuindaAccent,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable { onVerTodasClases() }
            )
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxWidth().height(230.dp)
        ) {
            items(accesos) { item ->
                Surface(
                    modifier = Modifier
                        .height(105.dp)
                        .clickable { onSelectCategoria(item.titulo) },
                    shape = RoundedCornerShape(22.dp),
                    color = DarkSurface,
                    border = BorderStroke(1.dp, DarkBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(DarkSurfaceAlt),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(item.icono, contentDescription = null, tint = TextWhite, modifier = Modifier.size(18.dp))
                        }
                        Text(item.titulo, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextWhite)
                    }
                }
            }
        }
    }
}

// =========================================================
// PANTALLA 2: LISTA DE CLASES (Mis Clases)
// =========================================================
@Composable
fun MisClasesScreen(
    materias: List<MateriaItem>,
    isLoading: Boolean,
    onOpenDrawer: () -> Unit,
    onBack: () -> Unit,
    onMateriaClick: (MateriaItem) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var filtroSeleccionado by remember { mutableStateOf("Todas") }
    val filtros = listOf("Todas", "Hoy", "Favoritas")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Barra superior
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(DarkSurface)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Atrás", tint = TextWhite, modifier = Modifier.size(18.dp))
            }
            Text("Mis Clases", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = TextWhite)
            IconButton(
                onClick = onOpenDrawer,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(DarkSurface)
            ) {
                Icon(Icons.Default.Person, contentDescription = "Menú", tint = TextWhite, modifier = Modifier.size(18.dp))
            }
        }

        // Buscador
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Buscar materia o profesor...", color = TextMuted, fontSize = 14.sp) },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null, tint = TextMuted) },
            trailingIcon = { Icon(Icons.Outlined.Tune, contentDescription = null, tint = TextMuted) },
            modifier = Modifier.fillMaxWidth(),
            shape = CircleShape,
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = DarkSurface,
                focusedContainerColor = DarkSurface,
                unfocusedBorderColor = Color.Transparent,
                focusedBorderColor = GuindaBright,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite
            )
        )

        // Chips horizontales
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtros) { filtro ->
                val activo = filtro == filtroSeleccionado
                Surface(
                    modifier = Modifier.clickable { filtroSeleccionado = filtro },
                    shape = CircleShape,
                    color = if (activo) GuindaAccent else DarkSurface
                ) {
                    Text(
                        text = filtro,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                        fontSize = 13.sp,
                        fontWeight = if (activo) FontWeight.Bold else FontWeight.Medium,
                        color = if (activo) Color.White else TextMuted
                    )
                }
            }
        }

        if (isLoading) {
            Box(modifier = Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = GuindaBright)
            }
        } else if (materias.isEmpty()) {
            Box(modifier = Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
                Text("No hay materias disponibles.", color = TextMuted)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                val filtradas = materias.filter {
                    it.nombre.contains(query, ignoreCase = true) || it.profesor.contains(query, ignoreCase = true)
                }
                items(filtradas) { materia ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onMateriaClick(materia) },
                        shape = CircleShape,
                        color = DarkSurface,
                        border = BorderStroke(1.dp, DarkBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(DarkSurfaceAlt),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(materia.iniciales, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Column {
                                    Text(materia.nombre, color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                    Text("${materia.aula} • ${materia.horario}", color = TextMuted, fontSize = 12.sp)
                                }
                            }

                            Text(
                                text = "Entrar",
                                color = GuindaAccent,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(end = 12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// =========================================================
// PANTALLA 3: DETALLE DE MATERIA
// =========================================================
@Composable
fun DetalleMateriaScreen(
    materia: MateriaItem,
    onOpenDrawer: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var favorita by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Top bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(DarkSurface)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Regresar", tint = TextWhite, modifier = Modifier.size(18.dp))
            }
            IconButton(
                onClick = onOpenDrawer,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(DarkSurface)
            ) {
                Icon(Icons.Default.Person, contentDescription = "Menú", tint = TextWhite, modifier = Modifier.size(18.dp))
            }
        }

        // Tarjeta destacada con degradado guinda
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(190.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(GuindaGradient)
                .padding(22.dp),
            contentAlignment = Alignment.BottomStart
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Surface(
                    color = Color.White.copy(alpha = 0.2f),
                    shape = CircleShape
                ) {
                    Text(
                        text = materia.aula,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        fontSize = 11.sp,
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Text(
                    text = materia.nombre,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "${materia.profesor}  •  ${materia.horario}",
                    fontSize = 13.sp,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
        }

        // Botones de acción (Acceder a la materia / Favorito)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = {
                    val intent = Intent(context, MateriaDetalleActivity::class.java).apply {
                        putExtra("NOMBRE_MATERIA", materia.nombre)
                        putExtra("NOMBRE_PROFESOR", materia.profesor)
                    }
                    context.startActivity(intent)
                },
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = GuindaBright)
            ) {
                Icon(Icons.Outlined.School, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Acceder a la materia", color = Color.White, fontWeight = FontWeight.Bold)
            }

            IconButton(
                onClick = { favorita = !favorita },
                modifier = Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .background(DarkSurface)
            ) {
                Icon(
                    imageVector = if (favorita) Icons.Outlined.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = "Favorito",
                    tint = if (favorita) GuindaAccent else TextWhite
                )
            }
        }

        // Descripción y avisos
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Último aviso del profesor", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextWhite)
            Text(
                text = materia.descripcion,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                color = TextMuted
            )
        }
    }
}
