package com.IPN.PAE

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.IPN.PAE.ui.theme.MyApplicationTheme

class KardexActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                KardexScreen()
            }
        }
    }
}

@Composable
fun KardexScreen() {
    MainDrawerLayout(currentScreenTitle = "Kárdex Académico") { openDrawer ->
        Box(modifier = Modifier.fillMaxSize().background(DarkBg)) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .verticalScroll(rememberScrollState()),
            ) {
                TopHeader(title = "Kárdex Académico", onOpenDrawer = openDrawer)

                Surface(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                    shape = RoundedCornerShape(22.dp),
                    color = DarkSurface,
                    border = BorderStroke(1.dp, DarkBorder),
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("Kárdex Académico General", style = MaterialTheme.typography.titleMedium, color = TextWhite, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "Promedio General Acumulado: 9.35", color = GuindaAccent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "Créditos Acreditados: 240 / 300", color = TextWhite, style = MaterialTheme.typography.bodyMedium)
                        Text(text = "Estado: Alumno Regular", color = TextWhite, style = MaterialTheme.typography.bodyMedium)
                        Text(text = "Unidad Académica: CECyT 5 \"Benito Juárez\"", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
