package com.IPN.PAE.data

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Gestor de sesiones para persistencia local de token y datos de usuario de forma segura.
 * Utiliza EncryptedSharedPreferences respaldado por Android Keystore para cifrar el token de sesión.
 * NUNCA almacena contraseñas.
 */
class SessionManager(context: Context) {

    private val prefs: SharedPreferences = createEncryptedPreferences(context)

    companion object {
        private const val PREF_NAME = "SesionIPN_Secure"
        private const val KEY_TOKEN = "token"
        private const val KEY_ROL = "rol"
        private const val KEY_BOLETA = "boleta"
        private const val KEY_NOMBRE = "nombre"
        private const val KEY_GRUPO = "grupo"
        private const val KEY_HORARIO = "horario"
        private const val KEY_HORARIO_URL = "horarioUrl"

        private fun createEncryptedPreferences(context: Context): SharedPreferences {
            return try {
                val masterKey = MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build()

                EncryptedSharedPreferences.create(
                    context,
                    PREF_NAME,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            } catch (_: Exception) {
                // Fallback seguro a SharedPreferences MODE_PRIVATE en caso de emuladores con restricciones de Keystore
                context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            }
        }
    }

    fun saveSession(
        token: String,
        rol: String,
        boleta: String,
        nombre: String,
        grupo: String? = null,
        horario: String? = null,
        horarioUrl: String? = null
    ) {
        prefs.edit {
            putString(KEY_TOKEN, token)
            putString(KEY_ROL, rol)
            putString(KEY_BOLETA, boleta)
            putString(KEY_NOMBRE, nombre)
            putString(KEY_GRUPO, grupo ?: "")
            putString(KEY_HORARIO, horario ?: "")
            putString(KEY_HORARIO_URL, horarioUrl ?: "")
        }
    }

    fun getToken(): String? = prefs.getString(KEY_TOKEN, null)
    fun getRol(): String? = prefs.getString(KEY_ROL, null)
    fun getBoleta(): String? = prefs.getString(KEY_BOLETA, null)
    fun getNombre(): String? = prefs.getString(KEY_NOMBRE, null)
    fun getGrupo(): String? = prefs.getString(KEY_GRUPO, null)
    fun getHorario(): String? = prefs.getString(KEY_HORARIO, null)
    fun getHorarioUrl(): String? = prefs.getString(KEY_HORARIO_URL, null)

    fun clearSession() {
        prefs.edit { clear() }
    }
}
