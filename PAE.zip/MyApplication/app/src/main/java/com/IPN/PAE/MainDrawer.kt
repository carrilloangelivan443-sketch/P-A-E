package com.IPN.PAE

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit
import com.IPN.PAE.data.SessionManager
import com.IPN.PAE.ui.theme.AnunciosActivity
import com.IPN.PAE.ui.theme.AppThemeMode
import com.IPN.PAE.ui.theme.LocalAppThemeMode
import kotlinx.coroutines.launch

@Composable
fun TopHeader(
    title: String,
    onOpenDrawer: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val headerTextColor = TextWhite
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(
            onClick = onOpenDrawer,
            colors = IconButtonDefaults.iconButtonColors(contentColor = headerTextColor)
        ) {
            Icon(
                imageVector = Icons.Default.Menu,
                contentDescription = "Abrir menú",
                modifier = Modifier.size(32.dp)
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = headerTextColor,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun MainDrawerLayout(
    currentScreenTitle: String,
    onLogoutOverride: (() -> Unit)? = null,
    content: @Composable (openDrawer: () -> Unit) -> Unit
) {
    val context = LocalContext.current
    val sessionManager = remember { SessionManager(context) }
    val boleta = sessionManager.getBoleta().orEmpty()
    val grupo = sessionManager.getGrupo().orEmpty()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val drawerTextColor = TextWhite

    val currentThemeMode = LocalAppThemeMode.current
    val systemDark = isSystemInDarkTheme()
    val isLightMode = currentThemeMode == AppThemeMode.LIGHT || (currentThemeMode == AppThemeMode.SYSTEM && !systemDark)
    val logoResId = if (isLightMode) R.drawable.logo_ipn_negro else R.drawable.logo_ipn

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = DarkBg,
                drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp),
                modifier = Modifier.fillMaxWidth(0.9f).fillMaxHeight()
            ) {
                Box(modifier = Modifier.fillMaxSize().background(DarkBg)) {
                    FondoOlasBackground(modifier = Modifier.fillMaxSize())

                    Column(
                        modifier = Modifier.fillMaxSize().padding(24.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp, top = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = logoResId),
                                contentDescription = null,
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "PORTAL IPN",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = drawerTextColor,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Boleta: $boleta",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = drawerTextColor.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = "Grupo: $grupo",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = GuindaAccent
                                )
                            }
                        }

                        HorizontalDivider(color = DarkBorder, thickness = 1.dp)
                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Servicios Académicos",
                            style = MaterialTheme.typography.titleMedium,
                            color = drawerTextColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        val services = listOf(
                            "Inicio" to Icons.Default.Home,
                            "Anuncios y Alertas" to Icons.Default.Notifications,
                            "Calificaciones" to Icons.Default.School,
                            "Horario de Clases" to Icons.Default.Schedule,
                            "Kárdex Académico" to Icons.Default.Assessment,
                            "Reinscripción" to Icons.Default.Description,
                            "Apariencia" to Icons.Default.Palette
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (service in services) {
                                val isSelected = service.first == currentScreenTitle
                                NavigationDrawerItem(
                                    icon = { Icon(service.second, null, tint = if (isSelected) Color.White else GuindaAccent) },
                                    label = { Text(service.first, fontWeight = FontWeight.SemiBold, color = drawerTextColor) },
                                    selected = isSelected,
                                    onClick = {
                                        scope.launch { drawerState.close() }
                                        if (!isSelected) {
                                            val targetActivity = when (service.first) {
                                                "Inicio" -> MainActivity::class.java
                                                "Anuncios y Alertas" -> AnunciosActivity::class.java
                                                "Calificaciones" -> CalificacionesActivity::class.java
                                                "Horario de Clases" -> HorarioActivity::class.java
                                                "Kárdex Académico" -> KardexActivity::class.java
                                                "Reinscripción" -> ReinscripcionActivity::class.java
                                                "Apariencia" -> AparienciaActivity::class.java
                                                else -> null
                                            }
                                            if (targetActivity != null) {
                                                val intent = Intent(context, targetActivity)
                                                if (service.first == "Inicio") {
                                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                                                }
                                                context.startActivity(intent)
                                            }
                                        }
                                    },
                                    colors = NavigationDrawerItemDefaults.colors(
                                        unselectedContainerColor = Color.Transparent,
                                        selectedContainerColor = GuindaBright
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.weight(1f))

                        OutlinedButton(
                            onClick = {
                                scope.launch { drawerState.close() }
                                if (onLogoutOverride != null) {
                                    onLogoutOverride()
                                } else {
                                    sessionManager.clearSession()
                                    val intent = Intent(context, MainActivity::class.java).apply {
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                    }
                                    context.startActivity(intent)
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, GuindaBright),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = drawerTextColor)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ExitToApp, null, tint = GuindaAccent)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("CERRAR SESIÓN", fontWeight = FontWeight.Bold, color = drawerTextColor)
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    ) {
        Box(modifier = Modifier.fillMaxSize().background(DarkBg)) {
            content {
                scope.launch { drawerState.open() }
            }
        }
    }
}

@Composable
fun PortalDrawerLayout(
    currentScreenTitle: String,
    nombreProfesor: String,
    onLogoutOverride: (() -> Unit)? = null,
    content: @Composable (openDrawer: () -> Unit) -> Unit
) {
    val context = LocalContext.current
    val sharedPreferences = remember { context.getSharedPreferences("SesionIPN", Context.MODE_PRIVATE) }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val drawerTextColor = TextWhite

    val currentThemeMode = LocalAppThemeMode.current
    val systemDark = isSystemInDarkTheme()
    val isLightMode = currentThemeMode == AppThemeMode.LIGHT || (currentThemeMode == AppThemeMode.SYSTEM && !systemDark)
    val logoResId = if (isLightMode) R.drawable.logo_ipn_negro else R.drawable.logo_ipn

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = DarkBg,
                drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp),
                modifier = Modifier.fillMaxWidth(0.9f).fillMaxHeight()
            ) {
                Box(modifier = Modifier.fillMaxSize().background(DarkBg)) {
                    FondoOlasBackground(modifier = Modifier.fillMaxSize())

                    Column(
                        modifier = Modifier.fillMaxSize().padding(24.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp, top = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = logoResId),
                                contentDescription = null,
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "PORTAL PROFESORES",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = drawerTextColor,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = nombreProfesor,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = drawerTextColor.copy(alpha = 0.8f)
                                )
                            }
                        }

                        HorizontalDivider(color = DarkBorder, thickness = 1.dp)
                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Configuración",
                            style = MaterialTheme.typography.titleMedium,
                            color = drawerTextColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        val isSelected = currentScreenTitle == "Apariencia"
                        NavigationDrawerItem(
                            icon = { Icon(Icons.Default.Palette, null, tint = GuindaAccent) },
                            label = { Text("Apariencia", fontWeight = FontWeight.SemiBold, color = drawerTextColor) },
                            selected = isSelected,
                            onClick = {
                                scope.launch { drawerState.close() }
                                if (!isSelected) {
                                    val intent = Intent(context, AparienciaActivity::class.java)
                                    context.startActivity(intent)
                                }
                            },
                            colors = NavigationDrawerItemDefaults.colors(
                                unselectedContainerColor = Color.Transparent,
                                selectedContainerColor = GuindaBright
                            )
                        )

                        Spacer(modifier = Modifier.weight(1f))

                        OutlinedButton(
                            onClick = {
                                scope.launch { drawerState.close() }
                                if (onLogoutOverride != null) {
                                    onLogoutOverride()
                                } else {
                                    sharedPreferences.edit { clear() }
                                    val intent = Intent(context, MainActivity::class.java).apply {
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                    }
                                    context.startActivity(intent)
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, GuindaBright),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = drawerTextColor)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ExitToApp, null, tint = GuindaAccent)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("CERRAR SESIÓN", fontWeight = FontWeight.Bold, color = drawerTextColor)
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    ) {
        Box(modifier = Modifier.fillMaxSize().background(DarkBg)) {
            content {
                scope.launch { drawerState.open() }
            }
        }
    }
}

// =========================================================
// BARRA DE NAVEGACIÓN INFERIOR FLOTANTE CON BOTÓN CENTRAL '+'
// =========================================================
@Composable
fun PoliFloatingBottomBar(
    selectedRoute: String,
    onSelectRoute: (String) -> Unit,
    onCenterAction: () -> Unit
) {
    val context = LocalContext.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(62.dp),
            shape = CircleShape,
            color = DarkSurface,
            border = BorderStroke(1.dp, DarkBorder)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {
                    val intent = Intent(context, MainActivity::class.java).apply {
                        putExtra("OPEN_TAB", "inicio")
                        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    }
                    context.startActivity(intent)
                }) {
                    Icon(
                        Icons.Outlined.Home,
                        contentDescription = "Inicio",
                        tint = if (selectedRoute == "inicio") TextWhite else TextMuted
                    )
                }
                IconButton(onClick = {
                    val intent = Intent(context, MainActivity::class.java).apply {
                        putExtra("OPEN_TAB", "clases")
                        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    }
                    context.startActivity(intent)
                }) {
                    Icon(
                        Icons.Outlined.Search,
                        contentDescription = "Clases / Buscar",
                        tint = if (selectedRoute == "clases") TextWhite else TextMuted
                    )
                }

                // Espacio central para el botón FAB
                Spacer(modifier = Modifier.width(48.dp))

                IconButton(onClick = { context.startActivity(Intent(context, CalificacionesActivity::class.java)) }) {
                    Icon(Icons.Outlined.Assignment, contentDescription = "Calificaciones", tint = TextMuted)
                }
                IconButton(onClick = { context.startActivity(Intent(context, HorarioActivity::class.java)) }) {
                    Icon(Icons.Outlined.CalendarToday, contentDescription = "Horario", tint = TextMuted)
                }
            }
        }

        // Botón central flotante guinda vibrante para abrir Anuncios y Alertas
        FloatingActionButton(
            onClick = onCenterAction,
            shape = CircleShape,
            containerColor = GuindaAccent,
            contentColor = Color.White,
            modifier = Modifier
                .size(52.dp)
                .offset(y = (-8).dp)
        ) {
            Icon(Icons.Default.Notifications, contentDescription = "Anuncios y Alertas")
        }
    }
}
