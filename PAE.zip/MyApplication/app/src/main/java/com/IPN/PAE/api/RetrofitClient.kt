package com.IPN.PAE.api

import android.content.Context
import com.IPN.PAE.BuildConfig
import com.IPN.PAE.data.SessionManager
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Cliente Retrofit centralizado para la API de PAE vía HTTPS.
 * Agrega automáticamente "Authorization: Bearer <token>" cuando hay sesión iniciada.
 */
object RetrofitClient {

    val BASE_URL: String = BuildConfig.BASE_URL

    @Volatile
    private var sessionManager: SessionManager? = null

    /** Se llama una sola vez al arrancar la app (ver PaeApplication). */
    fun init(context: Context) {
        if (sessionManager == null) {
            sessionManager = SessionManager(context.applicationContext)
        }
    }

    private val authInterceptor = Interceptor { chain ->
        val original = chain.request()
        val token = sessionManager?.getToken()
        if (original.header("Authorization") == null && !token.isNullOrBlank()) {
            chain.proceed(original.newBuilder().header("Authorization", "Bearer $token").build())
        } else {
            chain.proceed(original)
        }
    }

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.NONE
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(authInterceptor)
        .addInterceptor(loggingInterceptor)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    val paeApi: PaeApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(PaeApi::class.java)
    }

    /** Las pantallas usan esta interfaz; el adaptador la traduce a la API real. */
    val authApi: AuthApi by lazy { PaeApiAdapter(paeApi) }
}
