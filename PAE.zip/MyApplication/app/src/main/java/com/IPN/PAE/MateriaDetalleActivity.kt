package com.IPN.PAE

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.IPN.PAE.ui.theme.MyApplicationTheme
import com.IPN.PAE.api.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MateriaDetalleActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val nombreMateria = intent.getStringExtra("NOMBRE_MATERIA") ?: "Base de Datos"
        val nombreProfesor = intent.getStringExtra("NOMBRE_PROFESOR") ?: "Profesor Asignado"

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MateriaDetalleScreen(
                    nombreMateria = nombreMateria,
                    nombreProfesor = nombreProfesor,
                ) { finish() }
            }
        }
    }
}

@Composable
fun MateriaDetalleScreen(nombreMateria: String, nombreProfesor: String, onBack: () -> Unit) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("Novedades", "Tareas", "En vivo")

    Box(modifier = Modifier.fillMaxSize().background(DarkBg)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            // --- HEADER DARK MINIMALISTA ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.size(40.dp).clip(CircleShape).background(DarkSurfaceAlt)
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Regresar",
                        tint = TextWhite,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = nombreMateria,
                        style = MaterialTheme.typography.titleLarge,
                        color = TextWhite,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = nombreProfesor,
                        style = MaterialTheme.typography.bodySmall,
                        color = GuindaAccent
                    )
                }
            }

            // --- TAB ROW (Pestañas) ---
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = DarkSurface,
                contentColor = TextWhite,
                indicator = { tabPositions ->
                    if (selectedTabIndex < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                            color = GuindaAccent,
                            height = 3.dp
                        )
                    }
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) TextWhite else TextMuted
                            )
                        }
                    )
                }
            }

            // --- CONTENIDO DE LAS PESTAÑAS (NOVEDADES, TAREAS, EN VIVO) ---
            Box(modifier = Modifier.weight(1f)) {
                when (selectedTabIndex) {
                    0 -> PestañaNovedades(nombreMateria)
                    1 -> PestañaTareas()
                    2 -> PestañaVideollamada(nombreMateria)
                }
            }
        }
    }
}

// ==========================================
// PESTAÑA 1: NOVEDADES / MURO DEL PROFESOR
// ==========================================
@Composable
fun PestañaNovedades(nombreMateria: String) {
    var listaAnuncios by remember { mutableStateOf<List<Anuncio>>(emptyList()) }
    var isLoading by remember { mutableStateOf(value = true) }

    LaunchedEffect(nombreMateria) {
        withContext(Dispatchers.IO) {
            try {
                val response = RetrofitClient.authApi.getAnuncios(materia = nombreMateria, grupo = null)
                if (response.isSuccessful && response.body()?.success == true) {
                    val dtos = response.body()?.data ?: emptyList()
                    val mapped = dtos.map { dto ->
                        Anuncio(
                            id = dto.id,
                            autor = dto.autor,
                            fecha = dto.fecha,
                            mensaje = dto.mensaje
                        )
                    }
                    withContext(Dispatchers.Main) {
                        listaAnuncios = mapped
                        isLoading = false
                    }
                } else {
                    withContext(Dispatchers.Main) { isLoading = false }
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) { isLoading = false }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(DarkBg)) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center),
                color = GuindaBright,
            )
        } else if (listaAnuncios.isEmpty()) {
            Text(
                text = "Aún no hay anuncios en esta clase.",
                color = TextMuted,
                modifier = Modifier.align(Alignment.Center),
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                listaAnuncios.forEach { anuncio ->
                    CardAnuncio(
                        autor = anuncio.autor,
                        fecha = anuncio.fecha,
                        mensaje = anuncio.mensaje,
                    )
                }
            }
        }
    }
}

@Composable
fun CardAnuncio(autor: String, fecha: String, mensaje: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = DarkSurface,
        border = BorderStroke(1.dp, DarkBorder)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(GuindaBright),
                    contentAlignment = Alignment.Center
                ) {
                    Text(autor.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = autor, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(text = fecha, color = TextMuted, fontSize = 12.sp)
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = mensaje,
                color = TextWhite.copy(alpha = 0.9f),
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = DarkBorder)

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Comentarios", tint = TextMuted, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Agregar un comentario de clase...", color = TextMuted, fontSize = 12.sp)
            }
        }
    }
}

// ==========================================
// PESTAÑA 2: TAREAS
// ==========================================
@Composable
fun PestañaTareas() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        CardTarea(
            titulo = "Diagrama Entidad-Relación",
            fechaEntrega = "Entrega: Mañana 23:59",
            estado = "Asignada"
        )
        CardTarea(
            titulo = "Investigación: Llaves Foráneas",
            fechaEntrega = "Vencida el Lunes",
            estado = "Sin entregar",
            colorEstado = Color(0xFFFF8A8A)
        )
    }
}

@Composable
fun CardTarea(titulo: String, fechaEntrega: String, estado: String, colorEstado: Color = GuindaAccent) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = DarkSurface,
        border = BorderStroke(1.dp, DarkBorder)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(DarkSurfaceAlt),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.AutoMirrored.Filled.Assignment, contentDescription = "Tarea", tint = TextWhite)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = titulo, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = fechaEntrega, color = TextMuted, fontSize = 12.sp)
            }
            Text(text = estado, color = colorEstado, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

// ==========================================
// PESTAÑA 3: VIDEOLLAMADA Y CLASES EN LÍNEA (EN VIVO)
// ==========================================
@Composable
fun PestañaVideollamada(nombreMateria: String) {
    var isInCall by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize().background(DarkBg)) {
        if (isInCall) {
            AgoraVideoCallContainer(
                channelName = nombreMateria,
                onEndCall = { isInCall = false }
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.VideoCall,
                    contentDescription = "Videollamada",
                    tint = GuindaAccent,
                    modifier = Modifier.size(80.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Aula Virtual (En Vivo)",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextWhite,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "La asistencia se registrará automáticamente al ingresar a la sesión de clase.",
                    color = TextMuted,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Spacer(modifier = Modifier.height(32.dp))

                Button(
                    onClick = { isInCall = true },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(22.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GuindaBright)
                ) {
                    Text("UNIRSE A LA CLASE EN VIVO", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}
