package com.IPN.PAE

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.IPN.PAE.api.RetrofitClient
import com.IPN.PAE.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.round

// Estructura de datos para almacenar temporalmente cada materia leída de MariaDB
data class CalificacionMateria(
    val nombre: String,
    val u1: String,
    val u2: String,
    val u3: String,
    val final: String,
)

class CalificacionesActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CalificacionesScreen { finish() }
            }
        }
    }
}

@Composable
fun CalificacionesScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("SesionIPN", Context.MODE_PRIVATE)
    val boleta = sharedPreferences.getString("boleta", "") ?: ""

    var listaCalificaciones by remember { mutableStateOf<List<CalificacionMateria>>(emptyList()) }
    var isLoading by remember { mutableStateOf(value = true) }

    LaunchedEffect(boleta) {
        if (boleta.isNotBlank()) {
            withContext(Dispatchers.IO) {
                try {
                    val response = RetrofitClient.authApi.getCalificaciones(boleta)
                    if (response.isSuccessful && response.body()?.success == true) {
                        val dtos = response.body()?.data ?: emptyList()
                        val materiasTemp = dtos.map { dto ->
                            var promedioFinal = dto.final
                            if (promedioFinal == "-" || promedioFinal.isBlank()) {
                                val validas = listOfNotNull(dto.u1.toFloatOrNull(), dto.u2.toFloatOrNull(), dto.u3.toFloatOrNull())
                                if (validas.isNotEmpty()) {
                                    val promedio = validas.sum() / validas.size
                                    promedioFinal = (round(promedio * 10.0) / 10.0).toString()
                                }
                            }
                            CalificacionMateria(
                                nombre = dto.materia,
                                u1 = dto.u1,
                                u2 = dto.u2,
                                u3 = dto.u3,
                                final = promedioFinal
                            )
                        }
                        withContext(Dispatchers.Main) {
                            listaCalificaciones = materiasTemp.sortedBy { it.nombre }
                            isLoading = false
                        }
                    } else {
                        withContext(Dispatchers.Main) { isLoading = false }
                    }
                } catch (_: Exception) {
                    withContext(Dispatchers.Main) { isLoading = false }
                }
            }
        } else {
            isLoading = false
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        FondoLavaBackground(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack, colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Regresar", modifier = Modifier.size(32.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("Calificaciones", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold)
            }

            Column(modifier = Modifier.padding(horizontal = 24.dp)) {
                if (isLoading) {
                    Box(modifier = Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Color(0xFFFFB4A2))
                    }
                } else if (listaCalificaciones.isEmpty()) {
                    Text(text = "No hay calificaciones registradas.", color = Color.White, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                } else {
                    for (materia in listaCalificaciones) {
                        TarjetaMateria(materia)
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun TarjetaMateria(calificacion: CalificacionMateria) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
        border = BorderStroke(1.dp, Color(0x33FFFFFF)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = calificacion.nombre,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold,
            )

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 12.dp),
                color = Color(0x22FFFFFF),
                thickness = 1.dp,
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                ElementoCalificacion(titulo = "Unidad 1", valor = calificacion.u1)
                ElementoCalificacion(titulo = "Unidad 2", valor = calificacion.u2)
                ElementoCalificacion(titulo = "Unidad 3", valor = calificacion.u3)
                ElementoCalificacion(titulo = "Final", valor = calificacion.final, esFinal = true)
            }
        }
    }
}

@Composable
fun ElementoCalificacion(titulo: String, valor: String, esFinal: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = titulo,
            color = if (esFinal) Color(0xFFFFB4A2) else Color(0xFFA0A0A0),
            fontSize = 12.sp,
            fontWeight = if (esFinal) FontWeight.Bold else FontWeight.Normal,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = valor,
            color = if (esFinal) Color(0xFFFFB4A2) else Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
        )
    }
}
