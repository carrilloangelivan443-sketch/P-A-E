package com.IPN.PAE.api

import com.IPN.PAE.api.models.PaeAnuncioRequest
import com.IPN.PAE.api.models.PaeAnunciosResponse
import com.IPN.PAE.api.models.PaeCursosResponse
import com.IPN.PAE.api.models.PaeLoginRequest
import com.IPN.PAE.api.models.PaeLoginResponse
import com.IPN.PAE.api.models.PaeYoResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path

/**
 * Rutas reales de la API del servidor PAE.
 * El token se agrega solo (ver RetrofitClient), salvo en "yo" justo después del login.
 */
interface PaeApi {

    @POST("login")
    suspend fun login(@Body body: PaeLoginRequest): Response<PaeLoginResponse>

    @GET("yo")
    suspend fun yo(@Header("Authorization") autorizacion: String?): Response<PaeYoResponse>

    @GET("cursos")
    suspend fun cursos(): Response<PaeCursosResponse>

    @GET("cursos/{id}/anuncios")
    suspend fun anuncios(@Path("id") idCurso: Int): Response<PaeAnunciosResponse>

    @POST("cursos/{id}/anuncios")
    suspend fun publicarAnuncio(
        @Path("id") idCurso: Int,
        @Body body: PaeAnuncioRequest
    ): Response<Map<String, Any>>

    @POST("logout")
    suspend fun logout(): Response<Map<String, Any>>
}
