package com.IPN.PAE

import android.app.Application
import com.IPN.PAE.api.RetrofitClient

/** Se ejecuta al abrir la app, antes que cualquier pantalla. */
class PaeApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        RetrofitClient.init(this)
    }
}
