# Cambios: conexión de la app con el servidor PAE

La app ahora usa la API del servidor: https://pae.tail98eed5.ts.net/api/

## Archivos nuevos
- `app/src/main/java/com/IPN/PAE/PaeApplication.kt` — inicializa el cliente de red al abrir la app.
- `app/src/main/java/com/IPN/PAE/api/PaeApi.kt` — rutas reales de la API (login, yo, cursos, anuncios).
- `app/src/main/java/com/IPN/PAE/api/PaeApiAdapter.kt` — traduce entre las pantallas y la API.
- `app/src/main/java/com/IPN/PAE/api/models/PaeModels.kt` — modelos de datos de la API.

## Archivos modificados
- `app/build.gradle.kts` — BASE_URL apunta al servidor (antes: túnel temporal de Cloudflare).
- `app/src/main/AndroidManifest.xml` — se registró `PaeApplication`.
- `app/src/main/java/com/IPN/PAE/api/RetrofitClient.kt` — agrega el token (Authorization: Bearer) en cada petición.
- `app/src/main/java/com/IPN/PAE/PortalProfesoresActivity.kt` — las clases del profesor vienen de la API (antes era una lista fija).

## Qué funciona con la base real
- Inicio de sesión de alumnos (boleta) y profesores (usuario).
- Mis Clases (materias, profesor, aula y horario).
- Calificaciones (parciales y final).
- Novedades de cada materia, y publicar anuncios desde el portal de profesores.

## Pendiente
- Kárdex y Reinscripción siguen con datos de ejemplo (la API ya tiene /kardex).
- Tareas y asistencia automática (la API ya las tiene, falta la pantalla).
- La carpeta `backend/` es el backend anterior y ya no se usa; el nuevo vive en el servidor.
