-- =========================================================================
-- ESQUEMA SQL: Tabla `sesiones` para autenticación con Tokens Seguros en PAE
-- Base de Datos: pae_demo
-- Engine: InnoDB | Charset: utf8mb4
-- =========================================================================

-- IMPORTANTE: Generar la tabla ejecutando el siguiente código SQL en phpMyAdmin
-- o MariaDB CLI (mysql -u root -p pae_demo < schema_sesiones.sql).

CREATE TABLE IF NOT EXISTS `sesiones` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` VARCHAR(50) NOT NULL COMMENT 'Boleta del alumno o Num_Empleado del profesor',
    `rol` ENUM('alumno', 'profesor') NOT NULL COMMENT 'Rol del usuario en el sistema',
    `token_hash` VARCHAR(64) NOT NULL UNIQUE COMMENT 'Hash SHA-256 del token binario generado en PHP (random_bytes)',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Fecha y hora de inicio de sesión',
    `expires_at` DATETIME NOT NULL COMMENT 'Fecha y hora de expiración de la sesión (ej. +24 Horas)',
    `ip_address` VARCHAR(45) NULL COMMENT 'Dirección IP del cliente (IPv4 / IPv6)',
    `user_agent` TEXT NULL COMMENT 'Información del dispositivo / navegador',

    INDEX `idx_token_hash` (`token_hash`),
    INDEX `idx_user` (`user_id`, `rol`),
    INDEX `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- EXPLICACIÓN DE LA ESTRUCTURA Y SEGURIDAD:
-- 1. `token_hash`: El cliente Android almacena únicamente el token aleatorio en crudo (ej. 64 caracteres hex).
--    En la base de datos se guarda el HASH SHA-256 del token, NUNCA el token en texto plano.
--    Si la base de datos llegara a ser comprometida, los atacantes no podrán suplantar sesiones activas.
-- 2. `user_id` y `rol`: Identifica de forma unívoca si la sesión pertenece a un Alumno (Boleta) o a un Profesor (Num_Empleado).
-- 3. `expires_at`: Permite validar la vigencia temporal de la sesión (ej. DELETE FROM sesiones WHERE expires_at < NOW()).
-- 4. `ip_address` y `user_agent`: Facilitan auditoría de seguridad y detección de inicios de sesión sospechosos.
