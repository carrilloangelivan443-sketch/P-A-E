<?php
/**
 * Endpoint de Autenticación de Usuarios (Alumnos y Profesores) para PAE
 * Ruta: POST /api/auth/login.php
 */

header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Manejar preflight OPTIONS request para CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Permitir solo método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido'
    ]);
    exit();
}

// 1. CONEXIÓN A LA BASE DE DATOS
$pdo = null;

// Intentar incluir la configuración existente en el entorno XAMPP o local
$configPaths = [
    '/opt/lampp/htdocs/pae-api/config/database.php',
    __DIR__ . '/../../../config/database.php',
    __DIR__ . '/../../config/database.php',
    __DIR__ . '/../config/database.php'
];

foreach ($configPaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        break;
    }
}

// Fallback por si $pdo no fue instanciado en el archivo de configuración
if (!isset($pdo) || !($pdo instanceof PDO)) {
    try {
        $host    = '127.0.0.1';
        $db      = 'pae_demo';
        $user    = 'root';
        $pass    = '';
        $charset = 'utf8mb4';

        $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        $pdo = new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Error de conexión con la base de datos'
        ]);
        exit();
    }
}

// 2. LECTURA Y VALIDACIÓN DEL CUERPO JSON
$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

$usuario  = isset($data['usuario']) ? trim((string)$data['usuario']) : '';
$password = isset($data['password']) ? trim((string)$data['password']) : '';

if (empty($usuario) || empty($password)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Ingresa usuario y contraseña'
    ]);
    exit();
}

try {
    // 3. AUTENTICACIÓN PARA ALUMNOS (Identificador: Boleta)
    $stmtAlumno = $pdo->prepare("
        SELECT Boleta, Nombre, Contrasena, Id_Grupo_Base, Correo, Activo
        FROM alumnos
        WHERE Boleta = :usuario
        LIMIT 1
    ");
    $stmtAlumno->execute([':usuario' => $usuario]);
    $alumno = $stmtAlumno->fetch(PDO::FETCH_ASSOC);

    if ($alumno) {
        // Verificar si la cuenta está activa
        if ((int)$alumno['Activo'] !== 1) {
            http_response_code(403);
            echo json_encode([
                'success' => false,
                'message' => 'La cuenta de alumno está desactivada.'
            ]);
            exit();
        }

        // Verificar la contraseña con hash bcrypt de PHP
        if (password_verify($password, $alumno['Contrasena'])) {
            // Generar Token Criptográficamente Seguro
            $rawToken  = bin2hex(random_bytes(32));
            $tokenHash = hash('sha256', $rawToken);
            $expiresAt = date('Y-m-d H:i:s', time() + (24 * 3600)); // Vigencia de 24 horas

            // Registrar la sesión en la base de datos MariaDB
            try {
                $stmtSession = $pdo->prepare("
                    INSERT INTO sesiones (user_id, rol, token_hash, expires_at, ip_address, user_agent)
                    VALUES (:user_id, 'alumno', :token_hash, :expires_at, :ip_address, :user_agent)
                ");
                $stmtSession->execute([
                    ':user_id'    => $alumno['Boleta'],
                    ':token_hash' => $tokenHash,
                    ':expires_at' => $expiresAt,
                    ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
                    ':user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
                ]);
            } catch (Exception $e) {
                // Si la tabla sesiones aún no existe, se ignora silenciosamente para no interrumpir el inicio de sesión
            }

            // Consultar datos de grupo y horario del alumno
            $grupoNombre = $alumno['Id_Grupo_Base'] ?? '';
            $horario     = 'Sin horario registrado';
            $horarioUrl  = '';

            if (!empty($alumno['Id_Grupo_Base'])) {
                try {
                    $stmtGrupo = $pdo->prepare("
                        SELECT Nombre_Grupo, Horario, Horario_Url
                        FROM grupos
                        WHERE Id_Grupo = :grupo OR Nombre_Grupo = :grupo
                        LIMIT 1
                    ");
                    $stmtGrupo->execute([':grupo' => $alumno['Id_Grupo_Base']]);
                    $grupoData = $stmtGrupo->fetch(PDO::FETCH_ASSOC);
                    if ($grupoData) {
                        $grupoNombre = $grupoData['Nombre_Grupo'] ?? $alumno['Id_Grupo_Base'];
                        $horario     = $grupoData['Horario'] ?? $horario;
                        $horarioUrl  = $grupoData['Horario_Url'] ?? '';
                    }
                } catch (Exception $e) {
                    // Ignorar variaciones en la tabla grupos
                }
            }

            http_response_code(200);
            echo json_encode([
                'success' => true,
                'message' => 'Inicio de sesión exitoso',
                'data'    => [
                    'token'      => $rawToken,
                    'rol'        => 'alumno',
                    'id'         => $alumno['Boleta'],
                    'boleta'     => $alumno['Boleta'],
                    'nombre'     => $alumno['Nombre'],
                    'grupo'      => $grupoNombre,
                    'horario'    => $horario,
                    'horarioUrl' => $horarioUrl
                ]
            ]);
            exit();
        } else {
            http_response_code(401);
            echo json_encode([
                'success' => false,
                'message' => 'Contraseña incorrecta'
            ]);
            exit();
        }
    }

    // 4. AUTENTICACIÓN PARA PROFESORES (Identificador: Nombre_Completo o Usuario)
    $stmtProfesor = $pdo->prepare("
        SELECT Num_Empleado, Nombre_Completo, Usuario, Contrasena, Activo
        FROM profesores
        WHERE Usuario = :usuario OR Nombre_Completo = :usuario
        LIMIT 1
    ");
    $stmtProfesor->execute([':usuario' => $usuario]);
    $profesor = $stmtProfesor->fetch(PDO::FETCH_ASSOC);

    if ($profesor) {
        // Verificar estado activo del profesor
        if ((int)$profesor['Activo'] !== 1) {
            http_response_code(403);
            echo json_encode([
                'success' => false,
                'message' => 'La cuenta de docente está desactivada.'
            ]);
            exit();
        }

        // Verificar la contraseña del profesor
        if (password_verify($password, $profesor['Contrasena'])) {
            $rawToken  = bin2hex(random_bytes(32));
            $tokenHash = hash('sha256', $rawToken);
            $expiresAt = date('Y-m-d H:i:s', time() + (24 * 3600));

            try {
                $stmtSession = $pdo->prepare("
                    INSERT INTO sesiones (user_id, rol, token_hash, expires_at, ip_address, user_agent)
                    VALUES (:user_id, 'profesor', :token_hash, :expires_at, :ip_address, :user_agent)
                ");
                $stmtSession->execute([
                    ':user_id'    => (string)$profesor['Num_Empleado'],
                    ':token_hash' => $tokenHash,
                    ':expires_at' => $expiresAt,
                    ':ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
                    ':user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
                ]);
            } catch (Exception $e) {
                // Silencioso si no se ha creado aún la tabla de sesiones
            }

            http_response_code(200);
            echo json_encode([
                'success' => true,
                'message' => 'Inicio de sesión exitoso como docente',
                'data'    => [
                    'token'      => $rawToken,
                    'rol'        => 'profesor',
                    'id'         => (string)$profesor['Num_Empleado'],
                    'boleta'     => $profesor['Nombre_Completo'],
                    'nombre'     => $profesor['Nombre_Completo'],
                    'usuario'    => $profesor['Usuario'] ?? $profesor['Nombre_Completo']
                ]
            ]);
            exit();
        } else {
            http_response_code(401);
            echo json_encode([
                'success' => false,
                'message' => 'Contraseña de docente incorrecta'
            ]);
            exit();
        }
    }

    // 5. NINGÚN REGISTRO ENCONTRADO
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Usuario o Boleta no registrada'
    ]);
    exit();

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error interno en el servidor'
    ]);
    exit();
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Ocurrió un error inesperado'
    ]);
    exit();
}
