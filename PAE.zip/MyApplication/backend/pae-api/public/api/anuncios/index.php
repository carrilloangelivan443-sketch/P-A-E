<?php
/**
 * Endpoint para Anuncios (GET para listar por materia/grupo, POST para crear)
 * Ruta: /api/anuncios/index.php
 */

header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . '/../../config/database.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $materia = isset($_GET['materia']) ? trim($_GET['materia']) : '';
    $grupo = isset($_GET['grupo']) ? trim($_GET['grupo']) : '';

    try {
        $query = "
            SELECT
                Id_Anuncio AS id,
                Autor AS autor,
                Fecha AS fecha,
                Mensaje AS mensaje,
                Materia AS materia,
                Grupo AS grupo
            FROM anuncios
            WHERE 1=1
        ";
        $params = [];

        if (!empty($materia)) {
            $query .= " AND (Materia = :materia OR Materia = '')";
            $params[':materia'] = $materia;
        }
        if (!empty($grupo)) {
            $query .= " AND (Grupo = :grupo OR Grupo = '')";
            $params[':grupo'] = $grupo;
        }

        $query .= " ORDER BY Fecha DESC, Id_Anuncio DESC LIMIT 50";

        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $anuncios = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'data' => $anuncios
        ]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Error al obtener anuncios: ' . $e->getMessage(),
            'data' => []
        ]);
    }
} elseif ($method === 'POST') {
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true);

    $autor   = isset($data['autor']) ? trim($data['autor']) : 'Profesor';
    $mensaje = isset($data['mensaje']) ? trim($data['mensaje']) : '';
    $materia = isset($data['materia']) ? trim($data['materia']) : '';
    $grupo   = isset($data['grupo']) ? trim($data['grupo']) : '';
    $fecha   = date('Y-m-d H:i:s');

    if (empty($mensaje)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'El mensaje del anuncio no puede estar vacío'
        ]);
        exit();
    }

    try {
        $stmt = $pdo->prepare("
            INSERT INTO anuncios (Autor, Fecha, Mensaje, Materia, Grupo)
            VALUES (:autor, :fecha, :mensaje, :materia, :grupo)
        ");
        $stmt->execute([
            ':autor'   => $autor,
            ':fecha'   => $fecha,
            ':mensaje' => $mensaje,
            ':materia' => $materia,
            ':grupo'   => $grupo
        ]);

        $newId = $pdo->lastInsertId();

        http_response_code(201);
        echo json_encode([
            'success' => true,
            'message' => 'Anuncio publicado correctamente',
            'data' => [
                'id' => $newId,
                'autor' => $autor,
                'fecha' => $fecha,
                'mensaje' => $mensaje,
                'materia' => $materia,
                'grupo' => $grupo
            ]
        ]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Error al publicar anuncio: ' . $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido'
    ]);
}
