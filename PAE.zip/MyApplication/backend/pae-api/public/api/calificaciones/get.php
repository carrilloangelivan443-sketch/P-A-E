<?php
/**
 * Endpoint para obtener Calificaciones por Alumno (Boleta) desde MariaDB
 * Ruta: GET /api/calificaciones/get.php?boleta=2024640101
 */

header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . '/../../config/database.php';

$boleta = isset($_GET['boleta']) ? trim($_GET['boleta']) : '';

try {
    // Consultar calificaciones del alumno en MariaDB
    $query = "
        SELECT
            m.Nombre_Materia AS materia,
            COALESCE(c.Unidad_1, '-') AS u1,
            COALESCE(c.Unidad_2, '-') AS u2,
            COALESCE(c.Unidad_3, '-') AS u3,
            COALESCE(c.Calificacion_Final, '-') AS final
        FROM calificaciones c
        JOIN materias m ON c.Id_Materia = m.Id_Materia
        WHERE c.Boleta = :boleta
    ";

    $stmt = $pdo->prepare($query);
    $stmt->execute([':boleta' => $boleta]);
    $calificaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Si la tabla de calificaciones no tiene registros para este alumno, consultar inscripción y materias
    if (empty($calificaciones)) {
        $stmtInscritas = $pdo->prepare("
            SELECT m.Nombre_Materia AS materia
            FROM inscripciones i
            JOIN cursos cu ON i.Id_Curso = cu.Id_Curso
            JOIN materias m ON cu.Id_Materia = m.Id_Materia
            WHERE i.Boleta = :boleta
        ");
        $stmtInscritas->execute([':boleta' => $boleta]);
        $materiasInscritas = $stmtInscritas->fetchAll(PDO::FETCH_ASSOC);

        foreach ($materiasInscritas as $row) {
            $calificaciones[] = [
                'materia' => $row['materia'],
                'u1' => '-',
                'u2' => '-',
                'u3' => '-',
                'final' => '-'
            ];
        }
    }

    echo json_encode([
        'success' => true,
        'data' => $calificaciones
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error al consultar calificaciones: ' . $e->getMessage(),
        'data' => []
    ]);
}
