<?php
/**
 * Endpoint para obtener Materias por Grupo desde MariaDB
 * Ruta: GET /api/materias/get.php?grupo=5IV11
 */

header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . '/../../config/database.php';

$grupo = isset($_GET['grupo']) ? trim($_GET['grupo']) : '';

try {
    // Consultar materias asociadas al grupo en MariaDB (cursos / materias / profesores / grupos)
    $query = "
        SELECT
            m.Id_Materia AS id,
            m.Nombre_Materia AS nombre,
            COALESCE(p.Nombre_Completo, 'Profesor Asignado') AS profesor,
            COALESCE(c.Aula, 'Aula 101') AS aula,
            COALESCE(c.Horario, 'Lunes a Viernes 07:00 - 09:00') AS horario
        FROM cursos c
        JOIN materias m ON c.Id_Materia = m.Id_Materia
        JOIN grupos g ON c.Id_Grupo = g.Id_Grupo
        LEFT JOIN profesores p ON c.Num_Empleado = p.Num_Empleado
        WHERE g.Nombre_Grupo = :grupo OR g.Id_Grupo = :grupo
    ";

    $stmt = $pdo->prepare($query);
    $stmt->execute([':grupo' => $grupo]);
    $materias = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Si no hay cursos en la consulta anterior, devolver un listado genérico de materias para el grupo
    if (empty($materias)) {
        $stmtFallback = $pdo->prepare("SELECT Id_Materia AS id, Nombre_Materia AS nombre FROM materias LIMIT 10");
        $stmtFallback->execute();
        $fallbackRows = $stmtFallback->fetchAll(PDO::FETCH_ASSOC);
        foreach ($fallbackRows as $row) {
            $materias[] = [
                'id' => $row['id'],
                'nombre' => $row['nombre'],
                'profesor' => 'Profesor Titular',
                'aula' => 'Aula 101',
                'horario' => 'Matutino'
            ];
        }
    }

    echo json_encode([
        'success' => true,
        'data' => $materias
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error al consultar materias: ' . $e->getMessage(),
        'data' => []
    ]);
}
