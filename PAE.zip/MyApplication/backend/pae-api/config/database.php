<?php
/**
 * Configuración de conexión a MariaDB / MySQL mediante PDO.
 * Ubicación en XAMPP: /opt/lampp/htdocs/pae-api/config/database.php
 */

$host    = '127.0.0.1';
$db      = 'pae_demo';
$user    = 'root';
$pass    = ''; // Modificar si la contraseña de MariaDB en XAMPP está configurada
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // Manejar error de conexión sin exponer detalles sensibles
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error de conexión a la base de datos'
    ]);
    exit();
}
