package com.IPN.PAE.api

import com.IPN.PAE.api.models.*
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

/**
 * Interfaz de Retrofit para llamadas de autenticación y servicios académicos.
 */
interface AuthApi {

    @POST("api/auth/login.php")
    suspend fun login(
        @Body request: LoginRequest
    ): Response<LoginResponse>

    @GET("api/materias/get.php")
    suspend fun getMaterias(
        @Query("grupo") grupo: String
    ): Response<MateriaApiResponse>

    @GET("api/calificaciones/get.php")
    suspend fun getCalificaciones(
        @Query("boleta") boleta: String
    ): Response<CalificacionApiResponse>

    // Los anuncios se manejan por id_curso en Anuncios.kt.
}
