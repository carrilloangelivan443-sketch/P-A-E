package com.IPN.PAE.api

import com.IPN.PAE.api.models.CredencialesAgora
import com.IPN.PAE.api.models.PaeAsistenciaAlumno
import com.IPN.PAE.api.models.PaeFinalizarVideollamadaResponse
import com.IPN.PAE.api.models.PaeSesionVideollamada
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Videollamadas de clase (Agora). El canal, el token y el uid SIEMPRE vienen del servidor.
 * Todas las funciones corren en IO y regresan Result con un mensaje legible en caso de error.
 */
object Videollamadas {

    private val api get() = RetrofitClient.paeApi

    /** Para avisos que deben llegar al servidor aunque la pantalla ya se haya cerrado (salir). */
    private val scopeFondo = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Sesión actual del curso, o null si no hay ninguna. */
    suspend fun consultar(idCurso: Int): Result<PaeSesionVideollamada?> = llamarApi {
        val r = api.videollamada(idCurso)
        if (r.isSuccessful) Result.success(r.body()?.sesion) else fallaApi(r)
    }

    /** Profesor: inicia la clase (o devuelve la que ya estaba en vivo) con las credenciales para entrar. */
    suspend fun iniciar(idCurso: Int): Result<ClaseIniciada> = llamarApi {
        val r = api.iniciarVideollamada(idCurso)
        val body = r.body()
        val sesion = body?.sesion
        val credenciales = body?.credenciales(body.canal ?: sesion?.canal)
        when {
            !r.isSuccessful -> fallaApi(r)
            sesion == null -> Result.failure(Exception("El servidor no envió la sesión de la clase"))
            credenciales == null -> Result.failure(Exception("El servidor no envió el canal o el token de la clase"))
            else -> Result.success(ClaseIniciada(sesion, credenciales))
        }
    }

    /** Profesor o alumno: token nuevo para la clase en vivo (cuando el actual está por vencer). */
    suspend fun renovarToken(idCurso: Int): Result<CredencialesAgora> = llamarApi {
        val r = api.tokenVideollamada(idCurso)
        val body = r.body()
        val credenciales = body?.credenciales(body.canal)
        when {
            r.code() == 409 -> Result.failure(ClaseNoIniciada())
            !r.isSuccessful -> fallaApi(r)
            credenciales == null -> Result.failure(Exception("El servidor no envió el token de la clase"))
            else -> Result.success(credenciales)
        }
    }

    /** Profesor: finaliza la clase en vivo. */
    suspend fun finalizar(idCurso: Int): Result<PaeFinalizarVideollamadaResponse> = llamarApi {
        val r = api.finalizarVideollamada(idCurso)
        when {
            r.code() == 409 -> Result.failure(Exception("No hay una clase en vivo para finalizar"))
            r.isSuccessful -> Result.success(r.body() ?: PaeFinalizarVideollamadaResponse(null, null))
            else -> fallaApi(r)
        }
    }

    /** Profesor: lista de asistencia de una sesión. */
    suspend fun asistencia(idSesion: Int): Result<List<PaeAsistenciaAlumno>> = llamarApi {
        val r = api.asistenciaSesion(idSesion)
        if (r.isSuccessful) Result.success(r.body()?.asistencia.orEmpty()) else fallaApi(r)
    }

    /** Alumno: se une y registra asistencia. Error con [ClaseNoIniciada] si el profesor no ha iniciado. */
    suspend fun unirse(idCurso: Int): Result<Union> = llamarApi {
        val r = api.unirseVideollamada(idCurso)
        val body = r.body()
        val credenciales = body?.credenciales(body.canal)
        when {
            r.code() == 409 -> Result.failure(ClaseNoIniciada())
            !r.isSuccessful -> fallaApi(r)
            credenciales == null -> Result.failure(Exception("El servidor no envió el canal o el token de la clase"))
            else -> Result.success(Union(body.asistencia, credenciales))
        }
    }

    /** Alumno: registra la hora de salida. No bloquea la pantalla y sobrevive a su cierre. */
    fun salir(idCurso: Int) {
        scopeFondo.launch {
            try { api.salirVideollamada(idCurso) } catch (_: Exception) { }
        }
    }

    class ClaseIniciada(val sesion: PaeSesionVideollamada, val credenciales: CredencialesAgora)

    /** [asistencia]: "PRESENTE" o "RETARDO". */
    class Union(val asistencia: String?, val credenciales: CredencialesAgora)

    class ClaseNoIniciada : Exception("El profesor aún no inicia la clase")
}

/** "2026-11-12 10:05:33" → "10:05". Si no reconoce el formato, regresa el texto tal cual. */
fun horaCorta(fecha: String?): String? {
    if (fecha.isNullOrBlank()) return null
    return Regex("\\d{1,2}:\\d{2}").find(fecha)?.value ?: fecha
}
