package com.IPN.PAE

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.IPN.PAE.api.Tareas
import com.IPN.PAE.api.fechaCorta
import com.IPN.PAE.api.models.PaeTarea
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Tarea sin entregar, con la materia a la que pertenece. */
private data class Pendiente(val materia: Materia, val tarea: PaeTarea, val limiteMs: Long?)

private fun milisDe(fecha: String?): Long? {
    if (fecha.isNullOrBlank()) return null
    for (formato in listOf("yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM-dd")) {
        try {
            return SimpleDateFormat(formato, Locale.US).apply { isLenient = false }.parse(fecha)?.time
        } catch (_: Exception) { }
    }
    return null
}

/** "Vencida", "Vence hoy", "Vence mañana", "Vence en 3 días" o null si no hay fecha. */
private fun cuandoVence(limiteMs: Long?, ahora: Long): Pair<String, Color>? {
    if (limiteMs == null) return null
    val restante = limiteMs - ahora
    if (restante < 0) return "Vencida" to Color(0xFFFF8A8A)
    val horas = TimeUnit.MILLISECONDS.toHours(restante)
    return when {
        horas < 24 -> "Vence hoy" to Color(0xFFFFC266)
        horas < 48 -> "Vence mañana" to Color(0xFFFFC266)
        else -> "Vence en ${horas / 24} días" to Color(0xFF9CD3A4)
    }
}

/**
 * Inicio del alumno: tareas sin entregar de todas sus materias, de la más urgente a la menos.
 * Al tocar una, se abre la materia directamente en la pestaña de Tareas.
 */
@Composable
fun TarjetaTareasPendientes(materias: List<Materia>) {
    val context = LocalContext.current
    var pendientes by remember { mutableStateOf<List<Pendiente>?>(null) }
    var verTodas by remember { mutableStateOf(false) }
    val textColor = MaterialTheme.colorScheme.onSurface

    LaunchedEffect(materias) {
        if (materias.isEmpty()) { pendientes = emptyList(); return@LaunchedEffect }
        pendientes = coroutineScope {
            materias.mapNotNull { m -> m.id.toIntOrNull()?.let { id -> m to id } }
                .map { (m, id) -> async { m to Tareas.listar(id).getOrNull().orEmpty() } }
                .awaitAll()
                .flatMap { (m, tareas) ->
                    tareas.filter { it.estadoEntrega == null }
                        .map { Pendiente(m, it, milisDe(it.fechaLimite)) }
                }
                // Primero las que tienen fecha (la más próxima arriba), al final las que no tienen.
                .sortedWith(compareBy(nullsLast()) { it.limiteMs })
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.45f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)),
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Assignment, null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Tareas pendientes", style = MaterialTheme.typography.titleMedium, color = textColor, fontWeight = FontWeight.Bold)
            }
            val lista = pendientes
            when {
                lista == null -> CircularProgressIndicator(
                    modifier = Modifier.size(24.dp).align(Alignment.CenterHorizontally),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.tertiary
                )
                lista.isEmpty() -> Text(
                    "No tienes tareas pendientes. ¡Bien hecho!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = textColor.copy(alpha = 0.8f)
                )
                else -> {
                    val ahora = System.currentTimeMillis()
                    val visibles = if (verTodas) lista else lista.take(4)
                    visibles.forEach { p ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    context.startActivity(Intent(context, MateriaDetalleActivity::class.java).apply {
                                        putExtra("NOMBRE_MATERIA", p.materia.nombre)
                                        putExtra("ID_CURSO", p.materia.id.toIntOrNull() ?: -1)
                                        putExtra("NOMBRE_PROFESOR", p.materia.profesor)
                                        putExtra(MateriaDetalleActivity.EXTRA_PESTANA, MateriaDetalleActivity.PESTANA_TAREAS)
                                    })
                                }
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                p.tarea.titulo ?: "Tarea",
                                color = textColor,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    p.materia.nombre + (fechaCorta(p.tarea.fechaLimite)?.let { " · $it" } ?: ""),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = textColor.copy(alpha = 0.7f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                cuandoVence(p.limiteMs, ahora)?.let { (texto, color) ->
                                    Spacer(Modifier.width(8.dp))
                                    EtiquetaEstado(texto, color, sobreFondoClaro = modoClaro())
                                }
                            }
                        }
                    }
                    if (lista.size > 4) {
                        TextButton(onClick = { verTodas = !verTodas }) {
                            Text(
                                if (verTodas) "Ver menos" else "Ver las ${lista.size}",
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }
                    }
                }
            }
        }
    }
}
