package com.IPN.PAE.api

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import com.IPN.PAE.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Actualizaciones de la app desde el servidor PAE (sin Play Store).
 *
 * 1. [revisar] consulta GET /app/version una vez por arranque y compara con BuildConfig.VERSION_CODE.
 *    Si no hay internet o el servidor falla, no pasa nada: la app sigue normal, sin mensajes.
 * 2. [descargar] baja el APK a cache/actualizaciones/ con progreso y verifica su SHA-256.
 * 3. La pantalla (AvisoActualizacion.kt) lo instala con [intentInstalar] (FileProvider, content://).
 *
 * El estado vive aquí (no en la pantalla) para que una descarga siga si se gira el teléfono
 * o se cambia de Activity.
 */
object Actualizaciones {

    data class VersionNueva(
        val codigo: Int,
        val nombre: String,
        val url: String,
        val notas: String,
        val obligatoria: Boolean,
        val sha256: String?,
        val tamano: Long?
    )

    sealed interface Estado {
        /** No hay versión nueva, todavía no se sabe, o el usuario tocó "Después". */
        data object SinAviso : Estado
        data class Disponible(val version: VersionNueva) : Estado
        /** [progreso] de 0 a 1, o null si el servidor no dijo el tamaño. */
        data class Descargando(val version: VersionNueva, val progreso: Float?) : Estado
        /** [instaladorAbierto]: ya se abrió el instalador una vez (si se cancela, se ofrece otra vez). */
        data class Descargada(val version: VersionNueva, val archivo: File, val instaladorAbierto: Boolean = false) : Estado
        data class ErrorDescarga(val version: VersionNueva, val mensaje: String) : Estado
    }

    private const val CARPETA = "actualizaciones"
    private const val TIPO_APK = "application/vnd.android.package-archive"

    private val _estado = MutableStateFlow<Estado>(Estado.SinAviso)
    val estado: StateFlow<Estado> = _estado.asStateFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val yaRevisada = AtomicBoolean(false)

    /** Cliente aparte, sin token (el APK es público) y con tiempos holgados para un archivo grande. */
    private val clienteDescarga by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    /** Solo se aceptan APK por HTTPS y del mismo servidor que la API. */
    private val hostApi: String? = BuildConfig.BASE_URL.toHttpUrlOrNull()?.host

    /** Consulta el servidor una sola vez por arranque de la app. Nunca muestra errores. */
    fun revisar(context: Context) {
        if (!yaRevisada.compareAndSet(false, true)) return
        val appContext = context.applicationContext
        scope.launch {
            val nueva = try {
                consultar()
            } catch (_: Exception) {
                null
            }
            if (nueva != null) {
                _estado.value = Estado.Disponible(nueva)
            } else {
                // Ya estamos en la última versión (o no se pudo saber): se borran APK viejos.
                borrarDescargas(appContext, excepto = null)
            }
        }
    }

    private suspend fun consultar(): VersionNueva? {
        val r = RetrofitClient.paeApi.versionApp()
        val v = r.body()
        if (!r.isSuccessful || v == null) return null
        val codigo = v.versionCode ?: return null
        if (codigo <= BuildConfig.VERSION_CODE) return null
        val url = v.apkUrl?.toHttpUrlOrNull() ?: return null
        if (!url.isHttps || !url.host.equals(hostApi, ignoreCase = true)) return null
        return VersionNueva(
            codigo = codigo,
            nombre = v.versionName?.takeIf { it.isNotBlank() } ?: codigo.toString(),
            url = url.toString(),
            notas = v.notas?.trim().orEmpty(),
            obligatoria = v.obligatoria == true,
            sha256 = v.sha256?.trim()?.lowercase()?.takeIf { it.matches(Regex("[0-9a-f]{64}")) },
            tamano = v.tamano?.takeIf { it > 0 }
        )
    }

    /** "Después": oculta el aviso hasta el próximo arranque. Las versiones obligatorias no se pueden posponer. */
    fun posponer() {
        val v = versionActual() ?: return
        if (!v.obligatoria && _estado.value !is Estado.Descargando) _estado.value = Estado.SinAviso
    }

    fun versionActual(): VersionNueva? = when (val e = _estado.value) {
        Estado.SinAviso -> null
        is Estado.Disponible -> e.version
        is Estado.Descargando -> e.version
        is Estado.Descargada -> e.version
        is Estado.ErrorDescarga -> e.version
    }

    /** Descarga el APK a la caché de la app. Al terminar, el estado pasa a [Estado.Descargada]. */
    fun descargar(context: Context) {
        val actual = _estado.value
        if (actual is Estado.Descargando) return
        val v = versionActual() ?: return
        val appContext = context.applicationContext
        _estado.value = Estado.Descargando(v, null)
        scope.launch {
            _estado.value = try {
                Estado.Descargada(v, bajarApk(appContext, v))
            } catch (e: Exception) {
                Estado.ErrorDescarga(v, e.message ?: "No se pudo descargar la actualización")
            }
        }
    }

    private fun bajarApk(context: Context, v: VersionNueva): File {
        val carpeta = File(context.cacheDir, CARPETA).apply { mkdirs() }
        val destino = File(carpeta, "pae-${v.codigo}.apk")
        borrarDescargas(context, excepto = destino)

        // Ya se había descargado completa (p. ej. se canceló el instalador y se volvió a abrir la app).
        if (destino.isFile && v.sha256 != null && sha256(destino) == v.sha256) return destino

        val parcial = File(carpeta, "pae-${v.codigo}.apk.part")
        val digest = MessageDigest.getInstance("SHA-256")
        try {
            clienteDescarga.newCall(Request.Builder().url(v.url).build()).execute().use { r ->
                if (!r.isSuccessful) throw Exception("El servidor no envió la actualización (${r.code})")
                val cuerpo = r.body ?: throw Exception("El servidor no envió la actualización")
                val total = cuerpo.contentLength().takeIf { it > 0 } ?: v.tamano
                var leidos = 0L
                var ultimoPorcentaje = -1
                cuerpo.byteStream().use { entrada ->
                    parcial.outputStream().use { salida ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val n = entrada.read(buffer)
                            if (n < 0) break
                            salida.write(buffer, 0, n)
                            digest.update(buffer, 0, n)
                            leidos += n
                            if (total != null) {
                                val porcentaje = (leidos * 100 / total).toInt().coerceIn(0, 100)
                                if (porcentaje != ultimoPorcentaje) {
                                    ultimoPorcentaje = porcentaje
                                    _estado.value = Estado.Descargando(v, porcentaje / 100f)
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: java.io.IOException) {
            parcial.delete()
            throw Exception("Se perdió la conexión durante la descarga. Inténtalo de nuevo.")
        } catch (e: Exception) {
            parcial.delete()
            throw e
        }

        val hash = digest.digest().joinToString("") { "%02x".format(it) }
        if (v.sha256 != null && hash != v.sha256) {
            parcial.delete()
            throw Exception("La descarga llegó dañada. Inténtalo de nuevo.")
        }
        destino.delete()
        if (!parcial.renameTo(destino)) throw Exception("No se pudo guardar la actualización")
        return destino
    }

    private fun sha256(archivo: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        archivo.inputStream().use { entrada ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = entrada.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun borrarDescargas(context: Context, excepto: File?) {
        File(context.cacheDir, CARPETA).listFiles()?.forEach { if (it != excepto) it.delete() }
    }

    /**
     * Android 8+ exige que el usuario permita "instalar apps desconocidas" a PAE.
     * En Android 7 (API 24-25) el ajuste es global y el propio instalador lo pide si hace falta.
     */
    fun puedeInstalar(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O || context.packageManager.canRequestPackageInstalls()

    /** Pantalla de Ajustes donde se activa "Permitir de esta fuente" para PAE (Android 8+). */
    fun intentPermiso(context: Context): Intent =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
        } else {
            Intent(Settings.ACTION_SECURITY_SETTINGS)
        }

    /** Abre el instalador de Android con el APK descargado. Regresa false si no se pudo abrir. */
    fun abrirInstalador(context: Context, archivo: File): Boolean {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.archivos", archivo)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, TIPO_APK)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            val e = _estado.value
            if (e is Estado.Descargada && e.archivo == archivo) _estado.value = e.copy(instaladorAbierto = true)
            true
        } catch (_: ActivityNotFoundException) {
            false
        } catch (_: SecurityException) {
            false
        }
    }
}
