package com.IPN.PAE

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.IPN.PAE.api.Kardex
import com.IPN.PAE.api.models.PaeKardexMateria
import com.IPN.PAE.api.models.PaeKardexResumen
import com.IPN.PAE.api.numeroCorto
import com.IPN.PAE.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class KardexActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                KardexScreen()
            }
        }
    }
}

private val COLOR_ACENTO = Color(0xFFFFB4A2)
private val COLOR_TEXTO = Color(0xFFE0E0E0)
private val COLOR_SECUNDARIO = Color(0xFFA0A0A0)

/** Color de la situación de una materia ("APROBADA", "REPROBADA", "EN CURSO", ...). */
private fun colorSituacion(situacion: String?): Color {
    val s = situacion?.uppercase().orEmpty()
    return when {
        s.startsWith("APROB") -> Color(0xFF81C784)
        s.startsWith("REPROB") || s.startsWith("NO ") -> Color(0xFFFF8A8A)
        s.contains("CURSO") -> COLOR_ACENTO
        else -> COLOR_SECUNDARIO
    }
}

/** "EN CURSO" → "En curso". */
private fun textoSituacion(situacion: String?): String =
    situacion?.lowercase()?.replaceFirstChar { it.uppercase() } ?: "Sin registro"

@Composable
fun KardexScreen() {
    val scope = rememberCoroutineScope()
    var datos by remember { mutableStateOf<Kardex.Datos?>(null) }
    var cargando by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    val cargar: () -> Unit = {
        cargando = true
        error = null
        scope.launch {
            Kardex.consultar()
                .onSuccess { datos = it }
                .onFailure { error = it.message }
            cargando = false
        }
    }
    LaunchedEffect(Unit) { cargar() }

    MainDrawerLayout(currentScreenTitle = "Kárdex Académico") { openDrawer ->
        Box(modifier = Modifier.fillMaxSize()) {
            FondoLavaBackground(modifier = Modifier.fillMaxSize())

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .verticalScroll(rememberScrollState()),
            ) {
                TopHeader(title = "Kárdex Académico", onOpenDrawer = openDrawer)

                Column(
                    modifier = Modifier.padding(horizontal = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    val actual = datos
                    when {
                        cargando && actual == null -> Box(
                            Modifier.fillMaxWidth().padding(top = 48.dp),
                            contentAlignment = Alignment.Center
                        ) { CircularProgressIndicator(color = COLOR_ACENTO) }

                        actual == null -> Column(
                            Modifier.fillMaxWidth().padding(top = 48.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                error ?: "No se pudo cargar el kárdex",
                                color = Color(0xFFFF8A8A),
                                textAlign = TextAlign.Center
                            )
                            TextButton(onClick = cargar) { Text("Reintentar", color = Color.White) }
                        }

                        else -> {
                            TarjetaResumenKardex(
                                resumen = actual.kardex.resumen,
                                estatus = actual.estatus,
                                cargando = cargando,
                                onActualizar = cargar
                            )
                            error?.let { Text(it, color = Color(0xFFFF8A8A), fontSize = 13.sp) }

                            val materias = actual.kardex.materias.orEmpty()
                            if (materias.isEmpty()) {
                                Text("Aún no hay materias en tu kárdex.", color = COLOR_TEXTO)
                            }
                            // Se agrupan por semestre y periodo, en el orden en que llegan del servidor.
                            materias
                                .groupBy { it.semestre to it.periodo }
                                .forEach { (clave, lista) -> TarjetaSemestreKardex(clave.first, clave.second, lista) }
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun TarjetaResumenKardex(
    resumen: PaeKardexResumen?,
    estatus: String?,
    cargando: Boolean,
    onActualizar: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
        border = BorderStroke(1.dp, Color(0x33FFFFFF)),
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Kárdex Académico General",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onActualizar, enabled = !cargando, modifier = Modifier.size(32.dp)) {
                    if (cargando) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                    } else {
                        Icon(Icons.Default.Refresh, contentDescription = "Actualizar", tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Promedio General Acumulado: ${resumen?.promedio?.let { numeroCorto(it) } ?: "-"}",
                color = COLOR_ACENTO,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyLarge
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Créditos aprobados: ${numeroCorto(resumen?.creditosAprobados)} de ${numeroCorto(resumen?.creditosCursados)} cursados",
                color = COLOR_TEXTO,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "Materias calificadas: ${resumen?.materiasCalificadas ?: 0}",
                color = COLOR_TEXTO,
                style = MaterialTheme.typography.bodyMedium
            )
            if (!estatus.isNullOrBlank()) {
                Text(text = "Estado: Alumno $estatus", color = COLOR_TEXTO, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun TarjetaSemestreKardex(semestre: String?, periodo: String?, materias: List<PaeKardexMateria>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
        border = BorderStroke(1.dp, Color(0x33FFFFFF)),
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                listOfNotNull(
                    semestre?.let { "$it semestre" },
                    periodo?.let { "Periodo $it" }
                ).joinToString(" · ").ifBlank { "Materias" },
                color = Color.White,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleSmall
            )
            Spacer(modifier = Modifier.height(4.dp))
            materias.forEachIndexed { i, m ->
                if (i > 0) HorizontalDivider(color = Color(0x22FFFFFF))
                FilaMateriaKardex(m)
            }
        }
    }
}

@Composable
private fun FilaMateriaKardex(m: PaeKardexMateria) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                m.materia ?: "Materia",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                listOfNotNull(
                    m.codigo,
                    m.creditos?.let { "${numeroCorto(it)} créditos" },
                    m.extraordinario?.let { "Extraordinario: ${numeroCorto(it)}" }
                ).joinToString(" · "),
                color = COLOR_SECUNDARIO,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            EtiquetaEstado(textoSituacion(m.situacion), colorSituacion(m.situacion))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            numeroCorto(m.calificacionFinal),
            color = if (m.calificacionFinal != null) Color.White else COLOR_SECUNDARIO,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
