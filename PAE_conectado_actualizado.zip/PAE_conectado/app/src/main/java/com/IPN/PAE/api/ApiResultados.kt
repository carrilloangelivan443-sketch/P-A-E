package com.IPN.PAE.api

import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response

/**
 * Utilidades compartidas por los módulos de la API (Videollamadas, Tareas, ...).
 * Las llamadas corren en IO y regresan Result con un mensaje legible en caso de error.
 */

/** Ejecuta [bloque] en IO; si no hay conexión regresa un error legible. */
internal suspend fun <T> llamarApi(bloque: suspend () -> Result<T>): Result<T> = withContext(Dispatchers.IO) {
    try {
        bloque()
    } catch (e: Exception) {
        Result.failure(Exception("No se pudo conectar con el servidor"))
    }
}

/** Convierte una respuesta fallida en Result.failure con el mensaje de {"error": "..."}. */
internal fun <T> fallaApi(r: Response<*>): Result<T> = Result.failure(Exception(mensajeDeError(r)))

/** Mensaje de {"error": "..."} (o "mensaje"/"message") de una respuesta fallida. */
internal fun mensajeDeError(r: Response<*>): String {
    val texto = try { r.errorBody()?.string() } catch (_: Exception) { null }
    val mensaje = try {
        val obj = JsonParser.parseString(texto).asJsonObject
        (obj.get("error") ?: obj.get("mensaje") ?: obj.get("message"))?.asString
    } catch (_: Exception) {
        null
    }
    return mensaje ?: "Error del servidor (${r.code()})"
}
