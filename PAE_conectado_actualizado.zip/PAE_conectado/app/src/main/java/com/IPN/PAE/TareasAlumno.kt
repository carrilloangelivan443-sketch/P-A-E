package com.IPN.PAE

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.IPN.PAE.api.Tareas
import com.IPN.PAE.api.fechaCorta
import com.IPN.PAE.api.models.PaeTarea
import com.IPN.PAE.api.numeroCorto
import com.IPN.PAE.ui.theme.AppThemeMode
import com.IPN.PAE.ui.theme.LocalAppThemeMode
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ==========================================
// Utilidades compartidas por alumno y profesor
// ==========================================

private val COLOR_PENDIENTE = Color(0xFFFFB4A2)
private val COLOR_VENCIDA = Color(0xFFFF8A8A)
private val COLOR_ENTREGADA = Color(0xFF64B5F6)
private val COLOR_REVISADA = Color(0xFF81C784)

/** true si la fecha límite ("AAAA-MM-DD HH:MM[:SS]") ya pasó. */
fun tareaVencida(fechaLimite: String?): Boolean {
    if (fechaLimite.isNullOrBlank()) return false
    val limite = listOf("yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm").firstNotNullOfOrNull { formato ->
        try { SimpleDateFormat(formato, Locale.US).apply { isLenient = false }.parse(fechaLimite) } catch (_: Exception) { null }
    } ?: return false
    return limite.before(Date())
}

/** Etiqueta y color del estado de la entrega del alumno. */
fun estadoTareaAlumno(t: PaeTarea): Pair<String, Color> = when {
    t.revisada -> "Revisada" to COLOR_REVISADA
    t.entregadaPorAlumno -> "Entregada" to COLOR_ENTREGADA
    tareaVencida(t.fechaLimite) -> "Vencida" to COLOR_VENCIDA
    else -> "Pendiente" to COLOR_PENDIENTE
}

/** Color del estado de una entrega vista por el profesor ("ENTREGADA" / "REVISADA"). */
fun colorEstadoEntrega(estado: String?): Color =
    if (estado.equals("REVISADA", ignoreCase = true)) COLOR_REVISADA else COLOR_ENTREGADA

@Composable
fun EtiquetaEstado(texto: String, color: Color, sobreFondoClaro: Boolean = false) {
    // Los tonos pastel no se leen sobre fondo claro: ahí se oscurecen.
    val tono = if (sobreFondoClaro) lerp(color, Color.Black, 0.5f) else color
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(tono.copy(alpha = 0.15f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(texto, color = tono, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun modoClaro(): Boolean {
    val modo = LocalAppThemeMode.current
    val sistemaOscuro = isSystemInDarkTheme()
    return modo == AppThemeMode.LIGHT || (modo == AppThemeMode.SYSTEM && !sistemaOscuro)
}

// ==========================================
// PESTAÑA "TAREAS" DEL ALUMNO
// ==========================================

@Composable
fun PestañaTareas(idCurso: Int?) {
    val scope = rememberCoroutineScope()
    var tareas by remember { mutableStateOf<List<PaeTarea>>(emptyList()) }
    var cargando by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var idSeleccionada by remember { mutableStateOf<Int?>(null) }

    val cargar: () -> Unit = {
        if (idCurso == null) {
            cargando = false
            error = "No se pudo identificar la clase. Regresa e intenta de nuevo."
        } else {
            cargando = true
            error = null
            scope.launch {
                Tareas.listar(idCurso)
                    .onSuccess { tareas = it }
                    .onFailure { error = it.message }
                cargando = false
            }
        }
    }
    LaunchedEffect(idCurso) { cargar() }

    val seleccionada = tareas.firstOrNull { it.id == idSeleccionada }
    if (seleccionada != null && idCurso != null) {
        BackHandler { idSeleccionada = null }
        DetalleTareaAlumno(
            tarea = seleccionada,
            idCurso = idCurso,
            onBack = { idSeleccionada = null },
            onEntregada = cargar
        )
        return
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when {
            cargando && tareas.isEmpty() -> CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center),
                color = COLOR_PENDIENTE
            )
            error != null && tareas.isEmpty() -> Column(
                modifier = Modifier.align(Alignment.Center).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(error!!, color = COLOR_VENCIDA, textAlign = TextAlign.Center)
                TextButton(onClick = cargar) { Text("Reintentar", color = Color.White) }
            }
            tareas.isEmpty() -> Text(
                text = "No hay tareas en esta clase.",
                color = Color.Gray,
                modifier = Modifier.align(Alignment.Center)
            )
            else -> Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val pendientes = tareas.count { !it.entregadaPorAlumno }
                    Text(
                        if (pendientes == 0) "Todas entregadas" else "$pendientes por entregar",
                        color = Color(0xFFE0E0E0),
                        fontSize = 13.sp,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = cargar, enabled = !cargando, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Refresh, contentDescription = "Actualizar", tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }
                tareas.forEach { t -> CardTarea(t) { idSeleccionada = t.id } }
            }
        }
    }
}

@Composable
fun CardTarea(tarea: PaeTarea, onClick: () -> Unit) {
    val (estado, colorEstado) = estadoTareaAlumno(tarea)
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x22000000)),
        border = BorderStroke(1.dp, Color(0x22FFFFFF))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color(0x447D2242)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.AutoMirrored.Filled.Assignment, contentDescription = "Tarea", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = tarea.titulo ?: "Tarea",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = fechaCorta(tarea.fechaLimite)?.let { "Entrega: $it" } ?: "Sin fecha límite",
                    color = Color(0xFFA0A0A0),
                    fontSize = 12.sp
                )
                val puntos = if (tarea.revisada) {
                    "Calificación: ${numeroCorto(tarea.calificacion)} / ${numeroCorto(tarea.puntosMaximos)}"
                } else {
                    "${numeroCorto(tarea.puntosMaximos)} puntos"
                }
                Text(text = puntos, color = Color(0xFFA0A0A0), fontSize = 12.sp)
            }
            Spacer(modifier = Modifier.width(8.dp))
            EtiquetaEstado(estado, colorEstado)
        }
    }
}

@Composable
fun DetalleTareaAlumno(tarea: PaeTarea, idCurso: Int, onBack: () -> Unit, onEntregada: () -> Unit) {
    var mostrarEntrega by remember { mutableStateOf(false) }
    val (estado, colorEstado) = estadoTareaAlumno(tarea)
    val texto = Color(0xFFE0E0E0)
    val secundario = Color(0xFFA0A0A0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = COLOR_PENDIENTE)
            Spacer(Modifier.width(8.dp))
            Text("Todas las tareas", color = COLOR_PENDIENTE, fontWeight = FontWeight.Bold)
        }

        // --- La tarea ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
            border = BorderStroke(1.dp, Color(0x33FFFFFF))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    Text(
                        tarea.titulo ?: "Tarea",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    EtiquetaEstado(estado, colorEstado)
                }
                Text(
                    listOfNotNull(
                        fechaCorta(tarea.fechaLimite)?.let { "Entrega: $it" } ?: "Sin fecha límite",
                        "${numeroCorto(tarea.puntosMaximos)} puntos"
                    ).joinToString(" · "),
                    color = secundario,
                    fontSize = 13.sp
                )
                fechaCorta(tarea.publicada)?.let { Text("Publicada: $it", color = secundario, fontSize = 12.sp) }
                if (!tarea.descripcion.isNullOrBlank()) {
                    HorizontalDivider(color = Color(0x22FFFFFF))
                    Text(tarea.descripcion, color = texto, fontSize = 14.sp, lineHeight = 20.sp)
                }
                tarea.idArchivo?.let { id ->
                    ArchivoDeAnuncio(idArchivo = id, nombre = tarea.archivoNombre, textColor = texto)
                }
            }
        }

        // --- Mi entrega ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
            border = BorderStroke(1.dp, Color(0x33FFFFFF))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Tu entrega", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                if (!tarea.entregadaPorAlumno) {
                    Text(
                        if (tareaVencida(tarea.fechaLimite)) "No entregaste esta tarea y la fecha límite ya pasó."
                        else "Aún no has entregado esta tarea.",
                        color = texto,
                        fontSize = 14.sp
                    )
                } else {
                    fechaCorta(tarea.entregada)?.let { Text("Entregada: $it", color = secundario, fontSize = 13.sp) }
                    tarea.entregaIdArchivo?.let { id ->
                        ArchivoDeAnuncio(idArchivo = id, nombre = tarea.entregaArchivoNombre, textColor = texto)
                    }
                }
                if (tarea.revisada) {
                    HorizontalDivider(color = Color(0x22FFFFFF))
                    Text(
                        "Calificación: ${numeroCorto(tarea.calificacion)} / ${numeroCorto(tarea.puntosMaximos)}",
                        color = COLOR_REVISADA,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    if (!tarea.comentario.isNullOrBlank()) {
                        Text("Comentario del profesor:", color = secundario, fontSize = 12.sp)
                        Text(tarea.comentario, color = texto, fontSize = 14.sp)
                    }
                    Text("La tarea ya fue calificada; no se puede cambiar la entrega.", color = secundario, fontSize = 12.sp)
                } else {
                    Spacer(Modifier.height(4.dp))
                    Button(
                        onClick = { mostrarEntrega = true },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (modoClaro()) Color(0xFF1B2A3A) else Color(0xFF7D2242))
                    ) {
                        Text(
                            if (tarea.entregadaPorAlumno) "Volver a entregar" else "Entregar tarea",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (mostrarEntrega) {
        DialogoEntregaTarea(
            tarea = tarea,
            idCurso = idCurso,
            onCerrar = { mostrarEntrega = false },
            onEntregada = {
                mostrarEntrega = false
                onEntregada()
            }
        )
    }
}

@Composable
fun DialogoEntregaTarea(tarea: PaeTarea, idCurso: Int, onCerrar: () -> Unit, onEntregada: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var contenido by remember { mutableStateOf("") }
    var enlace by remember { mutableStateOf("") }
    var archivo by remember { mutableStateOf<ArchivoLocal?>(null) }
    var enviando by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val claro = modoClaro()
    val colorTexto = MaterialTheme.colorScheme.onSurface

    val selector = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val elegido = try { ArchivosAdjuntos.describir(context, uri) } catch (_: Exception) { null }
            if (elegido == null) {
                error = "No se pudo leer el archivo elegido"
            } else {
                error = ArchivosAdjuntos.validarTamano(elegido)
                if (error == null) archivo = elegido
            }
        }
    }

    val enviar: () -> Unit = enviar@{
        if (enviando) return@enviar
        val url = enlace.trim()
        val elegido = archivo
        when {
            contenido.isBlank() && url.isBlank() && elegido == null ->
                { error = "Escribe un texto, pega un enlace o adjunta un archivo"; return@enviar }
            url.isNotEmpty() && !url.startsWith("https://", ignoreCase = true) ->
                { error = "El enlace debe empezar con https://"; return@enviar }
        }
        enviando = true
        error = null
        scope.launch {
            val resultado = runCatching {
                val idArchivo = elegido?.let {
                    Tareas.subirArchivo(idCurso, Tareas.Categoria.ENTREGA, it.nombre, it.mime) {
                        ArchivosAdjuntos.leerBytes(context, it)
                    }.getOrThrow()
                }
                Tareas.entregar(tarea.id, contenido.trim(), url, idArchivo).getOrThrow()
            }
            enviando = false
            resultado
                .onSuccess {
                    Toast.makeText(context, "Tarea entregada", Toast.LENGTH_SHORT).show()
                    onEntregada()
                }
                .onFailure { error = it.message ?: "No se pudo entregar la tarea" }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!enviando) onCerrar() },
        containerColor = if (claro) MaterialTheme.colorScheme.surface else Color(0xFF2C2C2C),
        title = {
            Text(
                if (tarea.entregadaPorAlumno) "Volver a entregar" else "Entregar tarea",
                color = colorTexto
            )
        },
        text = {
            val campo = OutlinedTextFieldDefaults.colors(focusedTextColor = colorTexto, unfocusedTextColor = colorTexto)
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(tarea.titulo ?: "Tarea", color = colorTexto, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = contenido,
                    onValueChange = { contenido = it },
                    label = { Text("Texto de la entrega (opcional)") },
                    enabled = !enviando,
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth(),
                    colors = campo
                )
                OutlinedTextField(
                    value = enlace,
                    onValueChange = { enlace = it },
                    label = { Text("Enlace https (opcional)") },
                    leadingIcon = { Icon(Icons.Default.Link, contentDescription = null) },
                    enabled = !enviando,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth(),
                    colors = campo
                )
                val elegido = archivo
                if (elegido != null) {
                    FilaArchivoAdjunto(
                        nombre = elegido.nombre,
                        detalle = ArchivosAdjuntos.tamanoLegible(elegido.tamano),
                        textColor = colorTexto,
                        onQuitar = if (enviando) null else ({ archivo = null })
                    )
                } else {
                    OutlinedButton(
                        onClick = { selector.launch(arrayOf("*/*")) },
                        enabled = !enviando,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AttachFile, contentDescription = null, tint = colorTexto, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (tarea.entregaIdArchivo != null) "Reemplazar archivo" else "Adjuntar archivo",
                            color = colorTexto
                        )
                    }
                    if (tarea.entregaIdArchivo != null) {
                        Text(
                            "Se conservará el archivo que ya entregaste: ${tarea.entregaArchivoNombre ?: "archivo"}",
                            color = colorTexto.copy(alpha = 0.7f),
                            fontSize = 12.sp
                        )
                    }
                }
                Text(
                    "Máximo ${ArchivosAdjuntos.TAMANO_MAXIMO_MB} MB por archivo.",
                    color = colorTexto.copy(alpha = 0.6f),
                    fontSize = 11.sp
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            Button(
                onClick = enviar,
                enabled = !enviando,
                colors = ButtonDefaults.buttonColors(containerColor = if (claro) Color(0xFF1B2A3A) else Color(0xFF7D2242))
            ) {
                if (enviando) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                } else {
                    Text("Entregar", color = Color.White)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onCerrar, enabled = !enviando) { Text("Cancelar", color = colorTexto) }
        }
    )
}
