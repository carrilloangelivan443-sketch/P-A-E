package com.IPN.PAE.api

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.IPN.PAE.MainActivity
import com.IPN.PAE.BuildConfig
import com.IPN.PAE.data.SessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Cliente Retrofit centralizado para la API de PAE vía HTTPS.
 * Agrega automáticamente "Authorization: Bearer <token>" cuando hay sesión iniciada.
 */
object RetrofitClient {

    val BASE_URL: String = BuildConfig.BASE_URL

    @Volatile
    private var sessionManager: SessionManager? = null

    @Volatile
    private var appContext: Context? = null

    /** Se llama una sola vez al arrancar la app (ver PaeApplication). */
    fun init(context: Context) {
        if (sessionManager == null) {
            appContext = context.applicationContext
            sessionManager = SessionManager(context.applicationContext)
        }
    }

    /**
     * El token expiró (dura 24 h) o el servidor lo invalidó: se borra la sesión y se vuelve al login.
     * Solo actúa si el token rechazado sigue siendo el de la sesión actual, así que varias respuestas
     * 401 seguidas no abren el login varias veces.
     */
    private fun sesionExpirada(tokenRechazado: String) {
        val sm = sessionManager ?: return
        val ctx = appContext ?: return
        synchronized(this) {
            if (sm.getToken() != tokenRechazado) return
            sm.clearSession()
        }
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(ctx, "Tu sesión expiró. Inicia sesión de nuevo.", Toast.LENGTH_LONG).show()
            ctx.startActivity(Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            })
        }
    }

    private val scopeFondo = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /**
     * Cierra la sesión: borra la sesión local de inmediato (para que la siguiente pantalla ya no la
     * vea) y en segundo plano avisa al servidor para invalidar el token (best-effort).
     */
    fun cerrarSesion() {
        val sm = sessionManager ?: return
        val token = sm.getToken()
        sm.clearSession()
        if (token.isNullOrBlank()) return
        scopeFondo.launch {
            try { paeApi.logout("Bearer $token") } catch (_: Exception) { }
        }
    }

    /** Host de la API. El token solo se envía a este host, nunca a URLs externas (p. ej. descargarUrl). */
    private val apiHost: String? = BASE_URL.toHttpUrlOrNull()?.host

    private val authInterceptor = Interceptor { chain ->
        val original = chain.request()
        val token = sessionManager?.getToken()
        val mismoHost = original.url.host.equals(apiHost, ignoreCase = true)
        if (mismoHost && original.header("Authorization") == null && !token.isNullOrBlank()) {
            val respuesta = chain.proceed(original.newBuilder().header("Authorization", "Bearer $token").build())
            if (respuesta.code == 401) sesionExpirada(token)
            respuesta
        } else {
            chain.proceed(original)
        }
    }

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.NONE
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(authInterceptor)
        .addInterceptor(loggingInterceptor)
        .connectTimeout(15, TimeUnit.SECONDS)
        // Más holgado para subir/descargar archivos adjuntos.
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val paeApi: PaeApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(PaeApi::class.java)
    }

    /** Las pantallas usan esta interfaz; el adaptador la traduce a la API real. */
    val authApi: AuthApi by lazy { PaeApiAdapter(paeApi) }
}
