package com.IPN.PAE.api.models

import com.google.gson.annotations.SerializedName

// Modelos de la API del servidor PAE (https://pae.tail98eed5.ts.net/api/).
// Los campos son "nullable" para que la app no truene si el servidor omite alguno.

data class PaeLoginRequest(
    @SerializedName("usuario") val usuario: String,
    @SerializedName("contrasena") val contrasena: String
)

data class PaeUsuario(
    @SerializedName("id") val id: String?,
    @SerializedName("nombre") val nombre: String?
)

data class PaeLoginResponse(
    @SerializedName("token") val token: String?,
    @SerializedName("rol") val rol: String?,
    @SerializedName("expira_en_horas") val expiraEnHoras: Int?,
    @SerializedName("usuario") val usuario: PaeUsuario?
)

data class PaeYoDatos(
    @SerializedName("nombre") val nombre: String?,
    @SerializedName("grupo") val grupo: String?,
    @SerializedName("estatus") val estatus: String? = null   // alumno: "Regular", ...
)

data class PaeYoResponse(
    @SerializedName("rol") val rol: String?,
    @SerializedName("datos") val datos: PaeYoDatos?
)

data class PaeCurso(
    @SerializedName("id_curso") val idCurso: Int,
    @SerializedName("materia") val materia: String?,
    @SerializedName("grupo") val grupo: String?,
    @SerializedName("profesor") val profesor: String?,
    @SerializedName("horario") val horario: String?,
    @SerializedName("aula") val aula: String?,
    @SerializedName("parcial_1") val parcial1: Double?,
    @SerializedName("parcial_2") val parcial2: Double?,
    @SerializedName("parcial_3") val parcial3: Double?,
    @SerializedName("final") val calificacionFinal: Double?
)

data class PaeCursosResponse(
    @SerializedName("cursos") val cursos: List<PaeCurso>?
)

data class PaeAnuncio(
    @SerializedName("id") val id: Int,
    @SerializedName("titulo") val titulo: String?,
    @SerializedName("contenido") val contenido: String?,
    @SerializedName("fecha") val fecha: String?,
    @SerializedName("autor") val autor: String?,
    @SerializedName("id_archivo") val idArchivo: Int? = null,
    @SerializedName(value = "nombre_archivo", alternate = ["archivo_nombre", "nombre_original"]) val nombreArchivo: String? = null
)

data class PaeAnunciosResponse(
    @SerializedName("anuncios") val anuncios: List<PaeAnuncio>?
)

data class PaeAnuncioRequest(
    @SerializedName("titulo") val titulo: String,
    @SerializedName("contenido") val contenido: String,
    // Gson omite los null, así que un anuncio sin archivo no manda el campo.
    @SerializedName("id_archivo") val idArchivo: Int? = null
)

// ---------- Videollamadas ----------

data class PaeSesionVideollamada(
    @SerializedName("id") val id: Int,
    @SerializedName("canal") val canal: String?,
    @SerializedName("estado") val estado: String?,   // "EN_VIVO" o "PROGRAMADA"
    @SerializedName("inicio") val inicio: String?,
    @SerializedName("fin") val fin: String?
) {
    val enVivo: Boolean get() = estado.equals("EN_VIVO", ignoreCase = true)
}

data class PaeVideollamadaResponse(
    @SerializedName("sesion") val sesion: PaeSesionVideollamada?
)

/**
 * Datos para entrar al canal de Agora. El token se genera en el servidor para ese canal y ese uid:
 * hay que usar los tres tal cual en joinChannel, o Agora rechaza el token.
 */
data class CredencialesAgora(
    val canal: String,
    val appId: String,
    val token: String,
    val uid: Int,
    val expiraEnSegundos: Int?
)

/** Campos de Agora que vienen en iniciar, unirse y /token. */
interface ConCredencialesAgora {
    val appId: String?
    val token: String?
    val uid: Int?
    val expiraEnSegundos: Int?

    /** null si al servidor le faltó algún dato obligatorio. */
    fun credenciales(canal: String?): CredencialesAgora? {
        val c = canal?.trim()
        val t = token
        val u = uid
        if (c.isNullOrEmpty() || t.isNullOrBlank() || u == null) return null
        return CredencialesAgora(c, appId?.takeIf { it.isNotBlank() } ?: "", t, u, expiraEnSegundos)
    }
}

data class PaeIniciarVideollamadaResponse(
    @SerializedName("sesion") val sesion: PaeSesionVideollamada?,
    @SerializedName("mensaje") val mensaje: String?,
    @SerializedName("canal") val canal: String?,
    @SerializedName("app_id") override val appId: String?,
    @SerializedName("token") override val token: String?,
    @SerializedName("uid") override val uid: Int?,
    @SerializedName("expira_en_segundos") override val expiraEnSegundos: Int?
) : ConCredencialesAgora

data class PaeTokenVideollamadaResponse(
    @SerializedName("canal") val canal: String?,
    @SerializedName("app_id") override val appId: String?,
    @SerializedName("token") override val token: String?,
    @SerializedName("uid") override val uid: Int?,
    @SerializedName("expira_en_segundos") override val expiraEnSegundos: Int?
) : ConCredencialesAgora

data class PaeFinalizarVideollamadaResponse(
    @SerializedName("mensaje") val mensaje: String?,
    @SerializedName("id_sesion") val idSesion: Int?
)

data class PaeUnirseVideollamadaResponse(
    @SerializedName("canal") val canal: String?,
    @SerializedName("asistencia") val asistencia: String?,   // "PRESENTE" o "RETARDO"
    @SerializedName("app_id") override val appId: String?,
    @SerializedName("token") override val token: String?,
    @SerializedName("uid") override val uid: Int?,
    @SerializedName("expira_en_segundos") override val expiraEnSegundos: Int?
) : ConCredencialesAgora

data class PaeAsistenciaAlumno(
    @SerializedName("boleta") val boleta: String?,
    @SerializedName("alumno") val alumno: String?,
    @SerializedName("estado") val estado: String?,          // PRESENTE, RETARDO o AUSENTE
    @SerializedName("entrada") val entrada: String?,
    @SerializedName("salida") val salida: String?
)

data class PaeAsistenciaResponse(
    @SerializedName("asistencia") val asistencia: List<PaeAsistenciaAlumno>?
)

// ---------- Tareas ----------

/**
 * Tarea de un curso. Para el alumno trae también los campos de su entrega;
 * para el profesor trae [entregas] (cuántas hay) y los campos de entrega quedan en null.
 */
data class PaeTarea(
    @SerializedName("id") val id: Int,
    @SerializedName("titulo") val titulo: String?,
    @SerializedName("descripcion") val descripcion: String?,
    @SerializedName("publicada") val publicada: String?,
    @SerializedName("fecha_limite") val fechaLimite: String?,
    @SerializedName("puntos_maximos") val puntosMaximos: Double?,
    @SerializedName("id_archivo") val idArchivo: Int?,
    @SerializedName("archivo_nombre") val archivoNombre: String?,
    @SerializedName("archivo_tipo") val archivoTipo: String?,
    // Solo alumno
    @SerializedName("estado_entrega") val estadoEntrega: String?,   // null (pendiente), "ENTREGADA" o "REVISADA"
    @SerializedName("entregada") val entregada: String?,
    @SerializedName("calificacion") val calificacion: Double?,
    @SerializedName("comentario") val comentario: String?,
    @SerializedName("entrega_id_archivo") val entregaIdArchivo: Int?,
    @SerializedName("entrega_archivo_nombre") val entregaArchivoNombre: String?,
    // Solo profesor
    @SerializedName("entregas") val entregas: Int?
) {
    val revisada: Boolean get() = estadoEntrega.equals("REVISADA", ignoreCase = true)
    val entregadaPorAlumno: Boolean get() = !estadoEntrega.isNullOrBlank()
}

data class PaeTareasResponse(
    @SerializedName("tareas") val tareas: List<PaeTarea>?
)

data class PaeCrearTareaRequest(
    @SerializedName("titulo") val titulo: String,
    @SerializedName("descripcion") val descripcion: String? = null,
    @SerializedName("fecha_entrega") val fechaEntrega: String? = null,   // "AAAA-MM-DD HH:MM"
    @SerializedName("puntos_maximos") val puntosMaximos: Int? = null,
    @SerializedName("id_archivo") val idArchivo: Int? = null
)

data class PaeCrearTareaResponse(
    @SerializedName("id") val id: Int?,
    @SerializedName("mensaje") val mensaje: String?
)

data class PaeEntregaRequest(
    @SerializedName("contenido") val contenido: String? = null,
    @SerializedName("archivo_url") val archivoUrl: String? = null,
    // Si va en null el servidor conserva el archivo de la entrega anterior.
    @SerializedName("id_archivo") val idArchivo: Int? = null
)

data class PaeEntrega(
    @SerializedName("id") val id: Int,
    @SerializedName("boleta") val boleta: String?,
    @SerializedName("alumno") val alumno: String?,
    @SerializedName("contenido") val contenido: String?,
    @SerializedName("archivo_url") val archivoUrl: String?,
    @SerializedName("fecha") val fecha: String?,
    @SerializedName("estado") val estado: String?,
    @SerializedName("calificacion") val calificacion: Double?,
    @SerializedName("comentario") val comentario: String?,
    @SerializedName("id_archivo") val idArchivo: Int?,
    @SerializedName("archivo_nombre") val archivoNombre: String?,
    @SerializedName("archivo_tipo") val archivoTipo: String?
)

data class PaeEntregasResponse(
    @SerializedName("entregas") val entregas: List<PaeEntrega>?
)

data class PaeCalificarRequest(
    @SerializedName("calificacion") val calificacion: Double,
    @SerializedName("comentario") val comentario: String? = null
)

/** Respuesta de POST /archivos. */
data class PaeArchivoSubido(
    @SerializedName("id_archivo") val idArchivo: Int?,
    @SerializedName("nombre") val nombre: String?,
    @SerializedName("tipo") val tipo: String?,
    @SerializedName("tamano") val tamano: Long?
)

// ---------- Kárdex (solo alumno) ----------

data class PaeKardexResumen(
    @SerializedName("promedio") val promedio: Double?,
    @SerializedName("materias_calificadas") val materiasCalificadas: Int?,
    @SerializedName("creditos_cursados") val creditosCursados: Double?,
    @SerializedName("creditos_aprobados") val creditosAprobados: Double?
)

data class PaeKardexMateria(
    @SerializedName("periodo") val periodo: String?,
    @SerializedName("semestre") val semestre: String?,
    @SerializedName("codigo") val codigo: String?,
    @SerializedName("materia") val materia: String?,
    @SerializedName("creditos") val creditos: Double?,
    @SerializedName("final") val calificacionFinal: Double?,
    @SerializedName("extraordinario") val extraordinario: Double?,
    @SerializedName("situacion") val situacion: String?   // "EN CURSO", "APROBADA", ...
)

data class PaeKardexResponse(
    @SerializedName("resumen") val resumen: PaeKardexResumen?,
    @SerializedName("materias") val materias: List<PaeKardexMateria>?
)

/** GET /app/version (ruta pública): última versión publicada de la app. Ver Actualizaciones.kt. */
data class PaeVersionApp(
    @SerializedName("versionCode") val versionCode: Int?,
    @SerializedName("versionName") val versionName: String?,
    @SerializedName("apkUrl") val apkUrl: String?,
    @SerializedName("notas") val notas: String?,
    @SerializedName("obligatoria") val obligatoria: Boolean?,
    @SerializedName("sha256") val sha256: String? = null,
    @SerializedName("tamano") val tamano: Long? = null
)
