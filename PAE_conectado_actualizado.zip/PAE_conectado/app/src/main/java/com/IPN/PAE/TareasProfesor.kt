package com.IPN.PAE

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.IPN.PAE.api.Tareas
import com.IPN.PAE.api.fechaCorta
import com.IPN.PAE.api.models.PaeEntrega
import com.IPN.PAE.api.models.PaeTarea
import com.IPN.PAE.api.numeroCorto
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Locale

// ==========================================
// TAREAS DEL CURSO (portal de profesores)
// ==========================================

/** Tarjeta con la lista de tareas del curso y el botón para crear una nueva. */
@Composable
fun TarjetaTareasProfesor(
    idCurso: Int?,
    cardBg: Color,
    cardBorder: BorderStroke,
    institutionalColor: Color,
    onVerEntregas: (PaeTarea) -> Unit
) {
    val scope = rememberCoroutineScope()
    val textColor = MaterialTheme.colorScheme.onBackground
    var tareas by remember { mutableStateOf<List<PaeTarea>>(emptyList()) }
    var cargando by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var mostrarCrear by remember { mutableStateOf(false) }

    val cargar: () -> Unit = {
        if (idCurso == null) {
            cargando = false
            error = "No se pudo identificar la clase"
        } else {
            cargando = true
            error = null
            scope.launch {
                Tareas.listar(idCurso)
                    .onSuccess { tareas = it }
                    .onFailure { error = it.message }
                cargando = false
            }
        }
    }
    LaunchedEffect(idCurso) { cargar() }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = cardBorder
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.AutoMirrored.Filled.Assignment, contentDescription = null, tint = institutionalColor, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Tareas", color = textColor, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        when {
                            cargando -> "Consultando..."
                            tareas.isEmpty() -> "Sin tareas publicadas"
                            tareas.size == 1 -> "1 tarea"
                            else -> "${tareas.size} tareas"
                        },
                        color = MaterialTheme.colorScheme.secondary,
                        fontSize = 12.sp
                    )
                }
                IconButton(onClick = cargar, enabled = !cargando, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Refresh, contentDescription = "Actualizar", tint = textColor, modifier = Modifier.size(20.dp))
                }
            }

            error?.let {
                Spacer(modifier = Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
            }

            tareas.forEachIndexed { i, t ->
                if (i > 0) HorizontalDivider(color = textColor.copy(alpha = 0.12f))
                FilaTareaProfesor(t, textColor, institutionalColor) { onVerEntregas(t) }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = { mostrarCrear = true },
                enabled = idCurso != null,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = institutionalColor)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                Spacer(Modifier.width(8.dp))
                Text("Nueva tarea", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (mostrarCrear && idCurso != null) {
        DialogoCrearTarea(
            idCurso = idCurso,
            institutionalColor = institutionalColor,
            onCerrar = { mostrarCrear = false },
            onCreada = {
                mostrarCrear = false
                cargar()
            }
        )
    }
}

@Composable
private fun FilaTareaProfesor(tarea: PaeTarea, textColor: Color, institutionalColor: Color, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                tarea.titulo ?: "Tarea",
                color = textColor,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                listOf(
                    fechaCorta(tarea.fechaLimite)?.let { "Entrega: $it" } ?: "Sin fecha límite",
                    "${numeroCorto(tarea.puntosMaximos)} pts"
                ).joinToString(" · "),
                color = MaterialTheme.colorScheme.secondary,
                fontSize = 12.sp
            )
        }
        val n = tarea.entregas ?: 0
        EtiquetaEstado(
            if (n == 1) "1 entrega" else "$n entregas",
            if (n > 0) institutionalColor else textColor.copy(alpha = 0.6f)
        )
    }
}

// ---------- Crear tarea ----------

@Composable
fun DialogoCrearTarea(idCurso: Int, institutionalColor: Color, onCerrar: () -> Unit, onCreada: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colorTexto = MaterialTheme.colorScheme.onSurface
    var titulo by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }
    var puntos by remember { mutableStateOf("10") }
    // Fecha límite como "AAAA-MM-DD HH:MM", o null si no tiene.
    var fechaLimite by remember { mutableStateOf<String?>(null) }
    var archivo by remember { mutableStateOf<ArchivoLocal?>(null) }
    var enviando by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val selector = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val elegido = try { ArchivosAdjuntos.describir(context, uri) } catch (_: Exception) { null }
            if (elegido == null) {
                error = "No se pudo leer el archivo elegido"
            } else {
                error = ArchivosAdjuntos.validarTamano(elegido)
                if (error == null) archivo = elegido
            }
        }
    }

    // Primero la fecha y luego la hora (por defecto 23:59).
    val elegirFecha: () -> Unit = {
        val hoy = Calendar.getInstance()
        DatePickerDialog(context, { _, anio, mes, dia ->
            TimePickerDialog(context, { _, hora, minuto ->
                fechaLimite = String.format(Locale.US, "%04d-%02d-%02d %02d:%02d", anio, mes + 1, dia, hora, minuto)
            }, 23, 59, true).show()
        }, hoy.get(Calendar.YEAR), hoy.get(Calendar.MONTH), hoy.get(Calendar.DAY_OF_MONTH)).apply {
            datePicker.minDate = hoy.timeInMillis - 1000
        }.show()
    }

    val crear: () -> Unit = crear@{
        if (enviando) return@crear
        val puntosNum = puntos.trim().toIntOrNull()
        when {
            titulo.isBlank() -> { error = "Escribe el título de la tarea"; return@crear }
            puntosNum == null || puntosNum !in 1..100 -> { error = "Los puntos deben ser un número del 1 al 100"; return@crear }
        }
        enviando = true
        error = null
        val elegido = archivo
        scope.launch {
            val resultado = runCatching {
                val idArchivo = elegido?.let {
                    Tareas.subirArchivo(idCurso, Tareas.Categoria.TAREA, it.nombre, it.mime) {
                        ArchivosAdjuntos.leerBytes(context, it)
                    }.getOrThrow()
                }
                Tareas.crear(idCurso, titulo.trim(), descripcion.trim(), fechaLimite, puntosNum, idArchivo).getOrThrow()
            }
            enviando = false
            resultado
                .onSuccess {
                    Toast.makeText(context, "Tarea publicada", Toast.LENGTH_SHORT).show()
                    onCreada()
                }
                .onFailure { error = it.message ?: "No se pudo publicar la tarea" }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!enviando) onCerrar() },
        containerColor = if (modoClaro()) MaterialTheme.colorScheme.surface else Color(0xFF2C2C2C),
        title = { Text("Nueva tarea", color = colorTexto) },
        text = {
            val campo = OutlinedTextFieldDefaults.colors(focusedTextColor = colorTexto, unfocusedTextColor = colorTexto)
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = titulo,
                    onValueChange = { titulo = it.take(150) },
                    label = { Text("Título") },
                    enabled = !enviando,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = campo
                )
                OutlinedTextField(
                    value = descripcion,
                    onValueChange = { descripcion = it },
                    label = { Text("Instrucciones (opcional)") },
                    enabled = !enviando,
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth(),
                    colors = campo
                )
                OutlinedTextField(
                    value = puntos,
                    onValueChange = { v -> puntos = v.filter { it.isDigit() }.take(3) },
                    label = { Text("Puntos máximos (1 a 100)") },
                    enabled = !enviando,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = campo
                )
                val fecha = fechaLimite
                if (fecha != null) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color.Transparent,
                        border = BorderStroke(1.dp, colorTexto.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable(enabled = !enviando, onClick = elegirFecha)
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = colorTexto, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Entrega: ${fechaCorta(fecha)}", color = colorTexto, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            IconButton(onClick = { fechaLimite = null }, enabled = !enviando, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Quitar fecha", tint = colorTexto, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                } else {
                    OutlinedButton(onClick = elegirFecha, enabled = !enviando, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = colorTexto, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Fecha límite (opcional)", color = colorTexto)
                    }
                }
                val elegido = archivo
                if (elegido != null) {
                    FilaArchivoAdjunto(
                        nombre = elegido.nombre,
                        detalle = ArchivosAdjuntos.tamanoLegible(elegido.tamano),
                        textColor = colorTexto,
                        onQuitar = if (enviando) null else ({ archivo = null })
                    )
                } else {
                    OutlinedButton(onClick = { selector.launch(arrayOf("*/*")) }, enabled = !enviando, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.AttachFile, contentDescription = null, tint = colorTexto, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Adjuntar archivo (opcional)", color = colorTexto)
                    }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            Button(onClick = crear, enabled = !enviando, colors = ButtonDefaults.buttonColors(containerColor = institutionalColor)) {
                if (enviando) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                } else {
                    Text("Publicar", color = Color.White)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onCerrar, enabled = !enviando) { Text("Cancelar", color = colorTexto) }
        }
    )
}

// ---------- Entregas de una tarea ----------

/** Contenido de la pantalla de entregas de [tarea] (va debajo del encabezado del portal). */
@Composable
fun PantallaEntregasProfesor(
    tarea: PaeTarea,
    cardBg: Color,
    cardBorder: BorderStroke,
    institutionalColor: Color,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val textColor = MaterialTheme.colorScheme.onBackground
    var entregas by remember { mutableStateOf<List<PaeEntrega>>(emptyList()) }
    var cargando by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var calificando by remember { mutableStateOf<PaeEntrega?>(null) }

    val cargar: () -> Unit = {
        cargando = true
        error = null
        scope.launch {
            Tareas.entregas(tarea.id)
                .onSuccess { entregas = it }
                .onFailure { error = it.message }
            cargando = false
        }
    }
    LaunchedEffect(tarea.id) { cargar() }

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Regresar", tint = MaterialTheme.colorScheme.tertiary)
            Spacer(Modifier.width(8.dp))
            Text("Volver a la clase", color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
        }

        // Datos de la tarea
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            border = cardBorder
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(tarea.titulo ?: "Tarea", color = textColor, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    listOf(
                        fechaCorta(tarea.fechaLimite)?.let { "Entrega: $it" } ?: "Sin fecha límite",
                        "${numeroCorto(tarea.puntosMaximos)} puntos"
                    ).joinToString(" · "),
                    color = MaterialTheme.colorScheme.secondary,
                    fontSize = 13.sp
                )
                if (!tarea.descripcion.isNullOrBlank()) {
                    Text(tarea.descripcion, color = textColor, fontSize = 14.sp)
                }
                tarea.idArchivo?.let { ArchivoDeAnuncio(idArchivo = it, nombre = tarea.archivoNombre, textColor = textColor) }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            val revisadas = entregas.count { it.estado.equals("REVISADA", ignoreCase = true) }
            Text(
                if (cargando && entregas.isEmpty()) "Cargando entregas..."
                else "${if (entregas.size == 1) "1 entrega" else "${entregas.size} entregas"} · " +
                    if (revisadas == 1) "1 calificada" else "$revisadas calificadas",
                color = textColor,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = cargar, enabled = !cargando, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Refresh, contentDescription = "Actualizar", tint = textColor, modifier = Modifier.size(20.dp))
            }
        }

        error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
        if (!cargando && error == null && entregas.isEmpty()) {
            Text("Todavía no hay entregas.", color = textColor, fontSize = 14.sp)
        }

        entregas.forEach { e ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = cardBg),
                border = cardBorder
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(e.alumno ?: "Alumno", color = textColor, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(
                                listOfNotNull(e.boleta, fechaCorta(e.fecha)).joinToString(" · "),
                                color = MaterialTheme.colorScheme.secondary,
                                fontSize = 12.sp
                            )
                        }
                        val revisada = e.estado.equals("REVISADA", ignoreCase = true)
                        EtiquetaEstado(if (revisada) "Revisada" else "Entregada", colorEstadoEntrega(e.estado), sobreFondoClaro = modoClaro())
                    }
                    if (!e.contenido.isNullOrBlank()) {
                        Text(e.contenido, color = textColor, fontSize = 14.sp)
                    }
                    e.idArchivo?.let { ArchivoDeAnuncio(idArchivo = it, nombre = e.archivoNombre, textColor = textColor) }
                    e.archivoUrl?.takeIf { it.isNotBlank() }?.let { url ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth().clickable {
                                ArchivosAdjuntos.abrirEnlace(context, url)?.let { Toast.makeText(context, it, Toast.LENGTH_LONG).show() }
                            }.padding(vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Link, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(url, color = MaterialTheme.colorScheme.tertiary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (e.calificacion != null) {
                        HorizontalDivider(color = textColor.copy(alpha = 0.12f))
                        Text(
                            "Calificación: ${numeroCorto(e.calificacion)} / ${numeroCorto(tarea.puntosMaximos)}",
                            color = textColor,
                            fontWeight = FontWeight.Bold
                        )
                        if (!e.comentario.isNullOrBlank()) {
                            Text(e.comentario, color = MaterialTheme.colorScheme.secondary, fontSize = 13.sp)
                        }
                    }
                    OutlinedButton(
                        onClick = { calificando = e },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, institutionalColor)
                    ) {
                        Text(if (e.calificacion != null) "Cambiar calificación" else "Calificar", color = textColor)
                    }
                }
            }
        }
        Spacer(Modifier.height(32.dp))
    }

    calificando?.let { e ->
        DialogoCalificar(
            entrega = e,
            puntosMaximos = tarea.puntosMaximos ?: 10.0,
            institutionalColor = institutionalColor,
            onCerrar = { calificando = null },
            onCalificada = {
                calificando = null
                cargar()
            }
        )
    }
}

@Composable
fun DialogoCalificar(
    entrega: PaeEntrega,
    puntosMaximos: Double,
    institutionalColor: Color,
    onCerrar: () -> Unit,
    onCalificada: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colorTexto = MaterialTheme.colorScheme.onSurface
    var nota by remember { mutableStateOf(entrega.calificacion?.let { numeroCorto(it) } ?: "") }
    var comentario by remember { mutableStateOf(entrega.comentario.orEmpty()) }
    var enviando by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val guardar: () -> Unit = guardar@{
        if (enviando) return@guardar
        val valor = nota.trim().replace(',', '.').toDoubleOrNull()
        if (valor == null || valor < 0 || valor > puntosMaximos) {
            error = "La calificación debe estar entre 0 y ${numeroCorto(puntosMaximos)}"
            return@guardar
        }
        enviando = true
        error = null
        scope.launch {
            Tareas.calificar(entrega.id, valor, comentario.trim())
                .onSuccess {
                    Toast.makeText(context, "Calificación guardada", Toast.LENGTH_SHORT).show()
                    onCalificada()
                }
                .onFailure { error = it.message }
            enviando = false
        }
    }

    AlertDialog(
        onDismissRequest = { if (!enviando) onCerrar() },
        containerColor = if (modoClaro()) MaterialTheme.colorScheme.surface else Color(0xFF2C2C2C),
        title = { Text("Calificar entrega", color = colorTexto) },
        text = {
            val campo = OutlinedTextFieldDefaults.colors(focusedTextColor = colorTexto, unfocusedTextColor = colorTexto)
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(entrega.alumno ?: "Alumno", color = colorTexto, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = nota,
                    onValueChange = { v -> nota = v.filter { it.isDigit() || it == '.' || it == ',' }.take(6) },
                    label = { Text("Calificación (0 a ${numeroCorto(puntosMaximos)})") },
                    enabled = !enviando,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    colors = campo
                )
                OutlinedTextField(
                    value = comentario,
                    onValueChange = { comentario = it },
                    label = { Text("Comentario (opcional)") },
                    enabled = !enviando,
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                    colors = campo
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            Button(onClick = guardar, enabled = !enviando, colors = ButtonDefaults.buttonColors(containerColor = institutionalColor)) {
                if (enviando) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                } else {
                    Text("Guardar", color = Color.White)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onCerrar, enabled = !enviando) { Text("Cancelar", color = colorTexto) }
        }
    )
}
