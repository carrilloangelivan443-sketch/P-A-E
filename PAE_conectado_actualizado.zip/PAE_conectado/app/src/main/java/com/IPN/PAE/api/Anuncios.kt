package com.IPN.PAE.api

import com.IPN.PAE.Anuncio
import com.IPN.PAE.api.models.PaeAnuncioRequest

/**
 * Anuncios de un curso, identificado por id_curso (no por el nombre de la materia).
 * Todas las funciones corren en IO y regresan Result con un mensaje legible en caso de error.
 */
object Anuncios {

    private val api get() = RetrofitClient.paeApi

    suspend fun listar(idCurso: Int): Result<List<Anuncio>> = llamarApi {
        val r = api.anuncios(idCurso)
        if (!r.isSuccessful) return@llamarApi fallaApi(r)
        val lista = r.body()?.anuncios.orEmpty().map { a ->
            Anuncio(
                id = a.id.toString(),
                autor = a.autor.orEmpty(),
                fecha = a.fecha.orEmpty(),
                mensaje = unirTexto(a.titulo.orEmpty(), a.contenido.orEmpty()),
                idArchivo = a.idArchivo,
                nombreArchivo = a.nombreArchivo
            )
        }
        Result.success(lista)
    }

    /** Profesor: publica un anuncio. La primera línea del texto se usa como título. */
    suspend fun publicar(idCurso: Int, texto: String, idArchivo: Int?): Result<Unit> = llamarApi {
        val r = api.publicarAnuncio(idCurso, cuerpo(texto, idArchivo))
        if (r.isSuccessful) Result.success(Unit) else fallaApi(r)
    }

    /** Profesor: cambia el texto (y el adjunto) de un anuncio existente. */
    suspend fun editar(idAnuncio: Int, texto: String, idArchivo: Int?): Result<Unit> = llamarApi {
        val r = api.editarAnuncio(idAnuncio, cuerpo(texto, idArchivo))
        if (r.isSuccessful) Result.success(Unit) else fallaApi(r)
    }

    suspend fun eliminar(idAnuncio: Int): Result<Unit> = llamarApi {
        val r = api.eliminarAnuncio(idAnuncio)
        if (r.isSuccessful) Result.success(Unit) else fallaApi(r)
    }

    private fun cuerpo(texto: String, idArchivo: Int?): PaeAnuncioRequest {
        val mensaje = texto.trim()
        val titulo = mensaje.lineSequence().first().trim().take(150).ifBlank { "Anuncio" }
        return PaeAnuncioRequest(titulo = titulo, contenido = mensaje, idArchivo = idArchivo)
    }

    private fun unirTexto(titulo: String, contenido: String): String =
        if (titulo.isBlank() || contenido.startsWith(titulo)) contenido else "$titulo\n$contenido"
}
