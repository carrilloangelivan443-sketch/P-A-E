package com.IPN.PAE.api

import com.IPN.PAE.api.models.PaeArchivoSubido
import com.IPN.PAE.api.models.PaeCalificarRequest
import com.IPN.PAE.api.models.PaeCrearTareaRequest
import com.IPN.PAE.api.models.PaeEntrega
import com.IPN.PAE.api.models.PaeEntregaRequest
import com.IPN.PAE.api.models.PaeTarea
import com.google.gson.Gson
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Tareas de un curso: listar, crear, entregar y calificar.
 * Todas las funciones corren en IO y regresan Result con un mensaje legible en caso de error.
 */
object Tareas {

    private val api get() = RetrofitClient.paeApi

    /** Categorías válidas de POST /archivos. */
    object Categoria {
        const val TAREA = "tarea"       // profesor: archivo de instrucciones
        const val ENTREGA = "entrega"   // alumno: archivo de su entrega
        const val ANUNCIO = "anuncio"   // profesor: adjunto de un anuncio
    }

    /** Tareas del curso (alumno: con su entrega; profesor: con el número de entregas). */
    suspend fun listar(idCurso: Int): Result<List<PaeTarea>> = llamarApi {
        val r = api.tareas(idCurso)
        if (r.isSuccessful) Result.success(r.body()?.tareas.orEmpty()) else fallaApi(r)
    }

    /** Profesor: crea una tarea. [fechaEntrega] en formato "AAAA-MM-DD HH:MM". Regresa el id de la tarea. */
    suspend fun crear(
        idCurso: Int,
        titulo: String,
        descripcion: String?,
        fechaEntrega: String?,
        puntosMaximos: Int?,
        idArchivo: Int?
    ): Result<Int?> = llamarApi {
        val r = api.crearTarea(
            idCurso,
            PaeCrearTareaRequest(
                titulo = titulo,
                descripcion = descripcion?.ifBlank { null },
                fechaEntrega = fechaEntrega,
                puntosMaximos = puntosMaximos,
                idArchivo = idArchivo
            )
        )
        if (r.isSuccessful) Result.success(r.body()?.id) else fallaApi(r)
    }

    /**
     * Alumno: entrega (o vuelve a entregar) una tarea. Se necesita al menos uno de los tres campos.
     * Si [idArchivo] es null, el servidor conserva el archivo de la entrega anterior.
     */
    suspend fun entregar(
        idTarea: Int,
        contenido: String?,
        archivoUrl: String?,
        idArchivo: Int?
    ): Result<Unit> = llamarApi {
        val r = api.entregarTarea(
            idTarea,
            PaeEntregaRequest(
                contenido = contenido?.ifBlank { null },
                archivoUrl = archivoUrl?.ifBlank { null },
                idArchivo = idArchivo
            )
        )
        when {
            r.isSuccessful -> Result.success(Unit)
            r.code() == 409 -> Result.failure(Exception("Esta tarea ya fue calificada; ya no se puede cambiar la entrega"))
            else -> fallaApi(r)
        }
    }

    /** Profesor: entregas de los alumnos para una tarea. */
    suspend fun entregas(idTarea: Int): Result<List<PaeEntrega>> = llamarApi {
        val r = api.entregasTarea(idTarea)
        if (r.isSuccessful) Result.success(r.body()?.entregas.orEmpty()) else fallaApi(r)
    }

    /** Profesor: califica una entrega (0 a puntos_maximos). */
    suspend fun calificar(idEntrega: Int, calificacion: Double, comentario: String?): Result<Unit> = llamarApi {
        val r = api.calificarEntrega(idEntrega, PaeCalificarRequest(calificacion, comentario?.ifBlank { null }))
        if (r.isSuccessful) Result.success(Unit) else fallaApi(r)
    }

    /** Sube un archivo del curso (POST /archivos) y regresa su id_archivo. */
    suspend fun subirArchivo(
        idCurso: Int,
        categoria: String,
        nombre: String,
        mime: String,
        leerBytes: () -> ByteArray
    ): Result<Int> = llamarApi {
        val texto = "text/plain".toMediaType()
        val parte = MultipartBody.Part.createFormData(
            "archivo", nombre, leerBytes().toRequestBody(mime.toMediaTypeOrNull())
        )
        val r = api.subirArchivo(
            archivo = parte,
            categoria = categoria.toRequestBody(texto),
            idCurso = idCurso.toString().toRequestBody(texto)
        )
        if (!r.isSuccessful) return@llamarApi fallaApi(r)
        val subido = r.body()?.let { Gson().fromJson(it, PaeArchivoSubido::class.java) }
        val id = subido?.idArchivo
            ?: return@llamarApi Result.failure(Exception("El servidor no regresó el id del archivo"))
        Result.success(id)
    }
}

/** 9.0 → "9", 9.5 → "9.5". */
fun numeroCorto(valor: Double?): String {
    if (valor == null) return "-"
    return if (valor % 1.0 == 0.0) valor.toLong().toString() else valor.toString()
}

/** "2026-11-30 23:59:00" → "30/11/2026 23:59". Si no reconoce el formato, regresa el texto tal cual. */
fun fechaCorta(fecha: String?): String? {
    if (fecha.isNullOrBlank()) return null
    val m = Regex("(\\d{4})-(\\d{2})-(\\d{2})(?:[ T](\\d{2}):(\\d{2}))?").find(fecha) ?: return fecha
    val (a, mes, d, h, min) = m.destructured
    return if (h.isNotEmpty()) "$d/$mes/$a $h:$min" else "$d/$mes/$a"
}
