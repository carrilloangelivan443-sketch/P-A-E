@file:Suppress("PackageName")

package com.IPN.PAE

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.view.SurfaceView
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.SwitchCamera
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import io.agora.rtc2.Constants
import io.agora.rtc2.IRtcEngineEventHandler
import io.agora.rtc2.RtcEngine
import io.agora.rtc2.RtcEngineConfig
import io.agora.rtc2.video.VideoCanvas
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.IPN.PAE.api.Videollamadas
import com.IPN.PAE.api.models.CredencialesAgora
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/** Respaldo por si el servidor no manda app_id. */
val AGORA_APP_ID: String = BuildConfig.AGORA_APP_ID

@Composable
fun AgoraVideoCallContainer(
    idCurso: Int,
    credenciales: CredencialesAgora,
    onEndCall: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var hasPermissions by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        val cameraGranted = permissions[Manifest.permission.CAMERA] ?: false
        hasPermissions = audioGranted && cameraGranted
        if (!hasPermissions) {
            Toast.makeText(context, "Se requieren permisos de cámara y micrófono para la videollamada.", Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(Unit) {
        if (!hasPermissions) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CAMERA
                )
            )
        }
    }

    if (hasPermissions) {
        AgoraVideoCallContent(
            idCurso = idCurso,
            credenciales = credenciales,
            onEndCall = onEndCall,
            modifier = modifier
        )
    } else {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Permisos necesarios no concedidos.",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        permissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.RECORD_AUDIO,
                                Manifest.permission.CAMERA
                            )
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7D2242))
                ) {
                    Text("CONCEDER PERMISOS", color = Color.White)
                }
            }
        }
    }
}

@SuppressLint("NewApi")
@Composable
private fun AgoraVideoCallContent(
    idCurso: Int,
    credenciales: CredencialesAgora,
    onEndCall: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val scope = rememberCoroutineScope()

    var rtcEngine by remember { mutableStateOf<RtcEngine?>(null) }
    var remoteUid by remember { mutableStateOf<Int?>(null) }
    var isJoined by remember { mutableStateOf(false) }

    var isMutedAudio by remember { mutableStateOf(false) }
    var isMutedVideo by remember { mutableStateOf(false) }

    // Canal, token y uid los asigna el servidor; se usan tal cual (el token solo vale para ese canal y ese uid).
    val formattedChannel = credenciales.canal

    DisposableEffect(credenciales) {
        var engine: RtcEngine? = null
        val renovando = AtomicBoolean(false)

        // Pide un token nuevo al servidor y se lo pasa a Agora sin salir del canal.
        fun renovarToken() {
            if (!renovando.compareAndSet(false, true)) return
            scope.launch {
                Videollamadas.renovarToken(idCurso)
                    .onSuccess { nuevas -> engine?.renewToken(nuevas.token) }
                    .onFailure { e ->
                        Log.w("AgoraVideoCall", "No se pudo renovar el token", e)
                        Toast.makeText(context, "No se pudo renovar la conexión: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                renovando.set(false)
            }
        }

        val eventHandler = object : IRtcEngineEventHandler() {

            // Agora avisa ~30 s antes de que venza el token.
            override fun onTokenPrivilegeWillExpire(token: String?) {
                mainHandler.post { renovarToken() }
            }

            // El token ya venció (por ejemplo, si el aviso anterior no alcanzó a renovarlo).
            override fun onRequestToken() {
                mainHandler.post { renovarToken() }
            }

            override fun onJoinChannelSuccess(
                channel: String?,
                uid: Int,
                elapsed: Int
            ) {
                mainHandler.post {
                    isJoined = true
                }
            }

            override fun onUserJoined(
                uid: Int,
                elapsed: Int
            ) {
                mainHandler.post {
                    remoteUid = uid
                }
            }

            override fun onUserOffline(
                uid: Int,
                reason: Int
            ) {
                mainHandler.post {
                    if (remoteUid == uid) {
                        remoteUid = null
                    }
                }
            }

            override fun onError(errorCode: Int) {
                mainHandler.post {
                    Toast.makeText(
                        context,
                        "Error de Agora: $errorCode",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }

        try {
            val config = RtcEngineConfig().apply {
                mContext = context
                mAppId = credenciales.appId.ifBlank { AGORA_APP_ID }
                mEventHandler = eventHandler
            }
            val nuevo = RtcEngine.create(config)
            engine = nuevo
            nuevo.enableVideo()
            nuevo.enableAudio()

            nuevo.setChannelProfile(
                Constants.CHANNEL_PROFILE_COMMUNICATION
            )

            nuevo.startPreview()

            nuevo.joinChannel(
                credenciales.token,
                credenciales.canal,
                "",
                credenciales.uid
            )
            rtcEngine = nuevo
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Error al iniciar videollamada: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }

        onDispose {
            engine = null
            rtcEngine?.apply {
                stopPreview()
                leaveChannel()
            }
            RtcEngine.destroy()
            rtcEngine = null
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // 1. VIDEO DE FONDO (Remoto si existe, o local si está solo)
        if (remoteUid != null && rtcEngine != null) {
            AndroidView(
                factory = { ctx ->
                    SurfaceView(ctx).apply {
                        rtcEngine?.setupRemoteVideo(
                            VideoCanvas(this, VideoCanvas.RENDER_MODE_HIDDEN, remoteUid!!)
                        )
                    }
                },
                update = { surfaceView ->
                    rtcEngine?.setupRemoteVideo(
                        VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_HIDDEN, remoteUid!!)
                    )
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Si no hay remoto, la cámara local ocupa la pantalla completa
            if (rtcEngine != null && !isMutedVideo) {
                AndroidView(
                    factory = { ctx ->
                        SurfaceView(ctx).apply {
                            rtcEngine?.setupLocalVideo(
                                VideoCanvas(this, VideoCanvas.RENDER_MODE_HIDDEN, 0)
                            )
                        }
                    },
                    update = { surfaceView ->
                        rtcEngine?.setupLocalVideo(
                            VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_HIDDEN, 0)
                        )
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF1E1E1E)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isMutedVideo) "Cámara apagada" else "Conectando al aula virtual...",
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }

        // 2. VIDEO EN MINIATURA (Local PiP si hay un usuario remoto)
        if (remoteUid != null && rtcEngine != null && !isMutedVideo) {
            Box(
                modifier = Modifier
                    .padding(top = 48.dp, end = 16.dp)
                    .size(width = 110.dp, height = 160.dp)
                    .align(Alignment.TopEnd)
                    .clip(RoundedCornerShape(12.dp))
                    .border(2.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            ) {
                AndroidView(
                    factory = { ctx ->
                        SurfaceView(ctx).apply {
                            setZOrderMediaOverlay(true)
                            rtcEngine?.setupLocalVideo(
                                VideoCanvas(this, VideoCanvas.RENDER_MODE_HIDDEN, 0)
                            )
                        }
                    },
                    update = { surfaceView ->
                        rtcEngine?.setupLocalVideo(
                            VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_HIDDEN, 0)
                        )
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // 3. BARRA SUPERIOR CON ESTADO Y CANAL
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp, start = 16.dp, end = 16.dp)
                .align(Alignment.TopCenter)
                .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Canal: $formattedChannel",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = if (remoteUid != null) "● En clase (Participantes activos)" else "● Esperando más participantes...",
                    color = if (remoteUid != null) Color(0xFF81C784) else Color(0xFFFFB4A2),
                    fontSize = 12.sp
                )
            }
        }

        // 4. BARRA DE CONTROLES INFERIOR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
                .align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Silenciar / Activar Micrófono
            IconButton(
                onClick = {
                    isMutedAudio = !isMutedAudio
                    rtcEngine?.muteLocalAudioStream(isMutedAudio)
                },
                modifier = Modifier
                    .size(52.dp)
                    .background(
                        if (isMutedAudio) Color.Red else Color.White.copy(alpha = 0.25f),
                        CircleShape
                    )
            ) {
                Icon(
                    imageVector = if (isMutedAudio) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Micrófono",
                    tint = Color.White
                )
            }

            // Cambiar Cámara
            IconButton(
                onClick = {
                    rtcEngine?.switchCamera()
                },
                modifier = Modifier
                    .size(52.dp)
                    .background(Color.White.copy(alpha = 0.25f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.SwitchCamera,
                    contentDescription = "Cambiar Cámara",
                    tint = Color.White
                )
            }

            // Encender / Apagar Video
            IconButton(
                onClick = {
                    isMutedVideo = !isMutedVideo
                    rtcEngine?.muteLocalVideoStream(isMutedVideo)
                },
                modifier = Modifier
                    .size(52.dp)
                    .background(
                        if (isMutedVideo) Color.Red else Color.White.copy(alpha = 0.25f),
                        CircleShape
                    )
            ) {
                Icon(
                    imageVector = if (isMutedVideo) Icons.Default.VideocamOff else Icons.Default.Videocam,
                    contentDescription = "Cámara",
                    tint = Color.White
                )
            }

            // Colgar / Salir de la Clase
            IconButton(
                onClick = {
                    rtcEngine?.stopPreview()
                    rtcEngine?.leaveChannel()
                    onEndCall()
                },
                modifier = Modifier
                    .size(56.dp)
                    .background(Color(0xFFE53935), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.CallEnd,
                    contentDescription = "Finalizar Llamada",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }
}
