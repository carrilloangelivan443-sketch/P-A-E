package com.IPN.PAE

import android.content.ActivityNotFoundException
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import com.IPN.PAE.api.Actualizaciones
import com.IPN.PAE.api.Actualizaciones.Estado
import java.io.File

/**
 * Revisa si hay una versión nueva de la app y, si la hay, muestra el aviso para descargarla e instalarla.
 * Se coloca en la pantalla principal (alumno) y en el portal de profesores. Si no hay internet
 * o el servidor no responde, no muestra nada.
 */
@Composable
fun AvisoActualizacion() {
    val context = LocalContext.current
    LaunchedEffect(Unit) { Actualizaciones.revisar(context) }

    val estado by Actualizaciones.estado.collectAsState()
    // Android 8+: falta el permiso de "instalar apps desconocidas"; se explica antes de ir a Ajustes.
    var faltaPermiso by remember { mutableStateOf(false) }
    var errorInstalador by remember { mutableStateOf(false) }

    fun instalar(archivo: File) {
        if (!Actualizaciones.puedeInstalar(context)) {
            faltaPermiso = true
            return
        }
        faltaPermiso = false
        errorInstalador = !Actualizaciones.abrirInstalador(context, archivo)
    }

    // Al volver de Ajustes: si ya dio el permiso, se instala directamente.
    val ajustesLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        val e = Actualizaciones.estado.value
        if (e is Estado.Descargada && Actualizaciones.puedeInstalar(context)) instalar(e.archivo)
    }

    // En cuanto termina la descarga se abre el instalador (una sola vez; después hay botón "Instalar").
    LaunchedEffect(estado) {
        val e = estado
        if (e is Estado.Descargada && !e.instaladorAbierto && !faltaPermiso && !errorInstalador) instalar(e.archivo)
    }

    val version = Actualizaciones.versionActual() ?: return
    val descargando = estado is Estado.Descargando
    val puedePosponer = !version.obligatoria && !descargando

    AlertDialog(
        onDismissRequest = { if (puedePosponer) Actualizaciones.posponer() },
        properties = DialogProperties(
            dismissOnBackPress = puedePosponer,
            dismissOnClickOutside = false
        ),
        title = { Text("Nueva versión ${version.nombre}") },
        text = {
            Column(Modifier.fillMaxWidth()) {
                when {
                    faltaPermiso -> Text(
                        "Para instalar la actualización, Android necesita que permitas a PAE instalar apps.\n\n" +
                            "Toca \"Ir a Ajustes\", activa \"Permitir de esta fuente\" y regresa con el botón Atrás."
                    )

                    errorInstalador -> Text("No se pudo abrir el instalador de Android. Inténtalo de nuevo.")

                    else -> {
                        if (version.obligatoria) {
                            Text(
                                "Esta actualización es necesaria para seguir usando la app.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.error
                            )
                            Spacer(Modifier.height(8.dp))
                        }
                        if (version.notas.isNotBlank()) {
                            Text(
                                version.notas,
                                modifier = Modifier
                                    .heightIn(max = 220.dp)
                                    .verticalScroll(rememberScrollState())
                            )
                        } else {
                            Text("Hay una versión nueva de PAE disponible.")
                        }
                        when (val e = estado) {
                            is Estado.Descargando -> {
                                Spacer(Modifier.height(16.dp))
                                val p = e.progreso
                                if (p != null) {
                                    LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
                                    Spacer(Modifier.height(4.dp))
                                    Text("Descargando… ${(p * 100).toInt()} %", style = MaterialTheme.typography.bodySmall)
                                } else {
                                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                                    Spacer(Modifier.height(4.dp))
                                    Text("Descargando…", style = MaterialTheme.typography.bodySmall)
                                }
                            }

                            is Estado.ErrorDescarga -> {
                                Spacer(Modifier.height(12.dp))
                                Text(e.mensaje, color = MaterialTheme.colorScheme.error)
                            }

                            is Estado.Descargada -> if (e.instaladorAbierto) {
                                Spacer(Modifier.height(12.dp))
                                Text(
                                    "Si cancelaste la instalación, toca \"Instalar\" para intentarlo otra vez.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }

                            else -> Unit
                        }
                    }
                }
            }
        },
        confirmButton = {
            when (val e = estado) {
                is Estado.Descargando -> Unit
                is Estado.Descargada -> when {
                    faltaPermiso -> Button(onClick = {
                        try {
                            ajustesLauncher.launch(Actualizaciones.intentPermiso(context))
                        } catch (_: ActivityNotFoundException) {
                            // Algunos fabricantes no tienen esa pantalla: se abren los Ajustes generales.
                            ajustesLauncher.launch(Intent(Settings.ACTION_SETTINGS))
                        }
                    }) { Text("Ir a Ajustes") }

                    else -> Button(onClick = { instalar(e.archivo) }) { Text("Instalar") }
                }

                is Estado.ErrorDescarga -> Button(onClick = { Actualizaciones.descargar(context) }) { Text("Reintentar") }
                else -> Button(onClick = { Actualizaciones.descargar(context) }) { Text("Actualizar") }
            }
        },
        dismissButton = if (puedePosponer) {
            { TextButton(onClick = { Actualizaciones.posponer() }) { Text("Después") } }
        } else null
    )
}
