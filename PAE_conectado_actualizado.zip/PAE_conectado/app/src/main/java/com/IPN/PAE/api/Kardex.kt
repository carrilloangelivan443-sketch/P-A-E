package com.IPN.PAE.api

import com.IPN.PAE.api.models.PaeKardexResponse

/** Kárdex del alumno (GET /kardex). Corre en IO y regresa Result con un mensaje legible. */
object Kardex {

    private val api get() = RetrofitClient.paeApi

    /** Kárdex con su resumen; el estatus ("Regular", ...) viene aparte en /yo. */
    data class Datos(val kardex: PaeKardexResponse, val estatus: String?)

    suspend fun consultar(): Result<Datos> = llamarApi {
        val r = api.kardex()
        val body = r.body()
        if (!r.isSuccessful || body == null) return@llamarApi fallaApi(r)
        // El estatus es un extra: si /yo falla, el kárdex se muestra igual.
        val estatus = try { api.yoSesion().body()?.datos?.estatus } catch (_: Exception) { null }
        Result.success(Datos(body, estatus))
    }
}
