# PAE conectado

App Android (Kotlin + Jetpack Compose, Retrofit + Gson) para alumnos y profesores del PAE.

## Código relevante
- `app/src/main/java/com/IPN/PAE/api/PaeApi.kt` — rutas reales de la API (Retrofit).
- `api/PaeApiAdapter.kt` — adapta la API real a la interfaz `AuthApi` que usan las pantallas antiguas.
- `api/Videollamadas.kt` — patrón preferido para código nuevo: `object` con funciones `suspend` que corren en IO y regresan `Result<T>` con mensaje legible (lee `{"error"}`).
- `api/models/PaeModels.kt` — modelos de la API (campos nullable). `LoginModels.kt` — modelos de las pantallas.
- `api/RetrofitClient.kt` — agrega `Authorization: Bearer <token>` automáticamente.
- `api/Actualizaciones.kt` + `AvisoActualizacion.kt` — autoactualización desde el servidor: revisa `/app/version` una vez por arranque (en silencio si falla), descarga el APK a `cache/actualizaciones/`, verifica SHA-256 y lo instala con FileProvider (`${applicationId}.archivos`).
- `ArchivosAdjuntos.kt` — elegir, subir (máx. 25 MB) y abrir archivos adjuntos.
- `MateriaDetalleActivity.kt` (alumno: pestañas Novedades / Tareas / En vivo) y `PortalProfesoresActivity.kt` (profesor).
- La API vive en el repositorio aparte `pae-api`; este repositorio es solo la app.

## Reglas
- Identificar cursos por `id_curso` (`MateriaDto.id`), no por el nombre de la materia.
- Se pueden consultar rutas GET para ver respuestas reales, pero **no crear datos en el servidor sin preguntar**.
- Usuarios de prueba: alumno `2024050172` / `Prueba123`, profesor `acruz` / `Prueba123`.
- Datos de prueba de tareas: curso 3 (Programación Orientada a Objetos), tarea "Práctica con archivo" con una entrega del alumno 2024050172. Solo se pueden crear tareas de prueba en el curso 3.
- Límite de archivos: el servidor acepta hasta 500 MB (5 MB en fotos de perfil). La app limita a 25 MB con la constante `ArchivosAdjuntos.TAMANO_MAXIMO`.

## API del servidor

Base: `https://pae.tail98eed5.ts.net/api/` (`BuildConfig.BASE_URL`).
Todas las rutas, menos `/estado`, `/login` y `/app/version`, piden `Authorization: Bearer <token>`.
Los errores llegan como `{"error":"mensaje"}` (401 sin sesión: `"Inicia sesión para continuar"`).

### Sesión y usuario
- `GET /app/version` (pública, sin token) → `{"versionCode","versionName","apkUrl","notas","obligatoria","sha256","tamano"}`; 404 si no hay versión publicada. La usa `api/Actualizaciones.kt` (autoactualización; ver README).
- `GET /estado` → `{"estado":"ok","base_de_datos":"conectada","tablas":17}`
- `POST /login` `{"usuario","contrasena"}` → `{"token","rol":"alumno"|"profesor","expira_en_horas":24,"usuario":{"id","nombre"}}`
- `POST /logout`
- `GET /yo`
  - Alumno: `{"rol":"alumno","datos":{"boleta","nombre","correo","id_foto","estatus","grupo"}}`
  - Profesor: `{"rol":"profesor","datos":{"num_empleado","nombre","usuario","id_foto"}}`
- `POST /yo/foto` — sube la foto de perfil. Multipart con el campo `archivo`; acepta JPG, PNG o WEBP, máximo 5 MB.
  → `{"id_archivo","nombre","tipo","tamano","mensaje"}`. Después `GET /yo` trae `id_foto` y la imagen se descarga con `GET /archivos/{id_foto}` (con token).

### Cursos y kárdex
- `GET /cursos`
  - Alumno: `{"cursos":[{"id_curso","codigo","materia","creditos","profesor","grupo","horario","aula","periodo","parcial_1","parcial_2","parcial_3","extraordinario","final"}]}`
  - Profesor: `{"cursos":[{"id_curso","codigo","materia","grupo","horario","aula","alumnos"}]}`
- `GET /kardex` (alumno) → `{"resumen":{"promedio","materias_calificadas","creditos_cursados","creditos_aprobados"},"materias":[{"periodo","semestre","codigo","materia","creditos","final","extraordinario","situacion"}]}` (`situacion`: `"EN CURSO"`, `"APROBADA"`, …). El profesor recibe 403.

### Anuncios
- `GET /cursos/{id}/anuncios` → `{"anuncios":[{"id","titulo","contenido","fecha","autor","id_archivo","nombre_archivo"}]}`
- `POST /cursos/{id}/anuncios` (profesor) `{"titulo","contenido","id_archivo"?}`
- `PUT /anuncios/{id}` (profesor) — edita; la app manda el mismo cuerpo que al publicar. `DELETE /anuncios/{id}` (profesor). Ambas responden 404 `"Anuncio no encontrado"` con un id inexistente (ver `api/Anuncios.kt`).

### Archivos
- `POST /archivos` multipart: `archivo`, `categoria`, `id_curso`. Profesor usa `categoria` `"tarea"` o `"anuncio"`; alumno `"entrega"`.
  → `{"id_archivo","nombre","tipo","tamano"}`
- `GET /archivos/{id}` — descarga el contenido (con token).

### Videollamadas
- `GET /cursos/{id}/videollamada` → `{"sesion":{"id","canal","estado":"EN_VIVO"|"PROGRAMADA","inicio","fin"} | null}`
- `POST /cursos/{id}/videollamada/iniciar` (profesor) → `{"sesion",...,"mensaje","app_id","token","uid","expira_en_segundos"}`
- `POST /cursos/{id}/videollamada/finalizar` (profesor) → `{"mensaje","id_sesion"}`; 409 si no hay clase en vivo.
- `POST /cursos/{id}/videollamada/unirse` (alumno) → `{"canal","asistencia":"PRESENTE"|"RETARDO","app_id","token","uid","expira_en_segundos"}`; 409 si no ha iniciado.
- `POST /cursos/{id}/videollamada/token` (profesor o alumno) → `{"canal","app_id","token","uid","expira_en_segundos"}` mientras la clase siga en vivo; 409 si no.
- Tokens de Agora: el servidor los genera (`uid` es Int, `expira_en_segundos` = 7200). En `joinChannel` se usan exactamente el `token`, el `canal` y el `uid` del servidor (si el uid no coincide, Agora rechaza el token) y el `app_id` del servidor para crear el motor (`BuildConfig.AGORA_APP_ID` solo es respaldo). Cuando Agora avisa `onTokenPrivilegeWillExpire` (o `onRequestToken`), la app pide uno nuevo con `/token` y llama a `renewToken` (ver `AgoraVideoCallScreen.kt` y `Videollamadas.renovarToken`).
- `POST /cursos/{id}/videollamada/salir` (alumno)
- `GET /sesiones/{id}/asistencia` (profesor) → `{"asistencia":[{"boleta","alumno","estado":"PRESENTE"|"RETARDO"|"AUSENTE","entrada","salida"}]}`

### Tareas
- `GET /cursos/{id}/tareas`
  - Alumno: `{"tareas":[{"id","titulo","descripcion","publicada","fecha_limite","puntos_maximos","id_archivo","archivo_nombre","archivo_tipo","estado_entrega","entregada","calificacion","comentario","entrega_id_archivo","entrega_archivo_nombre"}]}`.
    `estado_entrega`: `null` (pendiente), `"ENTREGADA"` o `"REVISADA"`.
  - Profesor: los mismos campos de la tarea, más `"entregas"` (cuántas hay), sin los campos de entrega.
- `POST /cursos/{id}/tareas` (profesor) `{"titulo","descripcion"?,"fecha_entrega"? ("AAAA-MM-DD HH:MM"),"puntos_maximos"? (1 a 100, por defecto 10),"id_archivo"?}` → 201 `{"id","mensaje"}`
- `POST /tareas/{id}/entrega` (alumno) `{"contenido"?,"archivo_url"? (https),"id_archivo"?}` — al menos uno. Si no manda `id_archivo`, se conserva el de la entrega anterior. 409 si ya fue calificada.
- `GET /tareas/{id}/entregas` (profesor) → `{"entregas":[{"id","boleta","alumno","contenido","archivo_url","fecha","estado","calificacion","comentario","id_archivo","archivo_nombre","archivo_tipo"}]}`
- `POST /entregas/{id}/calificar` (profesor) `{"calificacion" (0 a puntos_maximos),"comentario"?}`
