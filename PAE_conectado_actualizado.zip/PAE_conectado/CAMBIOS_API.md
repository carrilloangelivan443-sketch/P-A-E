# Cambios: conexión de la app con el servidor PAE

La app ahora usa la API del servidor: https://pae.tail98eed5.ts.net/api/

## Archivos nuevos
- `app/src/main/java/com/IPN/PAE/PaeApplication.kt` — inicializa el cliente de red al abrir la app.
- `app/src/main/java/com/IPN/PAE/api/PaeApi.kt` — rutas reales de la API (login, yo, cursos, anuncios).
- `app/src/main/java/com/IPN/PAE/api/PaeApiAdapter.kt` — traduce entre las pantallas y la API.
- `app/src/main/java/com/IPN/PAE/api/models/PaeModels.kt` — modelos de datos de la API.

## Archivos modificados
- `app/build.gradle.kts` — BASE_URL apunta al servidor (antes: túnel temporal de Cloudflare).
- `app/src/main/AndroidManifest.xml` — se registró `PaeApplication`.
- `app/src/main/java/com/IPN/PAE/api/RetrofitClient.kt` — agrega el token (Authorization: Bearer) en cada petición.
- `app/src/main/java/com/IPN/PAE/PortalProfesoresActivity.kt` — las clases del profesor vienen de la API (antes era una lista fija).

## Qué funciona con la base real
- Inicio de sesión de alumnos (boleta) y profesores (usuario).
- Mis Clases (materias, profesor, aula y horario).
- Calificaciones (parciales y final).
- Novedades de cada materia, y publicar anuncios desde el portal de profesores.

## Tareas (alumno y profesor)
- `api/Tareas.kt` — listar, crear, entregar, ver entregas, calificar y subir archivos (categorías `tarea` y `entrega`).
- `api/ApiResultados.kt` — manejo de errores compartido con `Videollamadas.kt`.
- `TareasAlumno.kt` — pestaña Tareas del alumno: estado (Pendiente/Vencida/Entregada/Revisada), detalle, entrega con texto, enlace https y archivo; calificación y comentario del profesor.
- `TareasProfesor.kt` — sección Tareas del portal: crear tarea (fecha y hora límite, puntos, archivo), ver entregas y calificar.
- Límite de archivos de la app: `ArchivosAdjuntos.TAMANO_MAXIMO_MB` (25 MB; el servidor acepta hasta 500 MB).

## Kárdex
- `api/Kardex.kt` y `KardexActivity.kt` — el kárdex viene de `GET /kardex` (promedio, créditos, materias por semestre con calificación y situación); el estatus del alumno viene de `GET /yo`.

## Limpieza del repositorio
- Se borró la carpeta `backend/` (backend anterior); la API vive en el repositorio `pae-api`.
- `.idea/` ya no se versiona (está en `.gitignore`).

## Pendiente
- Reinscripción sigue con datos de ejemplo.
